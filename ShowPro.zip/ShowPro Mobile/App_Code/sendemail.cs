﻿using System;
using System.Data;
using System.Configuration;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using WebReference;
using System.Web.Services.Protocols;

/// <summary>
/// Summary description for sendemail
/// </summary>
public class sendemail
{
	public sendemail()
	{
		//
		// TODO: Add constructor logic here
		//
    }
    public static void SendEmailSample(string emto,string sub,string mess)
    {
        // Create the byte array that needs to be attached to the email. 

        // For demonstration, we're just attaching a blank array of roughly 1KB. 

        // For a real attachment, the file would need to be loaded into the byte array. 

        byte[] fileBody = new byte[1000];
        EmailFileAttachment[] fileAttachments = new EmailFileAttachment[1];
        EmailFileAttachment fileAttachment = new EmailFileAttachment();
        fileAttachment.body = fileBody;
        fileAttachment.fileName = "Marketing Flyer";
        fileAttachments[0] = fileAttachment;

        // Create the Email Message 

        SingleEmailMessage[] messages = new SingleEmailMessage[1];
        messages[0] = new SingleEmailMessage();
        //messages[0].bccAddresses = new string[] { "marketing@mycompany.com", "sales@mycompany.com" };
        // messages[0].ccAddresses = new string[] { "yourboss@yourcompany.com" };
        messages[0].bccSender = true;
        messages[0].emailPriority = EmailPriority.Normal;
        messages[0].replyTo = "sharad@aromatyk.com";
        messages[0].saveAsActivity = true;
        messages[0].subject = "Sample email sent via the API";
        messages[0].useSignature = true;
      
        messages[0].plainTextBody = mess;
        //messages[0].plainTextBody = "Dear Customer,\n\nPlease buy our products.\n" +            "Thanks,\n\nJohn Doe\nMarketing Vice President";

        //messages[0].fileAttachments = fileAttachments;



        // We can either set the To Address or just use an ID of a Contact, 

        // Lead or User for an implicit To Address 

        // messages[0].targetObjectId("00ID00000FooVsr"); 

        //messages[0].toAddresses = new string[] { "sharad.verma810@gmail.com" };
        messages[0].toAddresses = new string[] { emto };

        // Now send the email 

        try
        {
            SendEmailResult[] result = login.bi.sendEmail(messages);
            if (result[0].success)
            {
               // Console.WriteLine("The email was sent successfully");
            }
            else
            {
                //Console.WriteLine("The email failed to send: " + result[0].errors[0].message);
            }
        }
        catch (SoapException e)
        {
          //  Console.WriteLine(e.Message);
          //  Console.WriteLine(e.StackTrace);
          //  Console.WriteLine(e.InnerException);
        }
    }
}
