﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using WebReference;
/// <summary>
/// Created By:: Sharad Verma on 11 Sept. 2013
/// Get values from SF regarding accepted appointments with respect to given Agent id
/// </summary>
public class getAppointments
{
    public class AcceptedApptInfo
    {
        //Declare variables for holding the required information
        public string Appt_id { get; set; }
        public DateTime Appt_date { get; set; }
        public string Appt_time { get; set; }
        public string Appt_status { get; set; }
        public string Prop_name { get; set; }
        public string Prop_address { get; set; }
        public string Client_name { get; set; }
        public string Client_phone { get; set; }

        // change on 11 Dec 2013
        public string Client_mobile { get; set; }
        //
        public string Client_email { get; set; }
        public string Appt_time_from { get; set; }
        public string Appt_time_to { get; set; }

        // changin on 19 march 2014
        public string Days_until_Move_in { get; set; }
        public string Move_in_Date { get; set; }
        public string No_Of_Occupants { get; set; }
        public string No_Of_Bedroom { get; set; }
        public string No_Of_Bathroom { get; set; }
        public string Desired_Rent_Start { get; set; }
        public string Desired_Rent_End { get; set; }
        public string Desired_Lease_length { get; set; }
        public string W_D_Preference { get; set; }
        public string Affordable_Inquiry { get; set; }
        public string Dog_Count { get; set; }
        public string Dog_Breed { get; set; }
        public string Cat_Count { get; set; }
        public string Monthly_Income_Check { get; set; }
        public string Pet_type_other { get; set; }
        public string Pet_Count_Other { get; set; }
        public string Notes { get; set; }
        public string Reason_for_Moving { get; set; }
        public string Case_Description { get; set; }

    }
	public getAppointments()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static ArrayList acceptedAppointments(string pAgent_contact_id)
    {
        ArrayList arrList = new ArrayList();

        /*
        arrList.Add(
               new PendingApptInfo
               {
                   Appt_date = "Svetlana",
                   Appt_time = "Omelchenko",
                   Prop_name = "",
                   Prop_address = "",
                   Client_name = "",
                   Client_phone = "",
                   Client_email = ""
               });

        */

        try
        {



            if (login.bi != null)
            {
                if (login.lr.sessionId != null)
                {
                    string asd = login.lr.sessionId;
                }
                else
                {
                    login.loginnow();
                }
            }
            else
            {
                login.loginnow();
            }
            QueryResult qr = null;

            login.bi.QueryOptionsValue = new QueryOptions();


            //            SELECT Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c,
            //Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c,
            //Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.Email FROM Appointment__c
            //where  Contact__c='003d000000PgrzlAAB' and Invite_Status__c = 'Invited' order by LastModifiedDate desc

            // and  Appointment_Date__c>= today
            string sql = "";

            sql = "SELECT Id, Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c," +
                  " Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c," +
                  " Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.Email FROM Appointment__c " +
                  " where  Contact__c='" + pAgent_contact_id + "'  and  Appointment_Date__c>= today and Invite_Status__c = 'Accepted' order by LastModifiedDate desc";

            qr = login.bi.query(sql);

            bool done = false;

            if (qr.size > 0)
            {



                while (!done)
                {
                    


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        //Generate new instance of the Class to hold the values
                        AcceptedApptInfo actInfo = new AcceptedApptInfo();

                        Appointment__c con = (Appointment__c)qr.records[i];

                        try
                        {

                            #region Get Appointment details for this Id

                            if (con.Id != null)
                            {
                                actInfo.Appt_id = con.Id;
                            }
                            else
                            {
                                continue;
                            }

                            if (con.Appointment_Date__c != null)
                            {
                                con.Appointment_Date__cSpecified = true;
                                DateTime dt = (DateTime)con.Appointment_Date__c;
                                actInfo.Appt_date = dt; //dt.Month + "/" + dt.Day + "/" + dt.Year;
                                //pndInfo.Appt_date = common.Convert_USA_date(dt);
                            }
                            else
                            {
                                arrList = null;
                                continue;
                            }

                            string Timing = "";

                            if (con.From__c != null)
                            {
                                Timing = con.From__c;
                                actInfo.Appt_time_from = Timing;
                            }
                            else
                            {
                                Timing = "";
                            }
                            if (con.To__c != null)
                            {
                                Timing += " - " + con.To__c;

                                string to = con.To__c;
                                actInfo.Appt_time_to = to;
                            }
                            else
                            {

                                Timing = "";
                            }

                            if (Timing != "")
                            {
                                actInfo.Appt_time = Timing;
                            }


                            if (con.Invite_Status__c != null)
                            {
                               actInfo.Appt_status= con.Invite_Status__c;
                            }
                            else
                            {

                                actInfo.Appt_status = "";
                            }

                            #endregion

                            #region Get Property information for this Order ID

                            if (con.Property_name__c != null)
                            {
                                actInfo.Prop_name = con.Property_name__c;
                            }
                            else
                            {
                                actInfo.Prop_name = "";
                            }

                            string address = "";
                            if (con.Property__r.Address_Line_1__c != null)
                            {
                                address = con.Property__r.Address_Line_1__c;
                            }
                            else
                            {
                                address = "";
                            }
                            if (con.Property__r.City__c != null)
                            {
                                address += "<br/>" + con.Property__r.City__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.State__c != null)
                            {
                                address += " , " + con.Property__r.State__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.Zip_Code__c != null)
                            {
                                address += " " + con.Property__r.Zip_Code__c;
                            }
                            else
                            {
                                address += "";
                            }

                            if (address != "")
                            {
                                actInfo.Prop_address = address;
                            }
                            else
                            {
                                actInfo.Prop_address = "";
                            }

                            #endregion

                            #region Get Prospect(Client) information for this Property and AgentID
                            if (con.Case__r.Contact.Name != null)
                            {
                                actInfo.Client_name = con.Case__r.Contact.Name;
                            }
                            else
                            {
                                actInfo.Client_name = "";
                            }

                            if (con.Case__r.Contact.Phone != null)
                            {
                                actInfo.Client_phone = con.Case__r.Contact.Phone;
                            }
                            else
                            {
                                actInfo.Client_phone = "";
                            }

                            if (con.Case__r.Contact.Email != null)
                            {
                                actInfo.Client_email = con.Case__r.Contact.Email;
                            }
                            else
                            {
                                actInfo.Client_email = "";
                            }

                            #endregion

                            //add this instance into the arraylist
                            arrList.Add(actInfo);

                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                arrList = null;
            }



        }
        catch (Exception ex)
        {
            arrList = null;
        }



        return arrList;

    }

    public static ArrayList upcommingAppointments(string pAgent_contact_id)
    {
        ArrayList arrList = new ArrayList();

        /*
        arrList.Add(
               new PendingApptInfo
               {
                   Appt_date = "Svetlana",
                   Appt_time = "Omelchenko",
                   Prop_name = "",
                   Prop_address = "",
                   Client_name = "",
                   Client_phone = "",
                   Client_email = ""
               });

        */

        try
        {



            if (login.bi != null)
            {
                if (login.lr.sessionId != null)
                {
                    string asd = login.lr.sessionId;
                }
                else
                {
                    login.loginnow();
                }
            }
            else
            {
                login.loginnow();
            }
            QueryResult qr = null;

            login.bi.QueryOptionsValue = new QueryOptions();

            //sql = "SELECT Id, Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c," +
            //      " Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c," +
            //      " Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.MobilePhone,Case__r.Contact.Email FROM Appointment__c " +
            //      " where  Contact__c='" + pAgent_contact_id + "'  and  Appointment_Date__c>= today and Invite_Status__c in ('Accepted','Rejected','Invited') order by Appointment_Date__c asc";

            string sql = "";

            sql = "SELECT Id, Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c,"+
                "Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c, Case__r.Contact.Name,Case__r.Contact.Phone,"+
                "Case__r.Contact.MobilePhone,Case__r.Contact.Email,Case__r.Of_Occupants__c, Case__r.Days_until_Move_in__c, "+
                "Case__r.Move_in_Date__c, Case__r.Desired_Lease_length__c, Case__r.Desired_Rent_Range_End__c, Case__r.Desired_Rent_Start__c,"+
                "Case__r.Bed_Count_Pref__c, Case__r.Bath_Count_Pref__c, Case__r.BedCount__c, Case__r.W_D_Preference__c,"+
                "Case__r.Pet_type_other__c, Case__r.Pet_Count_Other__c, Case__r.Notes__c, Case__r.Monthly_Income_Check__c,"+
                "Case__r.Dog_Count2__c, Case__r.Dog_Count__c, Case__r.Dog_Breed__c, Case__r.Cat_Count__c, Case__r.Affordable_Inquiry__c,"+
                "Case__r.Description, Case__r.Reason_for_Moving__c FROM Appointment__c " +
                  " where  Contact__c='" + pAgent_contact_id + "'  and  Appointment_Date__c>= today and Invite_Status__c in ('Accepted','Rejected','Invited') order by Appointment_Date__c asc";

            qr = login.bi.query(sql);

            bool done = false;

            if (qr.size > 0)
            {



                while (!done)
                {



                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        //Generate new instance of the Class to hold the values
                        AcceptedApptInfo actInfo = new AcceptedApptInfo();

                        Appointment__c con = (Appointment__c)qr.records[i];

                        try
                        {

                            #region Get Appointment details for this Id

                            if (con.Id != null)
                            {
                                actInfo.Appt_id = con.Id;
                            }
                            else
                            {
                                continue;
                            }

                            if (con.Appointment_Date__c != null)
                            {
                                con.Appointment_Date__cSpecified = true;
                                DateTime dt = (DateTime)con.Appointment_Date__c;
                                actInfo.Appt_date = dt; //dt.Month + "/" + dt.Day + "/" + dt.Year;
                                //pndInfo.Appt_date = common.Convert_USA_date(dt);
                            }
                            else
                            {
                                arrList = null;
                                continue;
                            }

                            string Timing = "";

                            if (con.From__c != null)
                            {
                                Timing = con.From__c;
                                actInfo.Appt_time_from = Timing;
                            }
                            else
                            {
                                Timing = "";
                            }
                            if (con.To__c != null)
                            {
                                Timing += " - " + con.To__c;
                                string to = con.To__c;
                                actInfo.Appt_time_to = to;
                            }
                            else
                            {

                                Timing = "";
                            }

                            if (Timing != "")
                            {
                                actInfo.Appt_time = Timing;
                            }


                            if (con.Invite_Status__c != null)
                            {
                                actInfo.Appt_status = con.Invite_Status__c;
                            }
                            else
                            {

                                actInfo.Appt_status = "";
                            }

                            #endregion

                            #region Get Property information for this Order ID

                            if (con.Property_name__c != null)
                            {
                                actInfo.Prop_name = con.Property_name__c;
                            }
                            else
                            {
                                actInfo.Prop_name = "";
                            }

                            string address = "";
                            if (con.Property__r.Address_Line_1__c != null)
                            {
                                address = con.Property__r.Address_Line_1__c;
                            }
                            else
                            {
                                address = "";
                            }
                            if (con.Property__r.City__c != null)
                            {
                                address += "<br/>" + con.Property__r.City__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.State__c != null)
                            {
                                address += " , " + con.Property__r.State__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.Zip_Code__c != null)
                            {
                                address += " " + con.Property__r.Zip_Code__c;
                            }
                            else
                            {
                                address += "";
                            }

                            if (address != "")
                            {
                                actInfo.Prop_address = address;
                            }
                            else
                            {
                                actInfo.Prop_address = "";
                            }

                            #endregion

                            #region Get Prospect(Client) information for this Property and AgentID
                            if (con.Case__r.Contact.Name != null)
                            {
                                actInfo.Client_name = con.Case__r.Contact.Name;
                            }
                            else
                            {
                                actInfo.Client_name = "";
                            }

                            if (con.Case__r.Contact.Phone != null)
                            {
                                actInfo.Client_phone = con.Case__r.Contact.Phone;
                            }
                            else
                            {
                                actInfo.Client_phone = "";
                            }

                            // change on 11 Dec 2013

                            if (con.Case__r.Contact.MobilePhone != null)
                            {
                                actInfo.Client_mobile = con.Case__r.Contact.MobilePhone;
                            }
                            else
                            {
                                actInfo.Client_mobile = "";
                            }

                            //
                            if (con.Case__r.Contact.Email != null)
                            {
                                actInfo.Client_email = con.Case__r.Contact.Email;
                            }
                            else
                            {
                                actInfo.Client_email = "";
                            }

                            #endregion

                            #region Get Prospect Desires information for this AgentID
                            if (con.Case__r.Days_until_Move_in__c != null)
                            {
                                actInfo.Days_until_Move_in = con.Case__r.Days_until_Move_in__c.ToString();
                            }
                            else
                            {
                                actInfo.Days_until_Move_in = "";
                            }

                            if (con.Case__r.Move_in_Date__c != null)
                            {
                                con.Case__r.Move_in_Date__cSpecified = true;
                                DateTime dt = (DateTime)con.Case__r.Move_in_Date__c;
                                actInfo.Move_in_Date = common.Convert_USA_date(dt);
                            }
                            

                            if (con.Case__r.Of_Occupants__c != null)
                            {
                                actInfo.No_Of_Occupants = con.Case__r.Of_Occupants__c.ToString();
                            }
                            else
                            {
                                actInfo.No_Of_Occupants = "";
                            }


                            if (con.Case__r.Bed_Count_Pref__c != null)
                            {
                                actInfo.No_Of_Bedroom = con.Case__r.Bed_Count_Pref__c;
                            }
                            else
                            {
                                actInfo.No_Of_Bedroom = "";
                            }
                            if (con.Case__r.Bath_Count_Pref__c != null)
                            {
                                actInfo.No_Of_Bathroom = con.Case__r.Bath_Count_Pref__c;
                            }
                            else
                            {
                                actInfo.No_Of_Bathroom = "";
                            }
                            if (con.Case__r.Desired_Rent_Start__c != null)
                            {
                                actInfo.Desired_Rent_Start = con.Case__r.Desired_Rent_Start__c.ToString();
                            }
                            else
                            {
                                actInfo.Desired_Rent_Start = "0";
                            }
                            if (con.Case__r.Desired_Rent_Range_End__c != null)
                            {
                                actInfo.Desired_Rent_End = con.Case__r.Desired_Rent_Range_End__c.ToString();
                            }
                            else
                            {
                                actInfo.Desired_Rent_End = "0";
                            }
                            if (con.Case__r.Desired_Lease_length__c != null)
                            {
                                actInfo.Desired_Lease_length = con.Case__r.Desired_Lease_length__c.ToString();
                            }
                            else
                            {
                                actInfo.Desired_Lease_length = "";
                            }
                            if (con.Case__r.W_D_Preference__c != null)
                            {
                                actInfo.W_D_Preference = con.Case__r.W_D_Preference__c.ToString();
                            }
                            else
                            {
                                actInfo.W_D_Preference = "";
                            }
                            if (con.Case__r.Affordable_Inquiry__c != null)
                            {
                                actInfo.Affordable_Inquiry = con.Case__r.Affordable_Inquiry__c;
                            }
                            else
                            {
                                actInfo.Affordable_Inquiry = "";
                            }
                            if (con.Case__r.Monthly_Income_Check__c != null)
                            {
                                actInfo.Monthly_Income_Check = con.Case__r.Monthly_Income_Check__c;
                            }
                            else
                            {
                                actInfo.Monthly_Income_Check = "";
                            }
                            #endregion

                            #region Get Pet information for this AgentID
                            if (con.Case__r.Dog_Count2__c != null)
                            {
                                actInfo.Dog_Count = con.Case__r.Dog_Count2__c.ToString();
                            }
                            else
                            {
                                actInfo.Dog_Count = "";
                            }
                            if (con.Case__r.Dog_Breed__c != null)
                            {
                                actInfo.Dog_Breed = con.Case__r.Dog_Breed__c.ToString();
                            }
                            else
                            {
                                actInfo.Dog_Breed = "";
                            }
                            if (con.Case__r.Cat_Count__c != null)
                            {
                                actInfo.Cat_Count = con.Case__r.Cat_Count__c.ToString();
                            }
                            else
                            {
                                actInfo.Cat_Count = "";
                            }
                            

                            #endregion

                            #region Call Notes information for this AgentID
                            if (con.Case__r.Notes__c != null)
                            {
                                actInfo.Notes = con.Case__r.Notes__c;
                            }
                            else
                            {
                                actInfo.Notes = "";
                            }

                            if (con.Case__r.Reason_for_Moving__c != null)
                            {
                                
                                actInfo.Reason_for_Moving = con.Case__r.Reason_for_Moving__c;
                            }
                            else
                            {
                                actInfo.Reason_for_Moving = "";
                            }
                            if (con.Case__r.Description != null)
                            {

                                actInfo.Case_Description = con.Case__r.Description;
                            }
                            else
                            {
                                actInfo.Case_Description = "";
                            }
                           


                            #endregion

                            //add this instance into the arraylist
                            arrList.Add(actInfo);

                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                arrList = null;
            }



        }
        catch (Exception ex)
        {
            arrList = null;
        }



        return arrList;

    }

    public static ArrayList AppointmentsForCalendar(string pAgent_contact_id)
    {
        ArrayList arrList = new ArrayList();

        /*
        arrList.Add(
               new PendingApptInfo
               {
                   Appt_date = "Svetlana",
                   Appt_time = "Omelchenko",
                   Prop_name = "",
                   Prop_address = "",
                   Client_name = "",
                   Client_phone = "",
                   Client_email = ""
               });

        */

        try
        {



            if (login.bi != null)
            {
                if (login.lr.sessionId != null)
                {
                    string asd = login.lr.sessionId;
                }
                else
                {
                    login.loginnow();
                }
            }
            else
            {
                login.loginnow();
            }
            QueryResult qr = null;

            login.bi.QueryOptionsValue = new QueryOptions();


            //            SELECT Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c,
            //Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c,
            //Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.Email FROM Appointment__c
            //where  Contact__c='003d000000PgrzlAAB' and Invite_Status__c = 'Invited' order by LastModifiedDate desc

            // and  Appointment_Date__c>= today
            string sql = "";

            sql = "SELECT Id, Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c," +
                  " Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c," +
                  " Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.Email FROM Appointment__c " +
                  " where  Contact__c='" + pAgent_contact_id + "'  and  Invite_Status__c in('Accepted','Invited') order by LastModifiedDate desc";
                  //" where  Contact__c='" + pAgent_contact_id + "'  and  Appointment_Date__c>= today and Invite_Status__c = 'Accepted' order by LastModifiedDate desc";

            qr = login.bi.query(sql);

            bool done = false;

            if (qr.size > 0)
            {



                while (!done)
                {



                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        //Generate new instance of the Class to hold the values
                        AcceptedApptInfo actInfo = new AcceptedApptInfo();

                        Appointment__c con = (Appointment__c)qr.records[i];

                        try
                        {

                            #region Get Appointment details for this Id

                            if (con.Id != null)
                            {
                                actInfo.Appt_id = con.Id;
                            }
                            else
                            {
                                continue;
                            }

                            if (con.Appointment_Date__c != null)
                            {
                                con.Appointment_Date__cSpecified = true;
                                DateTime dt = (DateTime)con.Appointment_Date__c;
                                actInfo.Appt_date = dt; //dt.Month + "/" + dt.Day + "/" + dt.Year;
                                //pndInfo.Appt_date = common.Convert_USA_date(dt);
                            }
                            else
                            {
                                arrList = null;
                                continue;
                            }

                            string Timing = "";

                            if (con.From__c != null)
                            {
                                Timing = con.From__c;
                            }
                            else
                            {
                                Timing = "";
                            }
                            if (con.To__c != null)
                            {
                                Timing += " - " + con.To__c;
                            }
                            else
                            {

                                Timing = "";
                            }

                            if (Timing != "")
                            {
                                actInfo.Appt_time = Timing;
                            }


                            if (con.Invite_Status__c != null)
                            {
                                actInfo.Appt_status = con.Invite_Status__c;
                            }
                            else
                            {

                                actInfo.Appt_status = "";
                            }

                            #endregion

                            #region Get Property information for this Order ID

                            if (con.Property_name__c != null)
                            {
                                actInfo.Prop_name = con.Property_name__c;
                            }
                            else
                            {
                                actInfo.Prop_name = "";
                            }

                            string address = "";
                            if (con.Property__r.Address_Line_1__c != null)
                            {
                                address = con.Property__r.Address_Line_1__c;
                            }
                            else
                            {
                                address = "";
                            }
                            if (con.Property__r.City__c != null)
                            {
                                address += "<br/>" + con.Property__r.City__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.State__c != null)
                            {
                                address += " , " + con.Property__r.State__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.Zip_Code__c != null)
                            {
                                address += " " + con.Property__r.Zip_Code__c;
                            }
                            else
                            {
                                address += "";
                            }

                            if (address != "")
                            {
                                actInfo.Prop_address = address;
                            }
                            else
                            {
                                actInfo.Prop_address = "";
                            }

                            #endregion

                            #region Get Prospect(Client) information for this Property and AgentID
                            if (con.Case__r.Contact.Name != null)
                            {
                                actInfo.Client_name = con.Case__r.Contact.Name;
                            }
                            else
                            {
                                actInfo.Client_name = "";
                            }

                            if (con.Case__r.Contact.Phone != null)
                            {
                                actInfo.Client_phone = con.Case__r.Contact.Phone;
                            }
                            else
                            {
                                actInfo.Client_phone = "";
                            }

                            if (con.Case__r.Contact.Email != null)
                            {
                                actInfo.Client_email = con.Case__r.Contact.Email;
                            }
                            else
                            {
                                actInfo.Client_email = "";
                            }

                            #endregion

                            //add this instance into the arraylist
                            arrList.Add(actInfo);

                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                arrList = null;
            }



        }
        catch (Exception ex)
        {
            arrList = null;
        }



        return arrList;

    }
}