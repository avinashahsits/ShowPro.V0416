﻿using System;
using System.Collections.Generic;
using System.Web;


/// <summary>
/// "The Code Warehouse":::::: most commonly used C# methods.
/// </summary>
public class common
{
    public static string MbName = "";
    public common()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary>
    /// Is Mobile Device? Store Mobile Device Name in MbName (Static String Variable)
    /// </summary>

    private static readonly string[] mobiles =
            new[]
            {
               "rim tablet", "blackberry", "palmsource",
               "panasonic", "wireless", "android",
               "windows ce", "novarra", "alcatel",
               "philips", "samsung", "docomo",
               "pocket", "compal", "iphone",
               "symbian", "mitsu", "sagem",
               "sony", "sharp", "rover",  "benq",
               "gradi", "sendo", "webos",
               "nokia", "palmos", "chtml",
               "audio", "java", "dddi", "avant",
               "bird", "amoi", "voda", "eric",
               "hand", "opwv", "mobi", "midp",
               "phone", "j2me", "ipod", "ipad",
               "sany", "moto", "up.b", "SIE-",
               "kdd", "dbt", "mmm", "sgh",
               "wap", "NEC", "sch", "cdm",
               "SEC-",  "HTC", "mot-",  "vox",
               "pda",  "mmp", "mib",
               "lg",  "vx", "xx",
               "pt", "pg", "kg", "jb"
            };
    public static bool isMobileBrowser()
    {
        //GETS THE CURRENT USER CONTEXT
        HttpContext context = HttpContext.Current;

        //FIRST TRY BUILT IN ASP.NT CHECK
        if (context.Request.Browser.IsMobileDevice)
        {
            return true;
        }
        //THEN TRY CHECKING FOR THE HTTP_X_WAP_PROFILE HEADER
        if (context.Request.ServerVariables["HTTP_X_WAP_PROFILE"] != null)
        {
            return true;
        }
        //THEN TRY CHECKING THAT HTTP_ACCEPT EXISTS AND CONTAINS WAP
        if (context.Request.ServerVariables["HTTP_ACCEPT"] != null &&
            context.Request.ServerVariables["HTTP_ACCEPT"].ToLower().Contains("wap"))
        {
            return true;
        }
        //AND FINALLY CHECK THE HTTP_USER_AGENT 
        //HEADER VARIABLE FOR ANY ONE OF THE FOLLOWING
        if (context.Request.ServerVariables["HTTP_USER_AGENT"] != null)
        {
            //Create a list of all mobile types
            string[] mobiles =
                new[]
                {
                    "midp", "j2me", "avant", "docomo", "blackberry","android","windows ce", "novarra", "alcatel","philips", "samsung", "docomo",
                    "novarra", "palmos", "palmsource", "j2me", "ipod", "ipad",
                    "240x320", "opwv", "chtml",
                    "pda", "windows ce", "mmp/", 
                    "blackberry", "mib/", "symbian", 
                    "wireless", "nokia", "hand", "mobi",
                    "phone", "cdm", "up.b", "audio", 
                    "SIE-", "SEC-", "samsung", "HTC", 
                    "mot-", "mitsu", "sagem", "sony"
                    , "alcatel", "lg", "eric", "vx", 
                    "NEC", "philips", "mmm", "xx", 
                    "panasonic", "sharp", "wap", "sch",
                    "rover", "pocket", "benq", "java", 
                    "pt", "pg", "vox", "amoi", 
                    "bird", "compal", "kg", "voda",
                    "sany", "kdd", "dbt", "sendo", 
                    "sgh", "gradi", "jb", "dddi", 
                    "moto", "iphone", "android"
                };

            //Loop through each item in the list created above 
            //and check if the header contains that text
            foreach (string s in mobiles)
            {
                if (context.Request.ServerVariables["HTTP_USER_AGENT"].
                                                    ToLower().Contains(s.ToLower()))
                {

                    MbName = s;
                    return true;
                }
            }
        }

        return false;
    }
    public static double Return2places(double pVal)
    {
        double myPrice = pVal;

        String.Format(((Math.Round(myPrice) == myPrice) ? "{0:0}" : "{0:0.00}"), myPrice);
        return myPrice;
    }
    public static string USA_date(string pDate)
    {
        string result = "";
        try
        {
            DateTime dt = Convert.ToDateTime(pDate);

            result = dt.Month + "/" + dt.Day + "/" + dt.Year;
        }
        catch (Exception ex)
        {
            result = pDate;
        }
        return result;
    }
    public static string Convert_USA_date(DateTime pDate)
    {
        string result = "";
        try
        {
            DateTime dt = pDate;

            result = dt.Month + "/" + dt.Day + "/" + dt.Year;
        }
        catch (Exception ex)
        {
            result = "";
        }
        return result;
    }
    public static string ToIsoFormat(DateTime dateTime)
    {
        return dateTime.ToString("yyyy-MM-ddTHH:mm:ssZ");
    }

    public static string FormatDateForQuery(DateTime dateToFormat, bool includeTime)
    {
        if (includeTime)
        {
            return dateToFormat.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss+00:00");
        }
        else
        {
            return dateToFormat.ToUniversalTime().ToString("yyyy-MM-dd");
        }
    }
    public static string SF_date(string pDate)
    {
        string result = "";
        try
        {
            DateTime dt = Convert.ToDateTime(pDate);

            // result = dt.Month + "/" + dt.Day + "/" + dt.Year;


            int mm = dt.Month;
            string month = "";
            if (mm > 9)
            {
                month = Convert.ToString(dt.Month);
            }
            else
            {
                month = "0" + mm;
            }

            int day = dt.Day;
            string today_date = "";
            if (day > 9)
            {
                today_date = Convert.ToString(dt.Day);
            }
            else
            {
                today_date = "0" + day;
            }

            //2013-04-29
            result = dt.Year + "-" + month + "-" + today_date;


        }
        catch (Exception ex)
        {
            result = pDate;
        }
        return result;
    }

    public static string UppercaseWords(string value)
    {
        char[] array = value.ToCharArray();
        // Handle the first letter in the string.
        if (array.Length >= 1)
        {
            if (char.IsLower(array[0]))
            {
                array[0] = char.ToUpper(array[0]);
            }
        }
        // Scan through the letters, checking for spaces.
        // ... Uppercase the lowercase letters following spaces.
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i - 1] == ' ')
            {
                if (char.IsLower(array[i]))
                {
                    array[i] = char.ToUpper(array[i]);
                }
            }
        }
        return new string(array);
    }


    public static string Right(string sValue, int iMaxLength)
    {
        //Check if the value is valid
        if (string.IsNullOrEmpty(sValue))
        {
            //Set valid empty string as string could be null
            sValue = string.Empty;
        }
        else if (sValue.Length > iMaxLength)
        {
            //Make the string no longer than the max length
            sValue = sValue.Substring(sValue.Length - iMaxLength, iMaxLength);
        }

        //Return the string
        return sValue;
    }



}