﻿using System;
using System.Web;

/// <summary>
/// Summary description for appdb
/// </summary>
public class appdb
{
    public appdb()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public static string dbconmars()
    {

          // string cn_strg = "server=P3NWDSHSQL8-v03.shr.prod.phx3.secureserver.net; database=wsapi; User Id=wsapi;Password=Ahsits123@;MultipleActiveResultSets=true";

        //	P3NW3SHSQL8-v01.shr.prod.phx3.secureserver.net (MSSQL 2008)

        //  string cn_strg = "server=P3NW3SHSQL8-v01.shr.prod.phx3.secureserver.net; database=Anyonehome; User Id=Anyonehome;Password=Showhome1@;MultipleActiveResultSets=true";


        //string cn_strg = "server=localhost; database=appdb; integrated security=true;MultipleActiveResultSets=true";
       // string cn_strg = "server=ASUS-PC; database=appdb; User Id=sa;Password=ahsits;MultipleActiveResultSets=true";
        string cn_strg = "server=208.109.95.124; database=appdb; User Id=sa;Password=pass@123;MultipleActiveResultSets=true";
        return cn_strg;

        //        sub domain - ws.ahsits.us

        //db - wsapi

        //password - Ahsits123@

        //https://p3nmssqladmin.secureserver.net/2008/37/scripts/2005/login.aspx


        //P3NWDSHSQL8-v03.shr.prod.phx3.secureserver.net (MSSQL 2008)


        //con=
        //Data Source=P3NWDSHSQL8-v03.shr.prod.phx3.secureserver.net;Initial Catalog=wsapi;Persist Security Info=True;User ID=wsapi



    }
}