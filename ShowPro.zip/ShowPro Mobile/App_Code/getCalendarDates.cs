﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using WebReference;
/// <summary>
/// Summary description for getCalendarDates
/// </summary>
public class getCalendarDates
{
    public getCalendarDates()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary>
    /// Get Exception dates by providing Contact id and Status=2 to Un-Availability custom object
    /// </summary>
    public static ArrayList getSavedDateByID(string pID)
    {
        ArrayList result = new ArrayList();
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }

   

       // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            string sql = "SELECT Id, av_Date__c FROM Unvailability__c where Saved_by__c='" + pID + "' and av_Status__c=2 order by av_Date__c desc";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Unvailability__c
                          con = (Unvailability__c)qr.records[i];

                        con.av_Date__cSpecified = true;
                        string date = Convert.ToString(con.av_Date__c);

                        DateTime dt = Convert.ToDateTime(date);

                        date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                        result.Add(date);

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = new ArrayList();

            }
        }
        catch (Exception ex)
        {
            result = new ArrayList();

        }

        return result;
    }

    /// <summary>
    /// Get dafault days name like Monday, tuesday etc...by providing Contact id to Default Custom Object
    /// </summary>
    public static ArrayList getDefaultDaysByID(string pID)
    {
        ArrayList result = new ArrayList();
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {

            string sql = "SELECT Day__c FROM Default_Availability__c where contact_rec_id__c='" + pID + "'";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Default_Availability__c con = (Default_Availability__c)qr.records[i];
                        string day = con.Day__c;

                        if (day != "")
                        {

                            result.Add(day);
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = new ArrayList();

            }
            
        }
        catch (Exception ex)
        {
            result = new ArrayList();

        }

        return result;
    }

    /// <summary>
    /// Get Day Off dates...by providing Contact id and Status=3
    /// </summary>
    public static ArrayList getDayOffDateByID(string pID)
    {
        ArrayList result = new ArrayList();
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            string sql = "SELECT Id, av_Date__c FROM Unvailability__c where Saved_by__c='" + pID + "' and av_Status__c=3 order by av_Date__c desc";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Unvailability__c con = (Unvailability__c)qr.records[i];

                        con.av_Date__cSpecified = true;
                        string date = Convert.ToString(con.av_Date__c);

                        DateTime dt = Convert.ToDateTime(date);

                        date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                        result.Add(date);

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = new ArrayList();

            }
        }
        catch (Exception ex)
        {
            result = new ArrayList();


        }

        return result;
    }
}