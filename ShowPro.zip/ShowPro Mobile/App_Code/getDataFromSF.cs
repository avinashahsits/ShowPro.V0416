﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using WebReference;
/// <summary>
/// get Salesforce Object data here
/// </summary>
public class getDataFromSF
{
    public getDataFromSF()
    {
        //
        // TODO: Add constructor logic here
        //
    } /// <summary>
    /// Get Exception dates by providing Contact id and Status=2 to Un-Availability custom object
    /// </summary>
    public static ArrayList getContactDataByID(string pID)
    {
        ArrayList result = new ArrayList();
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //SELECT Id, Email, Name FROM Contact where Id='003d000000IUmR6AAL'
            // query change on 4 april 2014
            // string sql = "SELECT Id, Email, Name FROM Contact where Id='" + pID + "'";
            string sql = "SELECT Id, Email, Name,(SELECT Allow_Agents_Default_Availability_in_SP__c FROM Accounts1__r) FROM Contact where Id='" + pID + "'";//, (SELECT Allow_Agents_Default_Availability_in_SP__c FROM Accounts1__r)
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Contact con = (Contact)qr.records[i];

                        string emailid = con.Email.Trim();
                        string name = con.Name.Trim();

                        if (emailid != "")
                        {
                            result.Add(emailid);
                        }
                        else
                        {
                            result.Add("N/A");
                        }
                        if (name != "")
                        {
                            result.Add(name);
                        }
                        else
                        {
                            result.Add("N/A");
                        }
                        try
                        {
                            Object[] dAv = con.Accounts1__r.records;

                            foreach (var item in dAv)
                            {
                                Account deav = (Account)item;
                                string oncheckdefault = deav.Allow_Agents_Default_Availability_in_SP__c.ToString();
                                result.Add(oncheckdefault);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = new ArrayList();

            }
        }
        catch (Exception ex)
        {
            result = new ArrayList();

        }

        return result;
    }
    public static string isDayOffByID(string pID, string pDate)
    {
        string result = "";
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //SELECT Id, Email, Name FROM Contact where Id='003d000000IUmR6AAL'
            string sql = "SELECT Id, av_Status__c FROM Unvailability__c where Saved_by__c='" + pID + "' and av_Date__c=" + pDate;
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Unvailability__c con = (Unvailability__c)qr.records[i];
                        con.av_Status__cSpecified = true;
                        double isDayOff = Convert.ToUInt32(con.av_Status__c.ToString());

                        if (isDayOff == 3 || isDayOff == 3.00)
                        {

                            string DayOff_recId = con.Id;
                            result = DayOff_recId;
                        }
                        else
                        {
                            result = "";
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = "";

            }
        }
        catch (Exception ex)
        {
            result = "";

        }

        return result;
    }

    public static bool isDayOffAllowedByID(string pID, string pDate)
    {
        bool result = false;
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //SELECT Id, Email, Name FROM Contact where Id='003d000000IUmR6AAL'
            // invitation_status = "Accepted";
            //SELECT Contact__c, Appointment_Date__c, Invite_Status__c FROM Appointment__c where Contact__c='003i00000073R24AAE' and Appointment_Date__c=2013-04-22 and Invite_Status__c='Accepted'

            pDate = common.SF_date(pDate);

            string sql = "SELECT Contact__c, Appointment_Date__c, Invite_Status__c FROM Appointment__c where Contact__c='" + pID + "' and Appointment_Date__c=" + pDate + " and Invite_Status__c='Accepted'";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {
                /*
                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Appointment__c con = (Appointment__c)qr.records[i];
                        result = false;

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }
                */
                //has appointment, do not allow for Day off
                result = false;

            }
            else
            {
                //has no aapointment accepted in this day
                result = true;

            }
        }
        catch (Exception ex)
        {
            result = false;

        }

        return result;
    }
    public static Dictionary<string,string> ValidateAccountUser(string pLoginId,string pLoginPwd)
    {
        Dictionary<string, string> AccountInfo = new Dictionary<string, string>();

        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 5;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //SELECT Id, Email, Name FROM Contact where Id='003d000000IUmR6AAL'
            string sql = "SELECT Id, Name, Email FROM Contact where Email='" + pLoginId + "'";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Contact con = (Contact)qr.records[i];

                        string con_id = con.Id;

                        if (con_id != "")
                        {
                            AccountInfo.Add("", "");
                        }
                        else
                        {
                            
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                AccountInfo = null;
            }
        }
        catch (Exception ex)
        {
            AccountInfo = null;
        }

        return AccountInfo;
    }

    public static string getIDbyEmail(string pemail)
    {
        string result = "";
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //SELECT Id, Email, Name FROM Contact where Id='003d000000IUmR6AAL'
            string sql = "SELECT Id, Name, Email FROM Contact where Email='" + pemail + "'";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Contact con = (Contact)qr.records[i];

                        string con_id = con.Id;

                        if (con_id != "")
                        {
                            result = con_id;
                        }
                        else
                        {
                            result = "";
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = "";

            }
        }
        catch (Exception ex)
        {
            result = "";

        }

        return result;
    }

    public static string getPropertyName()
    {

        string result = "";
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }



        // login.loginnow();

        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //SELECT Address_Line_1__c, Address_Line_2__c, City__c, Zip_Code__c, State__c, Id, Name FROM Property__c
            string sql = "SELECT Address_Line_1__c, Address_Line_2__c, City__c, Zip_Code__c, State__c, Id, Name FROM Property__c order by LastActivityDate desc";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {
                    int _k = 1;

                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Property__c con = (Property__c)qr.records[i];

                        string address = con.Address_Line_1__c + " " + con.Address_Line_2__c + "  " + con.City__c + " " + con.State__c + " " + con.Zip_Code__c;
                        string name = con.Name;
                        string ahref = "<a href=\"javascript://\" onclick=\"call_to_the_boss('" + name + "','" + con.Id + "')\" >" + name + "</a>";
                        if (_k == 1)
                        {
                            result += "<tr class=\"gradeA\"><td>" + ahref + "</td><td>" + address + "</td></tr>";
                            _k = 2;
                        }
                        else
                        {
                            result += "<tr class=\"gradeC\"><td>" + ahref + "</td><td>" + address + "</td></tr>";
                            _k = 1;
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = "";

            }
        }
        catch (Exception ex)
        {
            result = ""; //ex.Message;

        }

        return result;

    }
    
}