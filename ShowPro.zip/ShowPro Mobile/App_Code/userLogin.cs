﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;

/// <summary>
/// Summary description for userLogin
/// </summary>
public class userLogin
{
    public userLogin()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    /// <summary>
    /// User Login function which validate user by given Token key and Pin, if found valid then return string array with Record id, Email id and User name
    /// </summary>
    public static string[] User_login(string puser_token_key, string puser_Pin)
    {


        SqlConnection con = new SqlConnection(appdb.dbconmars());
        string[] seesion_values = new string[3]; //No. of Array items to store the required information which will return to call function

        string sql_query = " ";
        try
        {
            bool validate = false;

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql_query, con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    string db_userid = dr[0].ToString();
                    string db_pass = dr[1].ToString();

                    if (puser_token_key == db_userid && db_pass == puser_Pin)
                    {
                        seesion_values[0] = dr[0].ToString();
                        seesion_values[1] = dr[1].ToString();
                        seesion_values[2] = dr[2].ToString();
                        validate = true;
                    }
                    else
                    {
                        seesion_values = new string[1];
                        seesion_values[0] = "0";
                        validate = false;
                    }

                }
            }
            else
            {
                validate = false;
                seesion_values = new string[0];
            }
            dr.Close();
            cmd.Dispose();


            if (validate == true)
            {

            }
        }
        catch (Exception ex)
        {
            //result = false;
        }
        finally
        {
            con.Close();
        }
        return seesion_values;
    }

    /// <summary>
    /// User Logout function which update log-out status and time for given User assigned by Record Id
    /// </summary>
    public static bool User_logout(string puser_token_key, string puser_Pin)
    {

        SqlConnection con = new SqlConnection(appdb.dbconmars());
        bool seesion_values = false;
        
        
        string sql_query = "update sunshineact_login_logs set login_status=0";

        try
        {
            SqlCommand cmd = new SqlCommand(sql_query, con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            int dr = cmd.ExecuteNonQuery();
            if (dr > 0)
            {
                seesion_values = true;
            }
            else
            {
                seesion_values = false;
            }

            cmd.Dispose();

        }
        catch (Exception ex)
        {
            //result = false;
        }
        finally
        {
            con.Close();
        }
        return seesion_values;
    }

    public static string[] salerep_login(string user_log_id, string user_log_pass, string ip, string os, string browser, string wd, string ht)
    {
        //first check session var in the parent page if already login with one account then send to the logout page or provide a way to login as different user
        //if not got any session var then come to this pinot and validate user
        //after the validation fi correct then insert a new record in loginlog table and fetch the auto generated id of this record of the table, store in session var

        //for logout page:
        //when logout then update the logout time in loginlog table with the help of this last sesson var




        //for mr login table:

        /*
        select userid,password,holder_mr_id,holder_email_id,company_id from sunshineact_mr_login where userid='userid' and account_status=1

        */

        SqlConnection con = new SqlConnection(appdb.dbconmars());


        string[] seesion_values = new string[9]; //5 for login table and 2 for loginlog table,2 for comp and sr name to store the auto generated id after the insert
        // select userid,password,holder_mr_id,holder_email_id,company_id from sunshineact_mr_login where userid='userid' and account_status=1
        string sql_query = " select userid,password,holder_mr_id,holder_email_id,company_id from sunshineact_mr_login where userid='" + user_log_id + "' and account_status=1";


        try
        {
            bool validate = false;

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql_query, con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    string db_userid = dr[0].ToString();
                    string db_pass = dr[1].ToString();

                    if (user_log_id == db_userid && db_pass == user_log_pass)
                    {
                        seesion_values[0] = dr[0].ToString();
                        seesion_values[1] = dr[1].ToString();
                        seesion_values[2] = dr[2].ToString();
                        seesion_values[3] = dr[3].ToString();
                        seesion_values[4] = dr[4].ToString();

                        validate = true;
                    }
                    else
                    {
                        seesion_values = new string[1];
                        seesion_values[0] = "0";
                        validate = false;
                    }

                }
            }
            else
            {
                validate = false;
                seesion_values = new string[0];
            }
            dr.Close();
            cmd.Dispose();


            // for loginlog table :
            /*
            SELECT IDENT_CURRENT('sunshineact_login_logs')
            insert into sunshineact_login_logs values('userid+mr',1,'192.168.125.124','windows xp','explorer 7','1000','700',getdate(),getdate())
            delete sunshineact_login_logs
            select * from sunshineact_login_logs where login_type='userid+mr'
            update sunshineact_login_logs set login_status=0,logout_time=getdate() where login_type='userid+mr'
            */
            if (validate == true)
            {
                string user_type = seesion_values[0] + "_" + seesion_values[4] + "_mr"; //userid_cmpid_mr
                string insert_loginlog = "insert into sunshineact_login_logs values('" + user_type + "',1,'" + ip + "','" + os + "','" + browser + "','" + wd + "','" + ht + "',getdate(),null) SELECT IDENT_CURRENT('sunshineact_login_logs')";
                cmd = new SqlCommand(insert_loginlog, con);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        seesion_values[5] = dr[0].ToString();
                        seesion_values[6] = user_type;
                        //sesson variable login_log_auto_ssn
                        //sesson variable user_type_ssn

                    }
                }
                dr.Close();
                cmd.Dispose();

                /*sss[4]=cmpid
                    ss[2]=srregid

                    ss[7]=sr name
                    ss[8]=cmp name
                  */



                string select_name = "select first_name+' '+last_name from sunshineact_salesrep_reg where sales_rep_id='" + seesion_values[2] + "'";
                string select_cmp_name = "select company_name from sunshineact_company_reg where company_id='" + seesion_values[4] + "'";

                cmd = new SqlCommand(select_name + " " + select_cmp_name, con);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        seesion_values[7] = dr[0].ToString();

                    }
                    dr.NextResult();
                    dr.Read();
                    seesion_values[8] = dr[0].ToString();
                }
            }

            dr.Close();
            cmd.Dispose();

        }
        catch (Exception ex)
        {
            //result = false;
        }
        finally
        {
            con.Close();
        }
        return seesion_values;
    }
}