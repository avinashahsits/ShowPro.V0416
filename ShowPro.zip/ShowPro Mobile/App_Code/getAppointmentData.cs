﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebReference;
using System.Xml;
/// <summary>
/// Created by: Sharad Verma on 12 Sept 2013
/// </summary>
public class getAppointmentData
{
	public getAppointmentData()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public class ApptSlotTime
    {
        public int startTime { get; set; }
        public int endTime { get; set; }
    }

   //public static Dictionary<int, ApptSlotTime> slotTiming = new Dictionary<int, ApptSlotTime>();

    //use this function for counting appointment for specific agent, date, time and property
    public static int countAppts(string ppropid,string pAgentId, DateTime pdt, int pSlotTime,int pSlotLimit, ref string mess)
    {
        int result = 0;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

            //SELECT Id, To__c, From__c, Property__c, Day__c, Case__c, Appointment_Date__c, Contact__c FROM Appointment__c where 
            //To__c='' and From__c='' and Property__c='a00i0000002JNSFAA4' and  Day__c='' and Case__c='' and Appointment_Date__c= and Contact__c=''

            /*
            SELECT Contact__c, Appointment_Date__c, NoTo__c, NoFrom__c FROM Appointment__c where 
Property__c='a00i0000002JNSFAA4'
and Appointment_Date__c=2013-09-18 and Contact__c='003i00000073R2EAAU'


 SELECT count(Id) FROM Appointment__c where Property__c='a00i0000002JNSFAA4'
and Appointment_Date__c=2013-09-18 and Contact__c='003i00000073R2EAAU' and (NoTo__c <= 26 and NoFrom__c >= 26)


            SELECT count(Id) FROM Appointment__c where Property__c='a00i0000002JNSFAA4'
and Appointment_Date__c=2013-09-18 and Contact__c='003i00000073R2EAAU'
            */


           

            string dayName = String.Format("{0:dddd}", pdt);


            string apptDate = common.Convert_USA_date(pdt);
            apptDate = common.SF_date(apptDate);


            //SELECT count(Id) FROM Appointment__c where Invite_Status__c='Invited'


            //for the Slot item only
            //string sql_appts_byid = " SELECT count(Id) FROM Appointment__c where " +
            //" Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and (NoTo__c <= " + pSlotTime + " and NoFrom__c >= " + pSlotTime + ")";

            
            //for the SlotLimit
            int apptStart = pSlotTime;
            int apptEnd = (pSlotTime - pSlotLimit);

            if (apptEnd < 1)
            {
                return 0;
            }

            
            string sql_appts_byid_old = " SELECT count(Id) FROM Appointment__c where " +
            " Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and (NoTo__c <= " + apptEnd + " and NoFrom__c >= " + apptStart + ")";

            string sql_appts_byid = " SELECT count(Id) FROM Appointment__c where " +
            " Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and (NoTo__c = " + pSlotTime + " or NoFrom__c = " + pSlotTime + ")";

            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {  
                        //if this Agent has appointment with this Property then return the no. of appointments otherwise return 0 
                        // because there is no mean of Concurrent Showing if the Property is defferent so use Property ID in filter also!
                        //just return the number from here! do not panic about the logic, it will be taken care of in the Slot display page! :-)
                      
                        AggregateResult ar = (AggregateResult)qr.records[i];

                        string Count = "";
                        foreach (XmlElement e in ar.Any)
                        {
                            //Console.WriteLine("{0} - {1}", e.LocalName, e.InnerText);
                            //Status = System.String.Format("{0} - {1}", e.LocalName, e.InnerText);
                            Count = System.String.Format(e.InnerText);
                        }
                        if (Count != "")
                        {
                            result = Convert.ToInt32(Count);
                        }
                        else
                        {
                            result = 0;
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }

                
            }
            else
            {
                result = 0;
            }
        }
        catch (Exception ex)
        {
            mess = ex.Message;
            result = 0;
        }
        finally
        {
        }

        return result;
    }


    public static int countAppts(string ppropid, string pAgentId, DateTime pdt, int pSlotTime,string pSlotBitween, ref string mess)
    {
        int result = 0;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

          



            string dayName = String.Format("{0:dddd}", pdt);


            string apptDate = common.Convert_USA_date(pdt);
            apptDate = common.SF_date(apptDate);


          

            ////for the SlotLimit
            //int apptStart = pSlotTime;
            //int apptEnd = (pSlotTime - pSlotLimit);

            //if (apptEnd < 1)
            //{
            //    return 0;
            //}


            //string sql_appts_byid_old = " SELECT count(Id) FROM Appointment__c where " +
            //" Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and (NoTo__c <= " + apptEnd + " and NoFrom__c >= " + apptStart + ")";


            //string sql_appts_byid_backup = " SELECT count(Id) FROM Appointment__c where " +
            //" Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and " + pSlotBitween;

//            - Bug - 

//"If you look at Case #1404, 3 overlapping showings for 109 front st on 9/19 at 2:00.  Appt #'s 1309-1648 and -1651 were accepted.  Appt# 1309-1650 was rejected.

//These are all for 109 Front St which has a setting of 3 for concurrent showings.  With only 2 that are accepted/invited, Client should be able to book one more but ShowPro shows the time as unavailable.

            string sql_appts_byid = " SELECT count(Id) FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
           " Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and " + pSlotBitween;


            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        //if this Agent has appointment with this Property then return the no. of appointments otherwise return 0 
                        // because there is no mean of Concurrent Showing if the Property is defferent so use Property ID in filter also!
                        //just return the number from here! do not panic about the logic, it will be taken care of in the Slot display page! :-)

                        AggregateResult ar = (AggregateResult)qr.records[i];

                        string Count = "";
                        foreach (XmlElement e in ar.Any)
                        {
                            //Console.WriteLine("{0} - {1}", e.LocalName, e.InnerText);
                            //Status = System.String.Format("{0} - {1}", e.LocalName, e.InnerText);
                            Count = System.String.Format(e.InnerText);
                        }
                        if (Count != "")
                        {
                            result = Convert.ToInt32(Count);
                        }
                        else
                        {
                            result = 0;
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = 0;
            }
        }
        catch (Exception ex)
        {
            mess = ex.Message;
            result = 0;
        }
        finally
        {
        }

        return result;
    }

    public static int countAppts(string ppropid, string pAgentId, DateTime pdt, int pSlotTime, string pSlotBitween, ref Dictionary<int, ApptSlotTime> pSlotTimings, ref string mess,string pThisAppptid)
    {
        int result = 0;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }


            //string dayName = String.Format("{0:dddd}", pdt);

            string apptDate = common.Convert_USA_date(pdt);
            apptDate = common.SF_date(apptDate);

             //SELECT id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and  Appointment_Date__c=2013-09-20   and Contact__c='003i00000073R2EAAU'  and  (NoTo__c >16 and NoFrom__c > 19) 

            string sql_appts_byid = "";
            if (pThisAppptid != "")
            {
                sql_appts_byid = " SELECT Id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and id <>'" + pThisAppptid + "' and " +
                          " Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and " + pSlotBitween;

            }
            else
            {
                sql_appts_byid = " SELECT Id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
          " Appointment_Date__c=" + apptDate + "  and Property__c='" + ppropid + "' and Contact__c='" + pAgentId + "'  and " + pSlotBitween;

            }
           

            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {

                    int counter = 0;
                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        //if this Agent has appointment with this Property then return the no. of appointments otherwise return 0 
                        // because there is no mean of Concurrent Showing if the Property is defferent so use Property ID in filter also!
                        //just return the number from here! do not panic about the logic, it will be taken care of in the Slot display page! :-)


                        Appointment__c con = (Appointment__c)qr.records[i];
                        
                        

                        ApptSlotTime apt = new ApptSlotTime();

                        if (con.NoFrom__c != null)
                        {
                            con.NoFrom__cSpecified = true;
                            apt.startTime = Convert.ToInt32(con.NoFrom__c);
                        }

                        if (con.NoTo__c != null)
                        {
                            con.NoTo__cSpecified = true;
                            apt.endTime = Convert.ToInt32(con.NoTo__c);
                        }

                        
                        try
                        {                           
                            pSlotTimings.Add(pSlotTime, apt);
                        }
                        catch (Exception ex)
                        {

                        }


                        counter++;

                        /*
                        AggregateResult ar = (AggregateResult)qr.records[i];

                        string Count = "";
                        foreach (XmlElement e in ar.Any)
                        {
                            //Console.WriteLine("{0} - {1}", e.LocalName, e.InnerText);
                            //Status = System.String.Format("{0} - {1}", e.LocalName, e.InnerText);
                            Count = System.String.Format(e.InnerText);
                        }
                        if (Count != "")
                        {
                            result = Convert.ToInt32(Count);
                        }
                        else
                        {
                            result = 0;
                        }

                        */


                    }
                    if (qr.done)
                    {
                        result = counter;
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = 0;
            }
        }
        catch (Exception ex)
        {
            mess = ex.Message;
            result = 0;
        }
        finally
        {
        }

        return result;
    }
    public static string getPropertyIdbyName(string ppropid,string ppName)
    {
        string result = "";
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

           // SELECT Id, Name FROM Property__c where Name='Jamboree - LA'

            if (ppName == "")
            {
                return "";
            }

            string sql_appts_byid = " SELECT Id, Name FROM Property__c where Name='" + ppName + "'";


            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {
                while (!done)
                {
                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Property__c con = (Property__c)qr.records[i];

                        if (con.Id != null)
                        {
                            result = con.Id.Trim();
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result ="";
            }
        }
        catch (Exception ex)
        {
           
            result = "";
        }
        finally
        {
        }

        return result;
    }
}