﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebReference;
/// <summary>
/// Created By:: Sharad Verma on 9 Sept. 2013
/// Get values from SF regarding pending appointments with respect to given Agent id
/// </summary>
public class getPendingAppointmentSF
{
    public class PendingApptInfo
    {
        //Declare variables for holding the required information
        public string Appt_id { get; set; }
        public string Appt_date { get; set; }
        public string Appt_time { get; set; }
        public string Prop_name { get; set; }
        public string Prop_address { get; set; }
        public string Client_name { get; set; }
        public string Client_phone { get; set; }
        // change on 11 Dec 2013
        public string Client_mobile { get; set; }
        public string Client_email { get; set; }
    }

    public getPendingAppointmentSF()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static ArrayList pendingAppointments(string pAgent_contact_id)
    {
        ArrayList arrList = new ArrayList();

        /*
        arrList.Add(
               new PendingApptInfo
               {
                   Appt_date = "Svetlana",
                   Appt_time = "Omelchenko",
                   Prop_name = "",
                   Prop_address = "",
                   Client_name = "",
                   Client_phone = "",
                   Client_email = ""
               });

        */

        try
        {

           

            if (login.bi != null)
            {
                if (login.lr.sessionId != null)
                {
                    string asd = login.lr.sessionId;
                }
                else
                {
                    login.loginnow();
                }
            }
            else
            {
                login.loginnow();
            }
            QueryResult qr = null;

            login.bi.QueryOptionsValue = new QueryOptions();
            
            
//            SELECT Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c,
//Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c,
//Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.Email FROM Appointment__c
//where  Contact__c='003d000000PgrzlAAB' and Invite_Status__c = 'Invited' order by LastModifiedDate desc

            // and  Appointment_Date__c>= today
            string sql = "";

            sql = "SELECT Id, Appointment_Date__c,From__c, Invite_Status__c, To__c,Property_name__c,Property__r.Address_Line_1__c," +
                  " Property__r.City__c,Property__r.State__c,Property__r.Zip_Code__c," +
                  " Case__r.Contact.Name,Case__r.Contact.Phone,Case__r.Contact.MobilePhone,Case__r.Contact.Email FROM Appointment__c " +
                  " where  Contact__c='" + pAgent_contact_id + "'  and  Appointment_Date__c>= today and Invite_Status__c = 'Invited' order by NoFrom__c desc";

            qr = login.bi.query(sql);

            bool done = false;

            if (qr.size > 0)
            {

                

                while (!done)
                {
                    //Generate new instance of the Class to hold the values
                   

                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        PendingApptInfo pndInfo = new PendingApptInfo();
                        Appointment__c con = (Appointment__c)qr.records[i];

                        try
                        {

                            #region Get Appointment details for this Id

                            if (con.Id != null)
                            {
                                pndInfo.Appt_id = con.Id;
                            }
                            else
                            {
                                continue;
                            }

                            if (con.Appointment_Date__c != null)
                            {
                                con.Appointment_Date__cSpecified = true;
                                DateTime dt = (DateTime)con.Appointment_Date__c;
                                pndInfo.Appt_date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                                //pndInfo.Appt_date = common.Convert_USA_date(dt);
                            }
                            else
                            {
                                arrList = null;
                                continue;
                            }

                            string Timing = "";

                            if (con.From__c != null)
                            {
                                Timing = con.From__c;
                            }
                            else
                            {
                                Timing = "";
                            }
                            if (con.To__c != null)
                            {
                                Timing += " - " + con.To__c;
                            }
                            else
                            {
                                
                                Timing = "";
                            }

                            if (Timing != "")
                            {
                                pndInfo.Appt_time = Timing;
                            }




                            #endregion

                            #region Get Property information for this Order ID

                            if (con.Property_name__c != null)
                            {
                                pndInfo.Prop_name = con.Property_name__c;
                            }
                            else
                            {
                                pndInfo.Prop_name = "";
                            }

                            string address = "";
                            if (con.Property__r.Address_Line_1__c != null)
                            {
                                address = con.Property__r.Address_Line_1__c;
                            }
                            else
                            {
                                address = "";
                            }
                            if (con.Property__r.City__c != null)
                            {
                                address += "<br/>" + con.Property__r.City__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.State__c != null)
                            {
                                address += " , " + con.Property__r.State__c;
                            }
                            else
                            {
                                address += "";
                            }
                            if (con.Property__r.Zip_Code__c != null)
                            {
                                address += " " + con.Property__r.Zip_Code__c;
                            }
                            else
                            {
                                address += "";
                            }

                            if (address != "")
                            {
                                pndInfo.Prop_address = address;
                            }
                            else
                            {
                                pndInfo.Prop_address = "";
                            }

                            #endregion

                            #region Get Prospect(Client) information for this Property and AgentID
                            if (con.Case__r.Contact.Name != null)
                            {
                                pndInfo.Client_name = con.Case__r.Contact.Name;
                            }
                            else
                            {
                                pndInfo.Client_name = "";
                            }

                            if (con.Case__r.Contact.Phone != null)
                            {
                                pndInfo.Client_phone = con.Case__r.Contact.Phone;
                            }
                            else
                            {
                                pndInfo.Client_phone = "";
                            }

                            // change on 11 Dec 2013

                            if (con.Case__r.Contact.MobilePhone != null)
                            {
                                pndInfo.Client_mobile = con.Case__r.Contact.MobilePhone;
                            }
                            else
                            {
                                pndInfo.Client_mobile = "";
                            }

                            //
                            if (con.Case__r.Contact.Email != null)
                            {
                                pndInfo.Client_email = con.Case__r.Contact.Email;
                            }
                            else
                            {
                                pndInfo.Client_email = "";
                            }

                            #endregion
                            
                            //add this instance into the arraylist
                            arrList.Add(pndInfo);

                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                arrList = null;
            }



        }
        catch (Exception ex)
        {
            arrList = null;
        }

        

        return arrList;

    }

}