﻿using System;
using System.Data;
using System.Configuration;

using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Web.Services.Protocols;
using WebReference;

/// <summary>
/// Login to SalesForce Account by Providing user id and password with security token
/// </summary>
public class login
{
    
    public static SforceService bi;
    public static LoginResult lr;
	public login()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private static string sf_user = "", sf_pass = "", sf_key = "";
  

    private static void get_SF_User()
    {
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "select createdBy, SF_userId, SF_pass, sf_sec_key, isActive from api_config where createdBy=0 and isActive=1";
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    sf_user = Convert.ToString(dr["SF_userId"]);
                    sf_pass = Convert.ToString(dr["SF_pass"]);
                    sf_key = Convert.ToString(dr["sf_sec_key"]);
                }

            }
            else
            {
                sf_user = "";
                
            }

        }
        catch (Exception ex)
        {
            sf_user = ""; 
            sf_pass = "";
            sf_key = "";
        }
        finally
        {
            con.Close();
        }
    }
    /// <summary>
    /// Login Method to SalesForce Account by Providing user id and password with security token, after successful login it return true
    /// </summary>
    public static bool loginnow()
    {

        //Get login information from the Database
        get_SF_User();

        if (sf_user != "")
        {
        }
        else
        {
            return false;
        }

        if (sf_pass != "" && sf_key != "")
        {
        }
        else
        {
            return false;
        }

        // Console.Write("Enter username: ");
        string username = sf_user.Trim(); //"sharad@aromatyk.com"; 
        //Console.ReadLine();
        
        //  Console.Write("Enter password: ");
        string password = string.Concat(sf_pass.Trim(), sf_key.Trim());
        
        //sf_pass.Trim() + sf_key.Trim(); //"salesforce_1jMt63HMxytg0YxtcnL05qpYc";

        //Console.ReadLine();
        // Create a service object
        bi = new SforceService();
        // Timeout after a minute * 30= 30 minut
        bi.Timeout = (1800000);
        // Try logging in
        
        lr = new LoginResult();
        try
        {
            //Console.WriteLine("LOGGING IN NOW..."); 
            lr = bi.login(username, password);
        }
        // ApiFault is a proxy stub generated from the WSDL contract when
        // the web service was imported
        catch (SoapException e)
        {
            /*
            // Write the fault code to the console
            Console.WriteLine(e.Code);
            // Write the fault message to the console
            Console.WriteLine("An unexpected error has occurred: " + e.Message);// Write the stack trace to the console
            Console.WriteLine(e.StackTrace);
            // Return False to indicate that the login was not successful
             */
            return false;
        }
        // Check if the password has expired
        if (lr.passwordExpired)
        {
           // Console.WriteLine("An error has occurred. Your password has expired.");
            return false;
        }
        /** Once the client application has logged in successfully, it will use
        * the results of the login call to reset the endpoint of the service
        * to the virtual server instance that is servicing your organization
        */
        bi.Url = lr.serverUrl;/** The sample client application now has an instance of the SforceService
            * that is pointing to the correct endpoint. Next, the sample client
            * application sets a persistent SOAP header (to be included on all
            * subsequent calls that are made with SforceService) that contains the
            * valid sessionId for our login credentials. To do this, the sample
            * client application creates a new SessionHeader object and persist it to
            * the SforceService. Add the session ID returned from the login to the
            * session header
            */
        bi.SessionHeaderValue = new SessionHeader();
        bi.SessionHeaderValue.sessionId = lr.sessionId;
        // Return true to indicate that we are logged in, pointed
        // at the right URL and have our security token in place.
        return true;
    }
}