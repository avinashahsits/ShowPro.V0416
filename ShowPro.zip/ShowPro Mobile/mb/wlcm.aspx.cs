﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_wlcm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

        if (Session["ssnUserId"] != null)
        {

            Response.Redirect("myappts.aspx");
        }
        else
        {
            Session.Abandon();
            Response.Redirect("Default.aspx");
        }

        if (Session["globalMessText"] != "")
        {
            globalMessage.InnerHtml = Convert.ToString(Session["globalMessText"]);
            Session["globalMessText"] = null;
        }
        else
        {
            globalMessage.InnerHtml = "";
        }


    }
}