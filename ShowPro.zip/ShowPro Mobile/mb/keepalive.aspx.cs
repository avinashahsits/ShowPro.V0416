﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_keepalive : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Random rm = new Random();
        //Response.Write(rm.Next(1, 300));
        // string js = "<script type=\"text/javascript\"> alert('" + rm.Next(1, 300) + "')    </script>";
        // Response.Write(js);

        Session["ssnRandom"] = rm.Next(1, 300).ToString().Trim();

        //Response.Headers.Add("keepitlive", Convert.ToString(Session["ssnRandom"]));
        string abc = rm.Next(1, 300).ToString().Trim();
        Response.CacheControl = "no-cache";
        Response.AddHeader("Pragma", "no-cache");
        Response.AddHeader("Pragmasdsada", abc);
        Response.AddHeader("Refresh", Convert.ToString((Session.Timeout * 60) - 10));


        //DateTime dt = new DateTime(1985, 5, 25);
        //Response.Write(Math.Floor(DateTime.Today.Subtract(dt).TotalDays / 365.25));


    }
}