﻿function standardAjax(inputvar,url,divid1,divid2,AjaxThread,Formatting)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;
  document.getElementById(divid2).innerHTML='<center class="ajaxLoad">Please wait...</center>'; //'<center><img src=/IMAGES/progress.gif /></center>';
  document.getElementById(divid1).style.display='block';
  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, true);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function () {
       //alert(http[AjaxThread].readyState);
       //alert(http[AjaxThread].status);
       //Call a function when the state changes.
       if (http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) {
          // alert('ok');
           str = http[AjaxThread].responseText;
          // alert(str);

           document.getElementById(divid2).innerHTML = str;
       }

   }
    http[AjaxThread].send(params);
   }

//----------
function myAjax(inputvar,url,divid1,divid2,AjaxThread,Formatting)
 {
    //alert(url);
  var str,arr1,arr2,final_string;
  var http=new Array;
  document.getElementById(divid2).innerHTML='<center class="ajaxLoad">Please wait...</center>';  
  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url,false);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	  str=http[AjaxThread].responseText;
	  //alert(str);
	   if(str==null)
	   {
	    document.getElementById(divid2).innerHTML="";	    
	   }
	   else
	    {	   
	    //alert('ij');var di= document.getElementById(divid2);di.innerHTML=str;
	   // alert(di);
	    document.getElementById(divid2).innerHTML=str;	  
	    // alert('k');
	    }
	     
       }
     }
    http[AjaxThread].send(params);

}


function mbAjax() {
    $.ajax({ url: "soon.htm",
        dataType: "jsonp",
        jsonpCallback: 'successCallback',
        async: true,
        beforeSend: function () {
            $.mobile.showPageLoadingMsg(true);
        },
        complete: function () {
            $.mobile.hidePageLoadingMsg();
        },
        success: function (result) {
            ajax.parseJSONP(result);
        },
        error: function (request, error) {
            alert('Network error has occurred please try again!');
        }
    });         
}

