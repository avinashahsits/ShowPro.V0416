﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class mb_pendingrequestDetails : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList pndgs = new ArrayList();

        if (Session["ssnPendingAppts"] != null)
        {
            pndgs = (ArrayList)Session["ssnPendingAppts"];
        }
        else
        {
            return;
        }
        string id = ""; //"a0Ci0000002GlxkEAC";


        id = GetParam("p1").Trim();

        if (id == "")
        {
            return;
        }


         var query = from getPendingAppointmentSF.PendingApptInfo appts in pndgs
                    // where appts.Appt_id = id
                     select appts;

         int counter = 1;
        string output = " <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 98%;\">";

         foreach (getPendingAppointmentSF.PendingApptInfo apptInfo in query)
         {
             string AjaxDivId = "ajx_" + counter;
             string ap_id = apptInfo.Appt_id;

             if (ap_id == id)
             {
                 output += "<tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px; border-bottom:1px solid #eee;\">" +
                        apptInfo.Appt_date + " </td> </tr>" +
                "<tr> <td colspan=\"4\">" +
                        apptInfo.Appt_time + "  </td> </tr>" +
                "<tr>  <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                        apptInfo.Prop_name + " <br />" +
                        apptInfo.Prop_address + " </td></tr>" +
                "<tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                    apptInfo.Client_name + "<br />";

                 if (apptInfo.Client_phone != "")
                 {
                     output += apptInfo.Client_phone + " <br />";
                 }
                 if (apptInfo.Client_mobile != "")
                 {
                     output += apptInfo.Client_mobile + " <br />";
                 }
                 else
                 {
                     output += "";
                 }
                 output += apptInfo.Client_email + " </td>  </tr><tr><td><br/></td></tr>" +
                "<tr>" +
                 "   <td align=\"center\" valign=\"top\" colspan=\"4\" style=\"border-bottom: 0px solid #ccc;\">" +
                        "<div id=\"" + AjaxDivId + "\"> <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"6\">" +
                         "<tr><td><a href=\"#\" data-role=\"button\"  data-mini=\"true\"  style=\"color:green;\"  onclick=\"appt_acpt('" + apptInfo.Appt_id + "','" + AjaxDivId + "');\">Accept </a>  </td> </tr>" +
                          "<tr><td><a href=\"modifyaccept.aspx?p1=" + apptInfo.Appt_id.Trim() + "\" data-role=\"button\"  data-ajax=\"false\"  data-mini=\"true\" style=\"color:green;\">Modify Time & Accept </a>  </td> </tr>" +
                          "<tr><td><p style=\"border:1px solid gray; word-spacing:0px; width:100%; height:2px;\"></p></td> </tr>" +
                           "<tr><td> <a href=\"#\" data-role=\"button\"  data-mini=\"true\" style=\"color:#AB3F3F;\" onclick=\"appt_cancel('" + apptInfo.Appt_id + " ','" + AjaxDivId + "');\"> Home Leased</a> </td></tr>" +
                          
                           "<tr> <td> <a href=\"#\" data-role=\"button\"  data-mini=\"true\" style=\"color:#AB3F3F;\" onclick=\"appt_reject('" + apptInfo.Appt_id + "','" + AjaxDivId + "');\">Reject For Rescheduling </a></td></tr>" +
                            "<tr><td><br/></td></tr>" +
                          //"<tr><td><ul data-role=\"listview\" data-count-theme=\"c\" data-inset=\"false\"><li><a href=\"pendingrequest.aspx\" data-ajax=\"false\">Next Invite</a></li></ul></td></tr>" +
                           "</table>  </div>   </td> </tr>";
                 counter++;
             }

         }
         output += "</table>";

         main_Div.InnerHtml = output;

    }
}