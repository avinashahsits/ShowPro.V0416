﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_Default_availa_rdirect : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string sucessmess = GetParam("p1");
        string errmess = GetParam("p2");

        string display = getmess(sucessmess, errmess);

        if (display != "")
        {

            string button = "<br/><div><center><table><tr><td style=\"width:80px;\"></td><td style=\"width:140px;\" align=\"right\"><input type=\"button\" id=\"txtbutton\" name=\"Ok\" value=\"Ok\" data-mini=\"true\" data-ajax=\"false\" onclick=\"toRedirect();\"></td> </tr></table></center></div>";
            messagedisplayfor.InnerHtml = "<br />" + display + button;
        }
        
    }

    public static string getmess(string sucess,string error)
    {
        string result = "";
        string displaysucess="",displayerror="", monday = "", tuesday = "", wed = "", thurd = "", frid = "", satrday = "", sunday = "";

        if (sucess != "")
        {
            string[] success = sucess.Split(',');

            foreach (string day in success)
            {
                if (day == "Monday")
                {
                    monday = messagedisplay(day, "Successfully Updated");
                }
                if (day == "Tuesday")
                {
                    tuesday = messagedisplay(day, "Successfully Updated");
                }
                if (day == "Wednesday")
                {
                    wed = messagedisplay(day, "Successfully Updated");
                }
                if (day == "Thursday")
                {
                    thurd = messagedisplay(day, "Successfully Updated");
                }
                if (day == "Friday")
                {
                    frid = messagedisplay(day, "Successfully Updated");
                }
                if (day == "Saturday")
                {
                    satrday = messagedisplay(day, "Successfully Updated");
                }
                if (day == "Sunday")
                {
                    sunday = messagedisplay(day, "Successfully Updated");
                }
            }
         
        }

        // error mess

        if (error != "")
        {
           
            string[] errormess = error.Split(',');

            foreach (string dayend in errormess)
            {
                if (dayend == "Monday")
                {
                    monday = "";
                    monday = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
                if (dayend == "Tuesday")
                {
                    tuesday = "";
                    tuesday = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
                if (dayend == "Wednesday")
                {
                    wed = "";
                    wed = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
                if (dayend == "Thursday")
                {
                    thurd = "";
                    thurd = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
                if (dayend == "Friday")
                {
                    frid = "";
                    frid = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
                if (dayend == "Saturday")
                {
                    satrday = "";
                    satrday = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
                if (dayend == "Sunday")
                {
                    sunday = "";
                    sunday = errormessagedisplay(dayend, "Unsuccessfully!!");
                }
            }
           
           
        }
        displaysucess = monday + tuesday + wed + thurd + frid + satrday + sunday;
        result = displaysucess;

        return result;
        
    }

    public static string messagedisplay(string day, string message)
    {
        string result = "<center><table id=\"Sunday\" style=\"margin-right:10px;\" runat=\"server\">" +
                   " <tr><td <td style=\"width:90px;\" align=\"left\"><label style=\"font-size: smaller; font-weight: bold;\">" + day + "</label></td>" +
                   "<td <td  align=\"left\"><label style=\"font-size: smaller; color: green; font-weight: bold;\">" +
                   "" + message + "</label></td></table></center>";
        return result;
    }
    public static string errormessagedisplay(string day, string message)
    {
        string result = "<center><table  id=\"Sunday\" style=\"margin-right:10px;\" runat=\"server\">" +
                   " <tr><td style=\"width:90px;\" align=\"left\"><label style=\"font-size: smaller; font-weight: bold;\">" + day + "</label></td>" +
                   "<td <td  align=\"left\"><label style=\"font-size: smaller; color: red; font-weight: bold;\">" +
                   "" + message + "</label></td></table></center>";
        return result;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("myappts.aspx");
    }
}