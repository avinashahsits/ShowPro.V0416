﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using WebReference;

public partial class mb_myappts : System.Web.UI.Page
{
    string displayTodaysException = "";
   

    ArrayList apptDates = new ArrayList(); //Appointment Dates    
    ArrayList exepDates = new ArrayList(); //Exception Dates    
    ArrayList offDates = new ArrayList();   //day off dates list

    ArrayList exception_fromtime = new ArrayList();
    ArrayList datecheck = new ArrayList();


    public class slotInformation
    {
        public string id { get; set; }
        public int slotType { get; set; } //1 for exception, 2 for Leave(Day off), 3 for Appointments
        public string slotTime { get; set; }
        public DateTime slotDate { get; set; }
        public string displayInfo { get; set; }
        public string fromtime { get; set; }
    }

    Dictionary<String, slotInformation> slotData = new Dictionary<string, slotInformation>();
    Dictionary<String, slotInformation> aaptData = new Dictionary<string, slotInformation>();

    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList pndgs = new ArrayList();
        string con_id = Convert.ToString(Session["ssnUserId"]);

        //changes on 10 Oct 2013.
        if (con_id != "")
        {
            pndgs = getAppointments.upcommingAppointments(con_id); //getAppointments.acceptedAppointments(con_id);
        }
        else
        {
            Response.Redirect("logout.aspx");
        }

        Session["ssnAcceptedAppts"] = pndgs;




        getDayOffDateByID(con_id);



        if (getAcceptedAppt())
        {

        }
        else
        {
            main_Div.InnerHtml = "You have no appointment.";
        }

    }


    private bool displayException(DateTime pDate,out int count, ref string pExHtml)
    {
        bool result = false;

        count = 0;

        if (slotData.Count > 0)
        {
            pExHtml = "";
        }
        else
        {
            pExHtml = "";
            return false;
        }
        foreach (KeyValuePair<string, slotInformation> slot in slotData)
        {
            slotInformation slt = slot.Value;

            try
            {
                DateTime slotDate = slt.slotDate;
                string time = slt.fromtime;

                string dates = Convert.ToString(slt.slotDate.ToShortDateString());

                DateTime checkapp_date = Get_datetime_to_string(time, dates);

                //if (slotDate == DateTime.Today)
                if (checkapp_date == pDate)
                {
                    count++;
                    //string id = GetParam("p1").Trim();
                    //string date = GetParam("p2").Trim();
                    //string time = GetParam("p3").Trim();

                    string queryString = "p1=" + slt.id + "&p2=" + slt.slotDate.ToShortDateString() + "&p3=" + slt.slotTime.Replace("<br/>", " - ");

                    string data = "<table cellpadding=\"8\" cellspacing=\"0\" ><tr>" +
                    "<td align=\"left\" valign=\"top\" style=\"color:red; font-weight:bold; font-size:11px; width:135px;\">" + " " + slotDate.ToShortDateString() + "<br/>" +
                       slt.slotTime +
                    "</td> <td align=\"left\" valign=\"middle\" style=\"color:red; font-weight:bold; font-size:11px;\">" + slt.displayInfo +
                    "</td></tr></table>";
                    string html = "<li><a style=\"border:1px solid #fff;\" href=\"cancelexp.aspx?" + queryString + "\" data-ajax=\"false\">" + data + "</a></li>";

                    pExHtml += html;
                    result = true;
                }
            }
            catch (Exception ex)
            {

            }
        }

        return result;
    }

    private bool displayException(DateTime pDate, ref string pExHtml)
    {
        bool result = false;

        if (slotData.Count > 0)
        {
            pExHtml = "";
        }
        else
        {
            pExHtml = "";
            return false;
        }
        foreach (KeyValuePair<string, slotInformation> slot in slotData)
        {
            slotInformation slt = slot.Value;

            try
            {
                DateTime slotDate = slt.slotDate;
                string time = slt.fromtime;

                string dates = Convert.ToString(slt.slotDate.ToShortDateString());

                DateTime checkapp_date = Get_datetime_to_string(time, dates);

                //if (slotDate == DateTime.Today)
                if (checkapp_date == pDate)
                {
                    //string id = GetParam("p1").Trim();
                    //string date = GetParam("p2").Trim();
                    //string time = GetParam("p3").Trim();

                    string queryString = "p1=" + slt.id + "&p2=" + slt.slotDate.ToShortDateString() + "&p3=" + slt.slotTime.Replace("<br/>", " - ");

                    string data = "<table cellpadding=\"8\" cellspacing=\"0\" ><tr>" +
                    "<td align=\"left\" valign=\"top\" style=\"color:red; font-weight:bold; font-size:11px; width:135px;\">" + " " + slotDate.ToShortDateString() + "<br/>" +
                       slt.slotTime +
                    "</td> <td align=\"left\" valign=\"middle\" style=\"color:red; font-weight:bold; font-size:11px;\">" + slt.displayInfo +
                    "</td></tr></table>";
                    string html = "<li><a style=\"border:1px solid red;\" href=\"cancelexp.aspx?" + queryString + "\" data-ajax=\"false\">" + data + "</a></li>";

                    pExHtml += html;
                    result = true;
                }
            }
            catch (Exception ex)
            {

            }
        }

        return result;
    }

    public bool getDayOffDateByID(string pID)
    {
        bool result = false;
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }

        QueryResult qr = null;

        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            string sql = "SELECT Id, av_Date__c,av_Status__c,av_start_Time__c,av_End_Time__c  FROM Unvailability__c where Saved_by__c='" + pID + "' and  av_Date__c >= today and av_Status__c in (1,2) order by NoFrom__c desc";

            //string sql = "SELECT Id, av_Date__c,av_Status__c,av_start_Time__c,av_End_Time__c  FROM Unvailability__c where Saved_by__c='" + pID + "' and  av_Date__c >= today and av_Status__c in (1,2) order by  av_Date__c asc";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Unvailability__c con = (Unvailability__c)qr.records[i];
                        int av_status = 0;
                        string object_id = "", date = "", slotFrom = "", slotTo = "";

                        if (con.Id != null)
                        {
                            object_id = con.Id;
                        }
                        else
                        {
                            return false;
                        }

                        //con.NoFrom__c;
                        //con.NoTo__c;
                        //con.av_start_Time__c;
                        //con.av_End_Time__c;

                        con.av_Date__cSpecified = true;
                        date = Convert.ToString(con.av_Date__c);

                        DateTime dt = Convert.ToDateTime(date);

                        date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                        //result.Add(date);

                        slotInformation slt = new slotInformation();

                        if (con.av_Status__c != null)
                        {
                            con.av_Status__cSpecified = true;
                            av_status = (int)con.av_Status__c;
                        }


                        if (con.av_start_Time__c != null)
                        {
                            slotFrom = con.av_start_Time__c;
                            slt.fromtime = slotFrom;
                        }

                        if (con.av_End_Time__c != null)
                        {
                            slotTo = con.av_End_Time__c;
                        }

                       

                        if (av_status == 2) /// Get Exception dates by providing Contact id and Status=2 to Un-Availability custom object
                        {
                            slt.id = object_id;
                            slt.displayInfo = "Unavailable";

                            if (con.av_Date__c != null)
                            {
                                con.av_Date__cSpecified = true;
                                slt.slotDate = (DateTime)con.av_Date__c;
                            }
                            else
                            {

                            }

                            slt.slotType = 1;
                            slt.slotTime = slotFrom + " - " + slotTo;

                            if (slotFrom == "0" && slotTo == "0")
                            {
                                slt.slotTime = "All Day";
                            }

                            try
                            {
                                slotData.Add(object_id, slt);
                            }
                            catch (Exception ex)
                            {

                            }

                            exepDates.Add(date);
                        }
                        else if (av_status == 1)/// Get Day Off dates...by providing Contact id and Status=1
                        {
                            //slt.id = object_id;
                            //slt.displayInfo = "Unavailable";
                            //slt.slotDate = date;
                            //slt.slotType = 2;
                            //slt.slotTime = "";// slotFrom + "<br/>" + slotTo;

                            slt.id = object_id;
                            slt.displayInfo = "Unavailable";

                            if (con.av_Date__c != null)
                            {
                                con.av_Date__cSpecified = true;
                                slt.slotDate = (DateTime)con.av_Date__c;
                            }
                            else
                            {

                            }

                            slt.slotType = 1;
                            //slt.slotTime = slotFrom + " - " + slotTo;

                            slt.slotTime = "All Day";

                            

                            try
                            {
                                slotData.Add(object_id, slt);
                            }
                            catch (Exception ex)
                            {

                            }

                            offDates.Add(date);
                        }


                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }

                result = true;
            }
            else
            {
                result = false;

            }
        }
        catch (Exception ex)
        {
            result = false;
        }

        return result;
    }

    private bool getAcceptedAppt_for_new()
    {
        bool result = false;
        try
        {
            Dictionary<DateTime, string> forDate = new Dictionary<DateTime, string>();

            

            string html = "<ul data-role=\"listview\" data-count-theme=\"c\" data-inset=\"false\">";

            int haveUp = 0;
            string ExceptOutput = "";

            #region Get Date for Appointment and Exception


            ArrayList pndgs = new ArrayList();
            if (Session["ssnAcceptedAppts"] != null)
            {
                pndgs = (ArrayList)Session["ssnAcceptedAppts"];
            }
            else
            {
                return result;
            }

            //Changes on 25 Oct. 2013 for Sorting
            

            //end changes

            var query = from getAppointments.AcceptedApptInfo appts in pndgs
                        select appts;


            foreach (getAppointments.AcceptedApptInfo apptInfo in query)
            {
                DateTime date_app = apptInfo.Appt_date;
                try
                {
                    forDate.Add(date_app, date_app.ToShortDateString());


                }
                catch (Exception ex)
                {

                }
            }



            foreach (KeyValuePair<string, slotInformation> slot in slotData)
            {
                slotInformation slt = slot.Value;
                DateTime date_exec = slt.slotDate;

                try
                {
                    forDate.Add(date_exec, date_exec.ToShortDateString());
                }
                catch (Exception ex)
                {

                }

            }

            

            #endregion
            
            // Change On 11 nov 2013

            #region for Shorting date bind list after clear date and rebind date with shorting

            var list = forDate.Keys.ToList();
            list.Sort();

            int c = 0;
            // Loop through keys.
            foreach (var key in list)
            {
                //Console.WriteLine("{0}: {1}", key, forDate[key]);

                if (c == 0)
                {
                    forDate.Clear();
                    c++;
                }

                forDate.Add(key, key.ToShortDateString());
            }
            #endregion

            #region Get All Appointment and Exception Upto Date

            int isFirstRows = 0;
            foreach (KeyValuePair<DateTime, string> date in forDate)
            {
                if (isFirstRows == 0)
                {
                    isFirstRows++;
                }
                else
                {
                    html += "<br/>";
                }
                foreach (getAppointments.AcceptedApptInfo apptInfo in query)
                {

                    if (date.Key == apptInfo.Appt_date)
                    {
                        string check_status = apptInfo.Appt_status;
                        string app_status = "";

                        if (check_status == "Accepted")
                        {
                            app_status = "<span style=\"color:green; font-weight:bold; font-size:11px;\">" + apptInfo.Appt_status + "</span>";
                        }
                        else if (check_status == "Rejected")
                        {
                            app_status = "<span style=\"color:red; font-weight:bold; font-size:11px;\">" + apptInfo.Appt_status + "</span>";
                        }
                        else if (check_status == "Invited")
                        {
                            app_status = "<span style=\"color:orange; font-weight:bold; font-size:11px;\">" + apptInfo.Appt_status + "</span>";
                        }

                        string appdetail = "<table cellpading=\"4\" cellspacing=\"0\"><tr><td style=\" font-size:11px; width:200px;\" valign=\"top\" >" + apptInfo.Appt_date.ToShortDateString() + " <br />"
                            + "<span style=\" font-size:11px;\">" + apptInfo.Appt_time + "</span><br/><span style=\" font-size:11px; color:#01A7FF;\">Todd Katler111</span></td>" +
                                            "<td style=\" font-size:11px;\">" + apptInfo.Prop_name + "<br />" + apptInfo.Prop_address + "<br/><span>" + app_status + "</span> </td></tr> </table>";

                        if (check_status == "Invited")
                        {
                            html += "<li><a href=\"pendingrequestDetails.aspx?p1=" + apptInfo.Appt_id + "\" data-ajax=\"false\">" + appdetail + "</a></li>";
                        }
                        else
                        {
                            html += "<li><a href=\"apptdetail.aspx?p1=" + apptInfo.Appt_id + "\" data-ajax=\"false\">" + appdetail + "</a></li>";
                        }
                        haveUp++;
                    }
                }



                if (displayException(date.Key, ref ExceptOutput))
                {
                    displayTodaysException = ExceptOutput;
                    haveUp++;
                }
                else
                {
                    displayTodaysException = "";

                }
                html += displayTodaysException;

            }

            #endregion


            if (haveUp == 0)
            {

                html += "You don't have any upcoming appointment.";
            }


            result = true;
            main_Div.InnerHtml = html;


        }
        catch (Exception ex)
        {

        }
        finally
        {

        }

        return result;
    }

    private bool getAcceptedAppt()
    {
        bool result = false;
        try
        {
            Dictionary<DateTime, string> forDate = new Dictionary<DateTime, string>();

            ArrayList FullDateList = new ArrayList();
            ArrayList FullDateList_except = new ArrayList();


            string html = "<ul data-role=\"listview\" data-count-theme=\"c\" data-inset=\"false\">";

            int haveUp = 0;
            string ExceptOutput = "";

            #region Get Date for Appointment and Exception

            bool itHaveAppt = false;

            ArrayList pndgs = new ArrayList();
            if (Session["ssnAcceptedAppts"] != null)
            {
                pndgs = (ArrayList)Session["ssnAcceptedAppts"];
                itHaveAppt = true;
            }
            else
            {
                itHaveAppt = false;
                //return result;
            }

            //Changes on 25 Oct. 2013 for Sorting


            //end changes
            //var query = new getAppointments.AcceptedApptInfo;
            if (itHaveAppt==true)
            {
                #region For Appointments

               var  query = from getAppointments.AcceptedApptInfo appts in pndgs
                            select appts;


                foreach (getAppointments.AcceptedApptInfo apptInfo in query)
                {
                    string time = apptInfo.Appt_time_from;

                    string date = Convert.ToString(apptInfo.Appt_date.ToShortDateString());

                    //string maindate = date +" "+ time;


                    DateTime date_app = apptInfo.Appt_date;
                    DateTime dtfull = Get_datetime_to_string(time, date);
                    try
                    {
                        //changes on 7 March
                        //forDate.Add(dtfull, dtfull.ToString());
                        forDate.Add(dtfull, dtfull.ToShortDateString());

                    }
                    catch (Exception ex)
                    {

                    }


                }

                #endregion    
            }


            if (slotData!=null&&slotData.Count>0)
            {

                #region for Exception
                foreach (KeyValuePair<string, slotInformation> slot in slotData)
                {

                    slotInformation slt = slot.Value;

                    DateTime date_exec = slt.slotDate;
                    DateTime dtfull_exception = new DateTime();
                    string exce_time = slt.fromtime;
                    if (exce_time != "")
                    {


                        string exce_date = Convert.ToString(slt.slotDate.ToShortDateString());

                        dtfull_exception = Get_datetime_to_string(exce_time, exce_date);

                        try
                        {
                            forDate.Add(dtfull_exception, dtfull_exception.ToString());
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                    else
                    {
                        forDate.Add(date_exec, date_exec.ToShortDateString());
                    }



                }
                #endregion
    
            }



            var list = forDate.Keys.ToList();
            list.Sort();

            int c = 0;
            // Loop through keys.
            foreach (var key in list)
            {
                //Console.WriteLine("{0}: {1}", key, forDate[key]);

                if (c == 0)
                {
                    forDate.Clear();
                    c++;
                }

                //forDate.Add(key, key.ToString());

                //changes on 7 March
                //forDate.Add(dtfull, dtfull.ToString());
                forDate.Add(key, key.ToShortDateString());
            }
           
            #endregion


   

            #region Get All Appointment and Exception Upto Date

            int isFirstRows = 0;

            Dictionary<DateTime, bool> dateHeader = new Dictionary<DateTime, bool>();

            //Create a different dictionary to store the counts.
            Dictionary<string, int> valCount = new Dictionary<string, int>();
            //Iterate through the values, setting count to 1 or incrementing current count.
            foreach (string i in forDate.Values)
                if (valCount.ContainsKey(i))
                    valCount[i]++;
                else
                    valCount[i] = 1;




            foreach (KeyValuePair<DateTime, string> date in forDate)
            {
                bool dateDisplayed = false;

                DateTime currentDate =DateTime.Parse( date.Key.ToShortDateString());
                int Count = 0;

               // var qer = forDate.Values.SelectMany(s => s).GroupBy(s => s)
               //             .Select(g => new { Value = g.First(), Count = g.Count() });


                

               
                if (isFirstRows == 0)
                {
                    
                   isFirstRows++;
                }
                else
                {
                    //if (dateDisplayed == false)
                    //{
                    //    html += "<span>" + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + "</span>";
                    //    dateDisplayed = true;
                    //}
                    //html += "<br/>";
                }

                //maindate = date.Key.ToShortDateString();

               


                // day/month names
               // String.Format("{0:ddd, MMM d, yyyy}", currentDate);    // "Sun, Mar 9, 2008"
               // String.Format("{0:dddd, MMMM d, yyyy}", currentDate);  // "Sunday, March 9, 2008"
                string AppointmentDisplay = "";
                int apptCount = 0;


                if (itHaveAppt == true)
                {
                 //   #region For Appointments

                    var query = from getAppointments.AcceptedApptInfo appts in pndgs
                                select appts;


                    foreach (getAppointments.AcceptedApptInfo apptInfo in query)
                    {

                        

                        string time = apptInfo.Appt_time_from;

                        string dates = Convert.ToString(apptInfo.Appt_date.ToShortDateString());

                        DateTime checkapp_date = Get_datetime_to_string(time, dates);

                        //if (dateDisplayed == false)
                        //{
                        //    html += "<span>" + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + "</span>";
                        //    dateDisplayed = true;
                        //}
                        
                        if (date.Key == checkapp_date)
                        {
                            apptCount++;

                            string check_status = apptInfo.Appt_status;
                            string app_status = "";

                            if (check_status == "Accepted")
                            {
                                app_status = "<span style=\"color:green; font-weight:bold; font-size:11px;\">" + apptInfo.Appt_status + "</span>";
                            }
                            else if (check_status == "Rejected")
                            {
                                app_status = "<span style=\"color:red; font-weight:bold; font-size:11px;\">" + apptInfo.Appt_status + "</span>";
                            }
                            else if (check_status == "Invited")
                            {
                                app_status = "<span style=\"color:orange; font-weight:bold; font-size:11px;\">" + apptInfo.Appt_status + "</span>";
                            }

                            string appdetail = "<table cellpading=\"4\" cellspacing=\"0\"><tr><td style=\" font-size:11px; width:200px;\" valign=\"top\" >" + apptInfo.Appt_date.ToShortDateString() + " <br />"
                                + "<span style=\" font-size:11px;\">" + apptInfo.Appt_time + "</span><br/><span style=\" font-size:11px; color:#01A7FF;\"> " + apptInfo.Client_name + "</span></td>" +
                                                "<td style=\" font-size:11px;\">" + apptInfo.Prop_name + "<br />" + apptInfo.Prop_address + "<br/><span>" + app_status + "</span> </td></tr> </table>";

                            if (check_status == "Invited")
                            {
                                AppointmentDisplay += "<li><a href=\"pendingrequestDetails.aspx?p1=" + apptInfo.Appt_id + "\" data-ajax=\"false\">" + appdetail + "</a></li>";
                            }
                            else
                            {
                                AppointmentDisplay += "<li><a href=\"apptdetail.aspx?p1=" + apptInfo.Appt_id + "\" data-ajax=\"false\">" + appdetail + "</a></li>";
                            }
                            haveUp++;

                        }

                    }//Appointment foreach for this date end here


                  

                }


                int exceptioncount = 0;
                if (displayException(date.Key,out exceptioncount, ref ExceptOutput))
                //if (displayException(date.Key, ref ExceptOutput))
                {
                    //if (dateDisplayed == false)
                    //{
                    //    html += "<span>" + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + "</span>";
                    //    dateDisplayed = true;
                    //}
                    displayTodaysException = ExceptOutput;
                    haveUp++;
                }
                else
                {
                    displayTodaysException = "";

                }

                if (dateDisplayed == false && !dateHeader.ContainsKey(currentDate))
                {



                    string counts = "<span class=\"ui-li-count\" style=\" color:red; border:1px solid rgb(140, 198, 63);-webkit-font-smoothing: antialiased;\">" + valCount[currentDate.ToShortDateString()] + "</span>";

                   // string apptsCountgol = "<span  style=\" color:red; border:1px solid rgb(140, 198, 63);-webkit-font-smoothing: antialiased;\">" + apptCount + "</span>";
                   // string exceptsCountgol = "<span class=\"ui-li-count\" style=\" color:red; border:1px solid rgb(140, 198, 63);-webkit-font-smoothing: antialiased;\">" + exceptioncount + "</span>";

                    //html += "<div style=\"background-color:#8D8D8D; color:#fff;  text-align: center; width:100%; height:27px; align:center; vertical-align:central; padding-top:5px; \">" 
                    //  + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) +counts+ "</div>";

                    html += " <li style=\"background-color:#8D8D8D; color:#fff; font-size: small; font-weight:normal;  text-align: center; -webkit-font-smoothing: antialiased;\">"
                        + String.Format("{0:dddd}", currentDate) + " " + currentDate.ToShortDateString() + "</li>";
                        // + String.Format("{0:dddd}", currentDate) + " " + String.Format("{0:MM/dd/yyyy}", currentDate) + "</li>";
                        //   + String.Format("{0:dddd}", currentDate) +" " + String.Format("{0:MM/dd/yyyy}", currentDate) + counts + "</li>";
                     //  + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + apptsCountgol + exceptsCountgol + "</li>";

                    dateDisplayed = true;
                    try
                    {
                        dateHeader.Add(currentDate, true);
                    }
                    catch (Exception)
                    {
                    }
                }


                //string displayDateSlot = String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + html + displayTodaysException;

                //html = String.Format("{0:dddd, MMMM d, yyyy}", currentDate)+html;
                //html += "<span>" + String.Format("{0:dddd, MMMM d, yyyy}", currentDate)+"</span>";

                html += AppointmentDisplay;
                html += displayTodaysException;

               
               

              


            }//date foreach end here

            #endregion


            if (haveUp == 0)
            {

                html += "You don't have any upcoming appointment.";
            }


            result = true;
            main_Div.InnerHtml = html;


        }
        catch (Exception ex)
        {

        }
        finally
        {

        }

        return result;
    }

    private string GetNumberFromTime1(string pStart)
    {
        string result = "00,00,00";
        //120200 : hh mm ss

        if (pStart == "")
        {
            return "06,00,00";
        }

        switch (pStart)
        {
            #region Converting Time to Number

            case "6:00 a.m.":
            case "35":
                result = "06,00,00"; break;

            case "6:30 a.m.":
            case "34":
                result = "06,30,00"; break;

            case "7:00 a.m.":
            case "33":
                result = "07,00,00"; break;

            case "7:30 a.m.":
            case "32":
                result = "07,30,00"; break;

            case "8:00 a.m.":
            case "31":
                result = "08,00,00"; break;


            case "8:30 a.m.":
            case "30":
                result = "08,30,00"; break;


            case "9:00 a.m.":
            case "29":
                result = "09,00,00"; break;


            case "9:30 a.m.":
            case "28":
                result = "09,30,00"; break;


            case "10:00 a.m.":
            case "27":
                result = "10,00,00"; break;


            case "10:30 a.m.":
            case "26":
                result = "10,30,00"; break;


            case "11:00 a.m.":
            case "25":
                result = "11,00,00"; break;


            case "11:30 a.m.":
            case "24":
                result = "11,30,00"; break;


            case "12:00 p.m.":
            case "23":
                result = "12,00,00"; break;


            case "12:30 p.m.":
            case "22":
                result = "12,30,00"; break;


            case "1:00 p.m.":
            case "21":
                result = "13,00,00"; break;


            case "1:30 p.m.":
            case "20":
                result = "13,30,00"; break;


            case "2:00 p.m.":
            case "19":
                result = "14,00,00"; break;

            case "2:30 p.m.":
            case "18":
                result = "14,30,00"; break;


            case "3:00 p.m.":
            case "17":
                result = "15,00,00"; break;


            case "3:30 p.m.":
            case "16":
                result = "15,30,00"; break;


            case "4:00 p.m.":
            case "15":
                result = "16,00,00"; break;


            case "4:30 p.m.":
            case "14":
                result = "16,30,00"; break;


            case "5:00 p.m.":
            case "13":
                result = "17,00,00"; break;


            case "5:30 p.m.":
            case "12":
                result = "17,30,00"; break;


            case "6:00 p.m.":
            case "11":
                result = "18,00,00"; break;


            case "6:30 p.m.":
            case "10":
                result = "18,30,00"; break;


            case "7:00 p.m.":
            case "9":
                result = "19,00,00"; break;


            case "7:30 p.m.":
            case "8":
                result = "19,30,00"; break;


            case "8:00 p.m.":
            case "7":
                result = "200000"; break;


            case "8:30 p.m.":
            case "6":
                result = "20,30,00"; break;


            case "9:00 p.m.":
            case "5":
                result = "21,00,00"; break;


            case "9:30 p.m.":
            case "4":
                result = "21,30,00"; break;


            case "10:00 p.m.":
            case "3":
                result = "22,00,00"; break;


            case "10:30 p.m.":
            case "2":
                result = "22,30,00"; break;


            case "11:00 p.m.":
            case "1":
                result = "23,00,00"; break;


            default:
                result = "06,00,00";
                break;
            #endregion
        }

        return result;
    }

    private DateTime Get_datetime_to_string(string pStart,string date)
    {
        //string result = "00,00,00";
        DateTime result = new DateTime();
        //120200 : hh mm ss


        DateTime dtCustom = DateTime.Parse(date);




        //var newDate = ""; //dtCustom.Date + new TimeSpan(11, 30, 55);


       


        if (pStart == "")
        {
            result = new DateTime();
        }

        switch (pStart)
        {
            #region Converting Time to Number

            case "6:00 a.m.":
            case "35":
               var newDate = dtCustom.Date + new TimeSpan(06, 00, 00);
                //result = Convert.ToDateTime(date + "06,00,00");
               result = (DateTime)newDate;
                break;

            case "6:30 a.m.":
            case "34":

                 var newDate1 = dtCustom.Date + new TimeSpan(06, 30, 00);
                //result = Convert.ToDateTime(date + "06,00,00");
                result = (DateTime)newDate1;
               // result = Convert.ToDateTime(date +"06,30,00"); break;
                break;
            case "7:00 a.m.":
            case "33":

                 var newDate2 = dtCustom.Date + new TimeSpan(07, 00, 00);
                //result = Convert.ToDateTime(date + "06,00,00");
                result = (DateTime)newDate2;

                //result = Convert.ToDateTime(date +"07,00,00"); 
                break;

            case "7:30 a.m.":
            case "32":
                var newDate3 = dtCustom.Date + new TimeSpan(07, 30, 00);
                //result = Convert.ToDateTime(date + "06,00,00");
                result = (DateTime)newDate3;
              //  result = Convert.ToDateTime(date +"07,30,00"); 
                break;

            case "8:00 a.m.":
            case "31":
                var newDate4 = dtCustom.Date + new TimeSpan(08, 00, 00);
                result = (DateTime)newDate4;
               // result = Convert.ToDateTime(date +"08,00,00"); 
                break;


            case "8:30 a.m.":
            case "30":

                var newDate5 = dtCustom.Date + new TimeSpan(08, 30, 00);
                result = (DateTime)newDate5;
                //result = Convert.ToDateTime(date +"08,30,00"); 
                break;


            case "9:00 a.m.":
            case "29":

                var newDate6 = dtCustom.Date + new TimeSpan(09, 00, 00);
                 result = (DateTime)newDate6;
                //result = Convert.ToDateTime(date +"09,00,00");
                break;


            case "9:30 a.m.":
            case "28":

                var newDate7 = dtCustom.Date + new TimeSpan(09, 30, 00);
                 result = (DateTime)newDate7;
                //result = Convert.ToDateTime(date +"09,30,00");
                break;


            case "10:00 a.m.":
            case "27":

                var newDate8 = dtCustom.Date + new TimeSpan(10, 00, 00);
                 result = (DateTime)newDate8;
               //result = Convert.ToDateTime(date +"10,00,00");
                break;


            case "10:30 a.m.":
            case "26":

                var newDate9 = dtCustom.Date + new TimeSpan(10, 30, 00);
                 result = (DateTime)newDate9;
                //result = Convert.ToDateTime(date +"10,30,00");
                break;


            case "11:00 a.m.":
            case "25":
                var newDate10 = dtCustom.Date + new TimeSpan(11, 00, 00);
                 result = (DateTime)newDate10;
               // result = Convert.ToDateTime(date +"11,00,00");
                break;


            case "11:30 a.m.":
            case "24":
                var newDate11 = dtCustom.Date + new TimeSpan(11, 30, 00);
                 result = (DateTime)newDate11;
                //result = Convert.ToDateTime(date +"11,30,00");
                break;


            case "12:00 p.m.":
            case "23":
                var newDate12= dtCustom.Date + new TimeSpan(12, 00, 00);
                 result = (DateTime)newDate12;
                //result = Convert.ToDateTime(date +"12,00,00");
                
                break;


            case "12:30 p.m.":
            case "22":
                var newDate13 = dtCustom.Date + new TimeSpan(12, 30, 00);
                 result = (DateTime)newDate13;
                //result = Convert.ToDateTime(date +"12,30,00");
                break;


            case "1:00 p.m.":
            case "21":
                var newDate14 = dtCustom.Date + new TimeSpan(13, 00, 00);
                 result = (DateTime)newDate14;
                //result = Convert.ToDateTime(date +"13,00,00");
                break;


            case "1:30 p.m.":
            case "20":
                var newDate15 = dtCustom.Date + new TimeSpan(13, 30, 00);
                 result = (DateTime)newDate15;
                //result = Convert.ToDateTime(date +"13,30,00"); 
                break;


            case "2:00 p.m.":
            case "19":
                var newDate16 = dtCustom.Date + new TimeSpan(14, 00, 00);
                 result = (DateTime)newDate16;
               // result = Convert.ToDateTime(date +"14,00,00"); 
                break;

            case "2:30 p.m.":
            case "18":
                var newDate17 = dtCustom.Date + new TimeSpan(14, 30, 00);
                 result = (DateTime)newDate17;
               // result = Convert.ToDateTime(date +"14,30,00");
               break;


            case "3:00 p.m.":
            case "17":
               var newDate18 = dtCustom.Date + new TimeSpan(15, 00, 00);
                 result = (DateTime)newDate18;
                //result = Convert.ToDateTime(date +"15,00,00"); 
                break;


            case "3:30 p.m.":
            case "16":
                var newDate19 = dtCustom.Date + new TimeSpan(15, 30, 00);
                 result = (DateTime)newDate19;
                //result = Convert.ToDateTime(date +"15,30,00");
                break;


            case "4:00 p.m.":
            case "15":
                var newDate20 = dtCustom.Date + new TimeSpan(16, 00, 00);
                 result = (DateTime)newDate20;
                //result = Convert.ToDateTime(date +"16,00,00"); 
                break;


            case "4:30 p.m.":
            case "14":
                var newDate21 = dtCustom.Date + new TimeSpan(16, 30, 00);
                 result = (DateTime)newDate21;
               // result = Convert.ToDateTime(date +"16,30,00");
               break;


            case "5:00 p.m.":
            case "13":
               var newDate22 = dtCustom.Date + new TimeSpan(17, 00, 00);
                 result = (DateTime)newDate22;
                //result = Convert.ToDateTime(date +"17,00,00");
                break;


            case "5:30 p.m.":
            case "12":
                var newDate23 = dtCustom.Date + new TimeSpan(17, 30, 00);
                 result = (DateTime)newDate23;
                //result = Convert.ToDateTime(date +"17,30,00");
                break;


            case "6:00 p.m.":
            case "11":
                var newDate24 = dtCustom.Date + new TimeSpan(18, 00, 00);
                 result = (DateTime)newDate24;
                //result = Convert.ToDateTime(date +"18,00,00"); 
                break;


            case "6:30 p.m.":
            case "10":
                var newDate25 = dtCustom.Date + new TimeSpan(18, 30, 00);
                 result = (DateTime)newDate25;
                //result = Convert.ToDateTime(date +"18,30,00");
                break;


            case "7:00 p.m.":
            case "9":
                var newDate26 = dtCustom.Date + new TimeSpan(19, 00, 00);
                 result = (DateTime)newDate26;
                //result = Convert.ToDateTime(date +"19,00,00");
                break;


            case "7:30 p.m.":
            case "8":
                var newDate27 = dtCustom.Date + new TimeSpan(19, 30, 00);
                 result = (DateTime)newDate27;
                //result = Convert.ToDateTime(date +"19,30,00");
                break;


            case "8:00 p.m.":
            case "7":
                var newDate28 = dtCustom.Date + new TimeSpan(20, 00, 00);
                 result = (DateTime)newDate28;
                //result = Convert.ToDateTime(date +"20,00,00"); 
                break;


            case "8:30 p.m.":
            case "6":
                var newDate29 = dtCustom.Date + new TimeSpan(20, 30, 00);
                 result = (DateTime)newDate29;
               // result = Convert.ToDateTime(date +"20,30,00");
               break;


            case "9:00 p.m.":
            case "5":
               var newDate30 = dtCustom.Date + new TimeSpan(21, 00, 00);
                 result = (DateTime)newDate30;
                //result = Convert.ToDateTime(date +"21,00,00");
                break;


            case "9:30 p.m.":
            case "4":
                var newDate31 = dtCustom.Date + new TimeSpan(21, 30, 00);
                 result = (DateTime)newDate31;
                //sult = Convert.ToDateTime(date +"21,30,00"); 
                break;


            case "10:00 p.m.":
            case "3":
                var newDate32 = dtCustom.Date + new TimeSpan(22, 00, 00);
                 result = (DateTime)newDate32;
                //result = Convert.ToDateTime(date +"22,00,00");
                break;


            case "10:30 p.m.":
            case "2":
                var newDate33 = dtCustom.Date + new TimeSpan(22, 30, 00);
                 result = (DateTime)newDate33;
                //result = Convert.ToDateTime(date +"22,30,00");
                break;


            case "11:00 p.m.":
            case "1":
                var newDate34 = dtCustom.Date + new TimeSpan(23, 00, 00);
                 result = (DateTime)newDate34;
                //result = Convert.ToDateTime(date +"23,00,00"); 
                break;


            default:
                //result = Convert.ToDateTime(date +"06,00,00");
                result = Convert.ToDateTime(date);
                break;
            #endregion
        }

        return result;
    }
}