﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using WebReference;

public partial class mb_mycal : System.Web.UI.Page
{
    Hashtable AppointmentList;

    ArrayList apptDates = new ArrayList(); //Appointment Dates    
    ArrayList exepDates = new ArrayList(); //Exception Dates    
    ArrayList offDates = new ArrayList();   //day off dates list

   public class slotInformation
    {
       public string id { get; set; }
       public int slotType { get; set; } //1 for exception, 2 for Leave(Day off), 3 for Appointments
       public string slotTime { get; set; }
       public DateTime slotDate { get; set; }
       public string displayInfo { get; set; }
    }

    Dictionary<String, slotInformation> slotData = new Dictionary<string, slotInformation>();
    Dictionary<String, slotInformation> aaptData = new Dictionary<string, slotInformation>();


    public string displayTodaysException = "", displayAppointments = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //  HolidayList = Getholiday();
        }

        //run each time otherwise calendar will throw an error
        //AppointmentList = GetAppointmentDates();

        //for (int i = 1; i < 4; i++)
        //{
        //    string date = "";
        //    DateTime dt = DateTime.Now.AddDays(i);
        //    date = dt.Month + "/" + dt.Day + "/" + dt.Year;
        //    apptDates.Add(date);
        //}


        /*

        for (int i = 2; i < 4; i++)
        {
            string date = "";
            DateTime dt = DateTime.Now.AddDays(i);
            date = dt.Month + "/" + dt.Day + "/" + dt.Year;
            exepDates.Add(date);          
            
        }
        for (int i = 4; i < 6; i++)
        {
            string date = "";
            Random rm = new Random();

            DateTime dt = DateTime.Now.AddDays(i + rm.Next(1, 20));
            date = dt.Month + "/" + dt.Day + "/" + dt.Year;
            offDates.Add(date);
        }
        */
        if (Session["ssnUserId"] != null)
        {
            string con_id = Convert.ToString(Session["ssnUserId"]);
            getDayOffDateByID(con_id);
            getAppointmentByID(con_id);
        }
        Tdsettimeoff.Visible = false;
    }

    private bool displayException(DateTime pDate,ref string pExHtml)
    {
        bool result = false;

        if (slotData.Count > 0)
        { }
        else
        {
            pExHtml = "";
            return false;
        }
        foreach (KeyValuePair<string, slotInformation> slot in slotData)
        {
            slotInformation slt = slot.Value;

            try
            {
                DateTime slotDate = slt.slotDate;

                //if (slotDate == DateTime.Today)
                if (slotDate == pDate)
                {
                    //string id = GetParam("p1").Trim();
                    //string date = GetParam("p2").Trim();
                    //string time = GetParam("p3").Trim();

                    string queryString = "p1=" + slt.id + "&p2=" + slt.slotDate.ToShortDateString() + "&p3=" + slt.slotTime.Replace("<br/>", " - ");

                    string html = "<tr> <td align=\"left\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\"> <img src=\"../mb/images/ex.gif\" /> </td>" +
                    "<td align=\"left\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\">" +
                       slt.slotTime +
                    "</td> <td align=\"left\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\"> <a style=\"text-decoration:none; color:black; font-size: small;font-weight: normal;\" data-ajax=\"false\" href=\"cancelexp.aspx?" + queryString + "\">" +
                        slt.displayInfo +
                    "</a></td>  <td align=\"right\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\">" +
                      "  <a href=\"cancelexp.aspx?" + queryString + "\"  data-ajax=\"false\" style=\"text-decoration: none;\">></a>   </td>    </tr>";

                    pExHtml += html;
                    result = true;
                }
            }
            catch (Exception ex)
            { }
        }

        return result;
    }

    /// <summary>
    /// Get Day Off dates...by providing Contact id and Status=3
    /// </summary>
    /// 


    public bool getDayOffDateByID(string pID)
    {
        bool result = false;
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }

        QueryResult qr = null;

        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            string sql = "SELECT Id, av_Date__c,av_Status__c,av_start_Time__c,av_End_Time__c  FROM Unvailability__c where Saved_by__c='" + pID + "' and av_Status__c in (2,3) order by av_Date__c desc";
            qr = login.bi.query(sql);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Unvailability__c con = (Unvailability__c)qr.records[i];
                        int av_status = 0;
                        string object_id = "", date = "", slotFrom = "", slotTo = "";

                        if (con.Id != null)
                        {
                            object_id = con.Id;
                        }
                        else
                        {
                            return false;
                        }

                        //con.NoFrom__c;
                        //con.NoTo__c;
                        //con.av_start_Time__c;
                        //con.av_End_Time__c;

                        con.av_Date__cSpecified = true;
                        date = Convert.ToString(con.av_Date__c);

                        DateTime dt = Convert.ToDateTime(date);

                        date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                        //result.Add(date);

                        if (con.av_Status__c != null)
                        {
                            con.av_Status__cSpecified = true;
                            av_status = (int)con.av_Status__c;
                        }


                        if (con.av_start_Time__c != null)
                        {
                            slotFrom = con.av_start_Time__c;
                        }

                        if (con.av_End_Time__c != null)
                        {
                            slotTo = con.av_End_Time__c;
                        }

                        slotInformation slt = new slotInformation();

                        if (av_status == 2) /// Get Exception dates by providing Contact id and Status=2 to Un-Availability custom object
                        {
                            slt.id = object_id;
                            slt.displayInfo = "Unavailable";

                            if (con.av_Date__c != null)
                            {
                                con.av_Date__cSpecified = true;
                                slt.slotDate = (DateTime)con.av_Date__c;
                            }
                            else
                            {
                               
                            }

                            slt.slotType = 1;
                            slt.slotTime = slotFrom + "<br/>" + slotTo;

                            try
                            {
                                slotData.Add(object_id, slt);
                            }
                            catch(Exception ex)
                            {

                            }

                            exepDates.Add(date);
                        }
                        else if (av_status == 3)/// Get Day Off dates...by providing Contact id and Status=3
                        {
                            //slt.id = object_id;
                            //slt.displayInfo = "Unavailable";
                            //slt.slotDate = date;
                            //slt.slotType = 2;
                            //slt.slotTime = "";// slotFrom + "<br/>" + slotTo;
                            
                            offDates.Add(date);
                        }


                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }

                result = true;
            }
            else
            {
                result = false;

            }
        }
        catch (Exception ex)
        {
            result = false;
        }

        return result;
    }





    private Hashtable GetAppointmentDates()
    {
        Hashtable appts = new Hashtable();

        /*
        holiday["1/1/2013"] = "New Year";
       
        */


        appts["10/2/2013"] = " <img src=\"../mb/images/li_2.gif\" />"; //"Janmashtami";
        appts["10/3/2013"] = " <img src=\"../mb/images/li_2.gif\" />"; //"Janmashtami"; //" <img src=\"http://localhost:3714/HTML5/mb/images/li_2.gif\" /> <img src=\"http://localhost:3714/HTML5/mb/images/li_2.gif\" />";


        return appts;
    }

    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
       

        #region Display tooltip and Make clikable to whole cell

        e.Cell.ToolTip = e.Day.Date.ToLongDateString();
        //e.Cell.Text = e.Day.DayNumberText;
        //e.Cell.Style.Add("cursor", "pointer");
        // e.Cell.Attributes.Add("onclick", "window.location='datefromCal.aspx?dater=" + e.Day.Date.ToString("MM/dd/yyyy") + "'");
        // e.Cell.CssClass = "igmc_IGDay";
        #endregion

        #region Previous month days, to disable click link on the dates
        if (e.Day.IsOtherMonth)
        {
            // e.Cell.Controls.RemoveAt(0);
            // e.Cell.Text = e.Day.DayNumberText;
            e.Day.IsSelectable = false;

        }
        #endregion

       /*
        #region Display Holiday list using HashTable
        if (AppointmentList[e.Day.Date.ToShortDateString()] != null)
        {
            //Literal literal1 = new Literal();
            //literal1.Text = e.Day.DayNumberText;// "<br/>";
            //e.Cell.Controls.Add(literal1);


            //e.Cell.Text = e.Day.DayNumberText;

            Label label1 = new Label();
            label1.Text = (string)AppointmentList[e.Day.Date.ToShortDateString()];
            label1.Font.Size = new FontUnit(FontSize.Small);
            e.Cell.Controls.Add(label1);
            //e.Cell.Text += e.Day.DayNumberText;
        }
        #endregion
        */

        #region Display Appointments
        if (apptDates!=null && apptDates.Contains(e.Day.Date.ToShortDateString()))
        {
           

            Label label1 = new Label();
            label1.Text = " <img src=\"../mb/images/li_2.gif\" />"; //(string)AppointmentList[e.Day.Date.ToShortDateString()];
            label1.Font.Size = new FontUnit(FontSize.Small);
            e.Cell.Controls.Add(label1);
            //e.Cell.Text += e.Day.DayNumberText;
        }
        #endregion
        #region Display Exception
        if (exepDates != null && exepDates.Contains(e.Day.Date.ToShortDateString()))
        {
            //Literal literal1 = new Literal();
            //literal1.Text = e.Day.DayNumberText;// "<br/>";
            //e.Cell.Controls.Add(literal1);


            //e.Cell.Text = e.Day.DayNumberText;

            Label label1 = new Label();
            label1.Text = " <img src=\"../mb/images/ex.gif\" />"; //(string)AppointmentList[e.Day.Date.ToShortDateString()];
            label1.Font.Size = new FontUnit(FontSize.Small);
            e.Cell.Controls.Add(label1);
            //e.Cell.Text += e.Day.DayNumberText;
        }
        #endregion

        #region Display Day Off
        if (offDates != null && offDates.Contains(e.Day.Date.ToShortDateString()))
        {
            e.Cell.BackColor = System.Drawing.Color.IndianRed;
            e.Cell.Text = e.Day.DayNumberText;
            e.Cell.ForeColor = System.Drawing.Color.White;
            e.Cell.Font.Bold = false;
            e.Cell.Font.Size = new FontUnit(FontSize.Small);
        }
        #endregion


    }


    public bool getAppointmentByID(string pID)
    {
        bool result = false;
        try
        {
            ArrayList pndgs = new ArrayList();
            string con_id = Convert.ToString(Session["ssnUserId"]);

            pndgs = getAppointments.AppointmentsForCalendar(con_id);


            if (pndgs != null)
            {
                Session["ssnCalendarAppts"] = pndgs;                
            }

            var query = from getAppointments.AcceptedApptInfo appts in pndgs
                        select appts;

            foreach (getAppointments.AcceptedApptInfo apptInfo in query)
            {
                slotInformation slt = new slotInformation();

                slt.id = apptInfo.Appt_id;
                slt.slotDate = apptInfo.Appt_date;
                slt.slotTime = apptInfo.Appt_time;
                slt.slotType = 3;

                slt.displayInfo = apptInfo.Prop_name + "<br/> " + apptInfo.Prop_address;

                string date = "";
                DateTime dt = apptInfo.Appt_date;
                date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                apptDates.Add(date);

                try
                {
                    aaptData.Add(apptInfo.Appt_id, slt);
                }
                catch (Exception ex)
                {

                }
            }

            result = true;
        }
        catch (Exception ex)
        {
            result = false;
        }

        return result;
    }

    private bool displayAppointment(DateTime pDate, ref string pExHtml)
    {
        bool result = false;

        if (aaptData.Count > 0)
        { }
        else
        {
            pExHtml = "";
            return false;
        }
        foreach (KeyValuePair<string, slotInformation> slot in aaptData)
        {
            slotInformation slt = slot.Value;

            try
            {
                DateTime slotDate = slt.slotDate;

                //if (slotDate == DateTime.Today)
                if (slotDate == pDate)
                {
                    string html = "<tr> <td align=\"left\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\"> <img src=\"../mb/images/li_2.gif\" /> </td>" +
                    "<td align=\"left\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\">" +
                       slt.slotTime +
                    "</td> <td align=\"left\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\"> <a style=\"text-decoration:none; color:black; font-size: small;font-weight: normal;\" data-ajax=\"false\" href=\"apptdetailcal.aspx?p1=" + slt.id + "\"> " +
                        slt.displayInfo +
                    "</a></td>  <td align=\"right\" valign=\"top\" style=\"border-bottom: 1px solid #ccc;\">" +
                      "  <a href=\"apptdetailcal.aspx?p1=" + slt.id + "\" style=\"text-decoration: none;\">></a>   </td>    </tr>";

                    pExHtml += html;
                    result = true;
                }
            }
            catch (Exception ex)
            { }
        }

        return result;
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        //Tdsettimeoff.Visible = true;

        string today = DateTime.Today.ToShortDateString();
       

        DateTime selectedDate = Calendar1.SelectedDate;


        if (selectedDate < DateTime.Today)
        {

            Tdsettimeoff.Visible = false;

        }
        else
        {
            Tdsettimeoff.Visible = true;
            string select_Date = String.Format("{0:MM/dd/yyyy}", selectedDate); //common.Convert_USA_date(selectedDate);

            set_time.HRef = "settimeoff.aspx?p1=" + select_Date;

        }
        string ExceptOutput = "";
        if (displayException(selectedDate, ref ExceptOutput))
        {
            displayTodaysException = ExceptOutput;
        }
        else
        {
            displayTodaysException = "";
        }

        string apptOutput = "";

        if (displayAppointment(selectedDate, ref apptOutput))
        {
            displayAppointments = apptOutput;
        }
        else
        {
            displayAppointments = "";
        }


    }
}