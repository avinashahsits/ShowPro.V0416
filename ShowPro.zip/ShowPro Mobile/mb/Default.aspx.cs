﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebReference;
using System.Collections;


public partial class mb_Default : System.Web.UI.Page
{
    //public static string globalMessText = "";

    
    protected void Page_Load(object sender, EventArgs e)
    {

        //Gets login details from cookie 09/04/2014
        getCookieValues(); 
       
        string DashBoardPage = "";
        if (Session["ssnUserType"] != null)
        {
            DashBoardPage = Convert.ToString(Session["ssnUserType"]);

            if (DashBoardPage != "" && DashBoardPage == "1")
            {
                //got to Admin page
                Response.Redirect("wlcm.aspx");
            }
            else if (DashBoardPage != "" && DashBoardPage == "2")
            {
                //got to user page
                Response.Redirect("wlcm.aspx");
            }
            else
            {   //got to user page
                Response.Redirect("wlcm.aspx");
            }
        }

        if (Session["globalMessText"] != "")
        {
            globalMessage.InnerHtml = Convert.ToString(Session["globalMessText"]);
            Session["globalMessText"] = null;
        }
        else
        {
            globalMessage.InnerHtml = "";
        }
    }
    protected void getCookieValues()
    {
        try
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["UserName"] != null && Request.Cookies["Password"] != null)
                {
                    txtEmail.Text = Request.Cookies["UserName"].Value;
                    txtCode.Attributes["value"] = Request.Cookies["Password"].Value;
                    rememberMebox.Checked = true;
                }
            }
        }
        catch (Exception ex) { }
        
    }
    protected void setCookieValues()
    {
        try
        {
            if (rememberMebox.Checked)
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddYears(1);
                Response.Cookies["Password"].Expires = DateTime.Now.AddYears(1);
            }
            else
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
            }
            Response.Cookies["UserName"].Value = txtEmail.Text.Trim();
            Response.Cookies["Password"].Value = txtCode.Text.Trim();
        }
        catch (Exception ex) { }
   }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //Set Login details in cookie 09/04/2014
        setCookieValues();    

        //globalError.InnerHtml = "Serror";
        string emailid_txt = txtEmail.Text.Trim();

        if (emailid_txt != "")
        {
            string Contact_id = getDataFromSF.getIDbyEmail(emailid_txt);
            if (Contact_id != "")
            {

                string pinCode = txtCode.Text.Trim();

                if (isValidUser(Contact_id, pinCode))
                {
                    if (Session["ssnUserId"] != null)
                    {
                        string con_id = Convert.ToString(Session["ssnUserId"]);


                        //add email id and name here from SF
                        
                        ArrayList ContactData = new ArrayList();
                        ContactData = getDataFromSF.getContactDataByID(con_id);

                        string emailid = ContactData[0].ToString();
                        string name = ContactData[1].ToString();
                        string checkdefaultability = "";
                        #region Check Deaultability
                        try
                        {
                            checkdefaultability = ContactData[2].ToString();
                        }
                        catch (Exception)
                        {

                        }
                        #endregion

                        if (checkdefaultability != "")
                        {
                            Session["checkDefaultAvailability"] = checkdefaultability;
                        }
                        else
                        {
                            Session["checkDefaultAvailability"] = null;
                        }

                        if (emailid != "")
                        {
                            Session["ssnUserEmailId"] = emailid;
                        }
                        else
                        {
                            Session["ssnUserEmailId"] = null;
                        }
                        if (name != "")
                        {
                            Session["ssnUserFullName"] = name;
                        }
                        else
                        {
                            Session["ssnUserFullName"] = null;
                        }
                        if (Session["ssnDFdates"] != null)
                        {
                            Session["ssnDFdates"] = null;
                        }
                        // add new session for check Default Availability

                        

                        string DashBoardPage = "";
                        if (Session["ssnUserType"] != null)
                        {
                            DashBoardPage = Convert.ToString(Session["ssnUserType"]);

                            if (DashBoardPage != "" && DashBoardPage == "1")
                            {
                                //got to Admin page
                                Response.Redirect("wlcm.aspx");
                            }
                            else if (DashBoardPage != "" && DashBoardPage == "2")
                            {
                                //got to user page
                                Response.Redirect("wlcm.aspx");
                            }
                            else
                            {   //got to user page
                                Response.Redirect("wlcm.aspx");
                            }
                        }


                    }
                    else
                    {
                        if (Session["ssnDFdates"] != null)
                        {
                            Session["ssnDFdates"] = null;
                        }
                        Session["ssnUserType"] = null;
                        Session["ssnSecToken"] = null;
                        globalError.InnerHtml = "Please try again!";
                        return;
                    }


                }
                else
                {
                    if (Session["ssnDFdates"] != null)
                    {
                        Session["ssnDFdates"] = null;
                    }
                    Session["ssnSecToken"] = null;
                    globalError.InnerHtml = "Your password is incorrect!";
                }
            }
            else
            {
                if (Session["ssnDFdates"] != null)
                {
                    Session["ssnDFdates"] = null;
                }
                Session["ssnSecToken"] = null;
                globalError.InnerHtml = "Please try again!";
            }
        }
        else
        {
            if (Session["ssnDFdates"] != null)
            {
                Session["ssnDFdates"] = null;
            }
            return;
        }
    }

    private bool isValidUser(string pSF_id, string pPinCode)
    {
        bool result = false;
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "select  auto_id,security_token, salesforce_obj_id, acc_type from user_master where" +
                " salesforce_obj_id='" + pSF_id + "' and security_pin='" + pPinCode + "' and acc_status='1'";

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    Session["ssnUserId"] = Convert.ToString(dr["salesforce_obj_id"]);
                    Session["ssnUserType"] = Convert.ToString(dr["acc_type"]);
                    Session["ssnSecToken"] = Convert.ToString(dr["security_token"]);
                    result = true;
                }

            }
            else
            {
                Session["ssnUserId"] = null;
                Session["ssnUserType"] = null;
                result = false;

            }

        }
        catch (Exception ex)
        {
            result = false;

        }
        finally
        {
            con.Close();
        }
        return result;
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin/adminpanel.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("passresend.aspx");
    }
}