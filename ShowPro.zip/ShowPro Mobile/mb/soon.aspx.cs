﻿using System;

public partial class mb_soon : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string appt_id = GetParam("p1");
        string abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #f46020; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Coming soon!</span> <sup>Under Construction</sup> </div> </div> </center>";
        if (appt_id != "")
        {
        }
        else
        {
            appt_id = "asdsadsadsadasdsad";
        }
        Response.Write(abc);
    }
}