﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class mb_menu : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    Hashtable HolidayList;
    protected void Page_Load(object sender, EventArgs e)
    {
        HolidayList = Getholiday();
        //Calendar1.Caption = "Calender - Author:AnyOneHome";

        //Calendar1.FirstDayOfWeek = FirstDayOfWeek.Sunday;
        //Calendar1.NextPrevFormat = NextPrevFormat.ShortMonth;
        //Calendar1.TitleFormat = TitleFormat.Month;
        //Calendar1.ShowGridLines = true;
        //Calendar1.DayStyle.Height = new Unit(50);
        //Calendar1.DayStyle.Width = new Unit(150);
        //Calendar1.DayStyle.HorizontalAlign = HorizontalAlign.Center;
        //Calendar1.DayStyle.VerticalAlign = VerticalAlign.Middle;
        //Calendar1.OtherMonthDayStyle.BackColor = System.Drawing.Color.AliceBlue;
    }


    private Hashtable Getholiday()
    {
        Hashtable holiday = new Hashtable();
       
        /*
        holiday["1/1/2013"] = "New Year";
        holiday["1/5/2013"] = "Guru Govind Singh Jayanti";
        holiday["1/8/2013"] = "Muharam (Al Hijra)";
        holiday["1/14/2013"] = "Pongal";
        holiday["1/26/2013"] = "Republic Day";
        holiday["2/23/2013"] = "Maha Shivaratri";
        holiday["3/10/2013"] = "Milad un Nabi (Birthday of the Prophet";
        holiday["3/21/2013"] = "Holi";
        holiday["3/21/2013"] = "Telugu New Year";
        holiday["4/3/2013"] = "Ram Navmi";
        holiday["4/7/2013"] = "Mahavir Jayanti";
        holiday["4/10/2013"] = "Good Friday";
        holiday["4/12/2013"] = "Easter";
        holiday["4/14/2013"] = "Tamil New Year and Dr Ambedkar Birth Day";
        holiday["5/1/2013"] = "May Day";
        holiday["5/9/2013"] = "Buddha Jayanti and Buddha Purnima";
        holiday["6/24/2013"] = "Rath yatra";
        holiday["8/13/2013"] = "Krishna Jayanthi";
        */


        holiday["8/14/2013"] = " <img src=\"http://localhost:3714/HTML5/mb/images/li_2.gif\" />"; //"Janmashtami";
        holiday["8/15/2013"] = " <img src=\"http://localhost:3714/HTML5/mb/images/li_2.gif\" /> <img src=\"http://localhost:3714/HTML5/mb/images/li_2.gif\" />";
        
        /*
        holiday["8/19/2013"] = "Parsi New Year";
        holiday["8/23/2013"] = "Vinayaka Chaturthi";
        holiday["9/2/2013"] = "Onam";
        holiday["9/5/2013"] = "Teachers Day";
        holiday["9/21/2013"] = "Ramzan";
        holiday["9/27/2013"] = "Ayutha Pooja";
        holiday["9/28/2013"] = "Vijaya Dasami (Dusherra)";
        holiday["10/2/2013"] = "Gandhi Jayanti";
        holiday["10/17/2013"] = "Diwali & Govardhan Puja";
        holiday["10/19/2013"] = "Bhaidooj";
        holiday["11/2/2013"] = "Guru Nanak Jayanti";
        holiday["11/14/2013"] = "Children's Day";
        holiday["11/28/2013"] = "Bakrid";
        holiday["12/25/2013"] = "Christmas";
        holiday["12/28/2013"] = "Muharram";
        */
        return holiday;
    }


    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {

        #region Change the ToolTip text as required!
        if (e.Day.IsWeekend)
        {
            //e.Day.v = false;
        }
        else
        {
            e.Cell.ToolTip = e.Day.Date.ToLongDateString();

            e.Cell.Text = e.Day.DayNumberText;
           
            e.Cell.Style.Add("cursor", "pointer");
            e.Cell.Attributes.Add("onclick", "window.location='datefromCal.aspx?dater=" + e.Day.Date.ToString("MM/dd/yyyy") + "'");
            e.Cell.CssClass = "igmc_IGDay";
        }
        #endregion





        #region Previous month days, to disable click link on the dates
        if (e.Day.IsOtherMonth)
        {
           // e.Cell.Controls.RemoveAt(0);
           // e.Cell.Text = e.Day.DayNumberText;
            e.Day.IsSelectable = false;

        }
        #endregion

        #region background color change
        // Display vacation dates in yellow boxes with purple borders.
        Style vacationStyle = new Style();
        vacationStyle.BackColor = System.Drawing.Color.Yellow;
        vacationStyle.BorderColor = System.Drawing.Color.Purple;
        vacationStyle.BorderWidth = 3;

        // Display weekend dates in green boxes.
        Style weekendStyle = new Style();
        weekendStyle.BackColor = System.Drawing.Color.LightYellow;
        weekendStyle.Font.Bold = false;
        //weekendStyle.Font.Size = new FontUnit(FontSize.Small);
        weekendStyle.CssClass = "igmc_IGDay";

        //weekendStyle.AddAttributesToRender()    

        if ((e.Day.Date >= new DateTime(2013, 04, 23)) &&
            (e.Day.Date <= new DateTime(2013, 04, 30)))
        {
            // Apply the vacation style to the vacation dates.
             e.Cell.ApplyStyle(vacationStyle);
        }
        else if (e.Day.IsWeekend && !e.Day.IsOtherMonth)//to prevent remove method of OtherMonth Date
        {
            // Apply the weekend style to the weekend dates.
            e.Cell.ApplyStyle(weekendStyle);
           

            //e.Cell.Controls.RemoveAt(0);
            //e.Cell.Text = e.Day.DayNumberText;


            //Un commetn this to make this cell Enable for Events

            //e.Day.IsSelectable = false;

            e.Cell.ToolTip = "Weekend";
            
        }

        if (e.Day.IsToday)
        {

            e.Cell.ToolTip = e.Day.Date.ToLongDateString();

            e.Cell.Text = e.Day.DayNumberText;

            e.Cell.Style.Add("cursor", "pointer");
            e.Cell.Attributes.Add("onclick", "window.location='datefromCal.aspx?dater=" + e.Day.Date.ToString("MM/dd/yyyy") + "'");
            
            //e.Cell.CssClass = "igmc_IGDay";

           // e.Cell.BackColor = System.Drawing.Color.Orange;
            e.Cell.BackColor = System.Drawing.Color.WhiteSmoke;
            e.Cell.ForeColor = System.Drawing.Color.Orange;
            e.Cell.BorderWidth = 1;
            e.Cell.BorderStyle = BorderStyle.Solid;
            e.Cell.BorderColor = System.Drawing.Color.Orange;
        }

        DateTime dt = e.Day.Date;
        string dayName = String.Format("{0:dddd}", dt);

        ArrayList DayNames = new ArrayList();
        DayNames.Add("Monday");
        DayNames.Add("Tuesday");
        DayNames.Add("Friday");

        weekendStyle.BackColor = System.Drawing.Color.Aquamarine;
        if (DayNames.Contains(dayName))
        {
           // e.Cell.ApplyStyle(weekendStyle);
           // e.Cell.CssClass = "mixBk";
        }

        #endregion


        #region Disable/Enable a day
        DateTime myAppointment = new DateTime(2012, 03, 01);
        if (e.Day.Date == myAppointment)
        {
            //  e.Day.IsSelectable = true;
        }
        else
        {
            //e.Day.IsSelectable = false;
        }
        #endregion


        #region To add content to an individual day

        string aHoliday;
        string[,] holidays = new String[13, 32];//[month,date] +1

        holidays[8, 19] = "Appt(3)";
        holidays[3, 14] = "An";

        DateTime theDate = e.Day.Date;
        aHoliday = holidays[theDate.Month, theDate.Day];
        if (aHoliday != null)
        {
            Image img = new Image();
            img.ImageUrl = "http://localhost:3714/HTML5/mb/images/li_2.gif";
            //img.Style.Add("position", "top right");
            e.Cell.Controls.Add(img);



            //aLabel.ToolTip = "this is the custome Message";
            e.Cell.ToolTip = "this is the custome Message for :" + e.Day.Date.ToLongDateString();
            //e.Cell.Text += "<a href=\"javascript:go4appt();\">" + aHoliday + " </a>";

            e.Cell.Text += "<br/><a href=\"javascript:\">" + aHoliday + " </a>";
            e.Cell.Style.Add("cursor", "pointer");
            e.Cell.Attributes.Add("onclick", "go4appt();");


            e.Cell.CssClass = "mixBk";
            //e.Cell.Text = e.Day.DayNumberText;

        }

        #endregion

        #region To customize the link text for individual days
        if (aHoliday != null)
        {
            //e.Cell.Text = "<a href=" + e.SelectUrl + ">" +
            //   aHoliday + "</a>";
            //go4appt()

           // e.Cell.Text = "<a href=\"javascript:go4appt();\">" + aHoliday + " </a>";
        }
        #endregion


        #region Display Holiday list using HashTable
        if (HolidayList[e.Day.Date.ToShortDateString()] != null)
        {
            Literal literal1 = new Literal();
            literal1.Text = e.Day.DayNumberText;// "<br/>";
            e.Cell.Controls.Add(literal1);
            
            
            //e.Cell.Text = e.Day.DayNumberText;

            Label label1 = new Label();
            label1.Text = (string)HolidayList[e.Day.Date.ToShortDateString()];
            label1.Font.Size = new FontUnit(FontSize.Small);
            e.Cell.Controls.Add(label1);
            //e.Cell.Text += e.Day.DayNumberText;
        }
        #endregion

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string date = GetParam("mydate");
    }
}