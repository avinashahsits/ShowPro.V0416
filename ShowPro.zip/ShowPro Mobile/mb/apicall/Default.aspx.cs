﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

public partial class mb_apicall_Default : System.Web.UI.Page
{
    string SF_Contact_id = "";

    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    private void Page_PreInit(object sender, EventArgs e)
    {
        string isComeFromURL = "";
        isComeFromURL = GetParam("apiCall").Trim();

        if (Session["ssnUserId"] != null)
        {
            SF_Contact_id = Convert.ToString(Session["ssnUserId"]);

            if (isComeFromURL == "1")
            {
                Response.Redirect("../myappts.aspx");
            }
            else if (isComeFromURL == "2")
            {
                Response.Redirect("../myappts.aspx");
            }
            else
            {
                Response.Redirect("../wlcm.aspx");
            }
            //ok then it dispaly his/her appointments
        }
        else
        {
            //user/recentAppts.aspx?apiCall=1&agRcview=003i00000073R29AAE
            // Session["ssnUserId"] = SF_Contact_id;


            if (isComeFromURL == "1" || isComeFromURL == "2")
            {
                Session["ssnUserId"] = null;
                Session["ssnUserType"] = null;

                SF_Contact_id = GetParam("agRcview").Trim();
                if (SF_Contact_id != "")
                {
                    if (isValidUser(SF_Contact_id))
                    {
                        //ok
                        if (Session["ssnUserId"] != null)
                        {
                            try
                            {
                                ArrayList clInfo = getDataFromSF.getContactDataByID(Convert.ToString(Session["ssnUserId"]));
                                string emailid = clInfo[0].ToString();
                                string name = clInfo[1].ToString();

                                if (emailid != "")
                                {
                                    Session["ssnUserEmailId"] = emailid;
                                }
                                else
                                {
                                    Session["ssnUserEmailId"] = null;
                                }
                                if (name != "")
                                {
                                    Session["ssnUserFullName"] = name;
                                }
                                else
                                {
                                    Session["ssnUserFullName"] = null;
                                }
                                if (Session["ssnDFdates"] != null)
                                {
                                    Session["ssnDFdates"] = null;
                                }
                            }
                            catch (Exception ex)
                            {
                            }

                            if (isComeFromURL == "1")
                            {
                                Response.Redirect("../myappts.aspx");
                            }
                            else if (isComeFromURL == "2")
                            {
                                Response.Redirect("../wlcm.aspx");
                            }
                            else
                            {
                                Response.Redirect("../wlcm.aspx");
                            }
                        }
                    }
                    else
                    {
                        Response.Redirect("../Default.aspx");
                    }
                }
                else
                {
                    Response.Redirect("../Default.aspx");
                }
            }
            else
            {
                Response.Redirect("../Default.aspx");
            }
        }
        // Session["ssnUserId"] = "003d000000PgrzlAAB";
    }

    private bool isValidUser(string pSF_id)
    {
        bool result = false;
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "select  auto_id,security_token, salesforce_obj_id, acc_type from user_master where" +
                " SF_id='" + pSF_id + "' and acc_status='1'";

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    Session["ssnUserId"] = Convert.ToString(dr["salesforce_obj_id"]);
                    Session["ssnUserType"] = Convert.ToString(dr["acc_type"]);
                    Session["ssnSecToken"] = Convert.ToString(dr["security_token"]);
                    result = true;
                }

            }
            else
            {
                Session["ssnUserId"] = null;
                Session["ssnUserType"] = null;
                result = false;

            }

        }
        catch (Exception ex)
        {
            result = false;

        }
        finally
        {
            con.Close();
        }
        return result;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}