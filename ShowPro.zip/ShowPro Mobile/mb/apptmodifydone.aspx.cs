﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_apptmodifydone : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        string mescount = GetParam("p1");

        if (mescount != "")
        {
            mes.InnerHtml = "Appointment has been updated successfully !";
        }
        else
        {
            mes.InnerHtml = " Appointment has been updated successfully !";
        }
    }
}