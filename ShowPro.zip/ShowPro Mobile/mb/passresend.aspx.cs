﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


using cs_mail;
using System.Threading;
using System.ComponentModel;
using System.Net.Mime;
using System.Text;
using System.IO;
using System.Net;
using System.Web.Services.Description;
using System.Net.Mail;


public partial class mb_passresend : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();

        if (email == "")
        {
            globalError.InnerHtml = "Please enter you email";
        }
        else
        {
            globalError.InnerHtml = "";
            string Contact_id = getDataFromSF.getIDbyEmail(email);
            if (Contact_id != "")
            {
                string password = loginPassword(Contact_id);

                if (send_mail(email, password))
                {
                    globalMessage.InnerHtml = "Your password has been sent.";
                    txtEmail.Text = "";
                    // Response.Redirect("Default.aspx");
                }
                else
                {

                    globalError.InnerHtml = "Please try again !";
                    txtEmail.Text = "";
                }
            }

        }
    }
    protected bool send_mail(string pEmailid, string pPwd)
    {
        bool result = false;
        try
        {

            string user_id = "customercare@showingset.com"; //"itinfo@ahsits.com";
            string pass = "Anyonehome1";

            int port = 25;

            string emto = "sverma@ahsits.com";

            if (pEmailid != null)
            {
                emto = pEmailid;
            }

            DateTime dt = System.DateTime.Now;

            string dtformat = dt.ToString("MMMM") + " " + dt.Month.ToString() + ", " + dt.Year + " " + "at" + " " + dt.ToLongTimeString();
            Random rm1 = new Random();


            string sub = "Your Showpro Login Info";

            StringWriter sw = new StringWriter();
            HtmlTextWriter h = new HtmlTextWriter(sw);
            string messageBody = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"9\" style=\"border:1px solid #666; background-color:#CCEEFF;\">" +
                                 "<thead> <tr>   <th>   <h3>ShowPro Login Info</h3>" + dtformat + "</th></tr></thead><tbody> <tr> <td> Here are your account credentials you requested:</td> </tr>" +
                                 "<tr> <td> <a href=\"http://showdev.anyonehome.com/mb/\">Click Here to access </a>ShowPro </td>  </tr>" +
                                 "<tr><td>E-mail &nbsp; :&nbsp; " + pEmailid + "</td></tr><tr><td>Password &nbsp; :&nbsp; " + pPwd + "</td></tr> <tr>  <td>Thanks!<br />The Anyone Home Team</td></tr></tbody></table>";

            //       h.Write(" <h3 style=\"text-decoration: underline;\">Registration Details:</h3><br/> ");

            h.Write(messageBody);


            string str = sw.GetStringBuilder().ToString();

            string mess = str;
            cs_mail.custom_mail gm = new custom_mail();

            bool re = gm.sendMail(emto, "localhost", port, user_id, pass, sub, str); //gm.godaddyMail(emto, "sverma@ahsits.com", "", "", port, user_id, pass, sub, mess);
            if (re == false)
            {
                // pendingmail.store_mail(emto, sub, mess);
                // globalError.InnerHtml = "Email not sent to " + emto + "!";
                result = false;
            }
            else
            {
                //globalError.InnerHtml = "<img src=\"../images/sahi.png\" alt=\"\" />Done!";
                result = true;
            }
        }
        catch (Exception ex)
        {
            globalError.InnerHtml = ex.Message;
        }
        finally
        {

        }
        return result;
    }
    private string loginPassword(string pSF_id)
    {
        string result = "";
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "select  auto_id,security_token, security_pin, acc_type from user_master where" +
                " salesforce_obj_id='" + pSF_id + "' and acc_status='1'";

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    //Session["ssnUserId"] = Convert.ToString(dr["salesforce_obj_id"]);
                    //Session["ssnUserType"] = Convert.ToString(dr["acc_type"]);
                    result = Convert.ToString(dr["security_pin"]);
                }

            }
            else
            {
                result = "";
            }
            dr.Close();
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            result = "";
        }
        finally
        {
            con.Close();
        }
        return result;
    }
}