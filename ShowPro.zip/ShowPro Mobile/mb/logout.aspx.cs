﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class logout : System.Web.UI.Page
{
    
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Abandon();
        Session["ssnSecToken"] = null;
        if (Session["ssnUserId"] != null)
        {
            goto HomePage;
        }
        else
        {
            goto HomePage;
            //Response.Redirect("Default.aspx");
        }

    HomePage:
        Session["ssnSecToken"] = null;
        Session["ssnUserId"] = null;
        Session["ssnUserType"] = null;
        Session["ssnUserEmailId"] = null;
        Session["ssnUserFullName"] = null;

        string back_toAdmin = GetParam("backtosuper").Trim();


        Session["globalMessText"] = "You have been logged out";
        if (back_toAdmin == "1")
        {
            //
            //adminpanel.aspx
            Response.Redirect("Default.aspx");
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }
}