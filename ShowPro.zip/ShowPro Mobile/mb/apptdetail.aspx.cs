﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_apptdetail : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        //globalMessage.InnerHtml = "";
        ArrayList pndgs = new ArrayList();

        if (Session["ssnAcceptedAppts"] != null)
        {
            pndgs = (ArrayList)Session["ssnAcceptedAppts"];
        }
        else
        {
            string con_id = Convert.ToString(Session["ssnUserId"]);

            //changes on 12 Oct 2013.
            if (con_id != "")
            {
                pndgs = getAppointments.upcommingAppointments(con_id); //getAppointments.acceptedAppointments(con_id);
            }
            else
            {
                Response.Redirect("Default.aspx");
            }
            //globalMessage.InnerHtml = "Appt. id not found!, go back";
            //return;
        }

        string id = ""; //"a0Ci0000002GlxkEAC";

        id = GetParam("p1").Trim();

        if (id == "")
        {
            return;
        }


        var query = from getAppointments.AcceptedApptInfo appts in pndgs
                    // where appts.Appt_id = id
                    select appts;

        int counter = 1;
        string output = " <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 98%;\">";

        foreach (getAppointments.AcceptedApptInfo apptInfo in query)
        {
            string AjaxDivId = "ajx_" + counter;
            string ap_id = apptInfo.Appt_id;

            if (ap_id == id)
            {
                output += "<td align=\"left\" valign=\"top\" style=\"padding-top: 10px; \"><b>Date & Time</b><br/>" +
                    String.Format("{0:ddd, MMM d, yyyy}", apptInfo.Appt_date) + " </td> </tr>" +
               "<tr> <td colspan=\"4\">" +
                       apptInfo.Appt_time + "</td> </tr>" +
               "<tr>  <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                      "<b>Property</b> <br />"+ apptInfo.Prop_name + " <br />" +
                       apptInfo.Prop_address + " </td></tr>" +
               "<tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                  "<b>Prospect</b> <br />"+ apptInfo.Client_name + "<br />";

                if (apptInfo.Client_phone != "")
                {
                    output += apptInfo.Client_phone + " <br />";
                }
                if (apptInfo.Client_mobile != "")
                {
                    output += apptInfo.Client_mobile + " <br />";
                }
                else
                {
                    output += "";
                }




                output += apptInfo.Client_email + "</td></tr>";

                #region changing for 19 march 2014 to display Prospect Desire

              
                output += "<tr><td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                    "<b>Prospect Desires</b><br/>" +
                    "Days Until Move:&nbsp;" + apptInfo.Days_until_Move_in + "<br/>" +
                    "Desired Move In Date:&nbsp;" + apptInfo.Move_in_Date + "<br/>" +
                    "Number of Occupants:&nbsp;" + apptInfo.No_Of_Occupants + "<br/>" +
                     "Number of Bedrooms:&nbsp;" + apptInfo.No_Of_Bedroom + "<br/>" +
                      "Number of Bathrooms:&nbsp;" + apptInfo.No_Of_Bathroom + "<br/>" +
                       "Rent Range:&nbsp;" + apptInfo.Desired_Rent_Start + "&nbsp;&nbsp;to&nbsp;" + apptInfo.Desired_Rent_End + "<br/>" +
                       "Lease Length:&nbsp;" + apptInfo.Desired_Lease_length + "<br/>" +
                       "Washer/Dryer Pref:&nbsp;" + apptInfo.W_D_Preference + "<br/>" +
                        "Affordable Inquiry:&nbsp;" + apptInfo.Affordable_Inquiry + "<br/>" +
                         apptInfo.Monthly_Income_Check + "<br/>" +
                    "</td></tr>";
               
                #endregion

                #region changing for 19 march 2014 to display Pet Information

                output += "<tr><td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                    "<b>Pet Information</b><br/>" +
                    "Dogs:&nbsp;" + apptInfo.Dog_Count + "<br/>" +
                    "Breed:&nbsp;" + apptInfo.Dog_Breed + "<br/>" +
                    "Cats:&nbsp;" + apptInfo.Cat_Count + "<br/>" +
                     
                    "</td></tr>";

                #endregion

                #region changing for 19 march 2014 to display Call Notes

                output += "<tr><td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                    "<b>Call Notes</b><br/>" +
                    "Notes:&nbsp;" + apptInfo.Notes + "<br/>" +
                    "Reason For Moving:&nbsp;" + apptInfo.Reason_for_Moving + "<br/>" +
                      apptInfo.Case_Description + "<br/>" +

                    "</td></tr>";

                #endregion

                output += "<br/><br/>";
                output += "<tr><td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" + apptInfo.Appt_status + "&nbsp;<a href=\"javascript://\" onclick=\"change_status('" + ap_id + "');\" >Change Status</a> </td>  </tr>" +
               "<tr>" +
                "   <td align=\"center\" valign=\"top\" colspan=\"4\" style=\"border-bottom: 1px solid #ccc;\">" +
                       "<div id=\"" + AjaxDivId + "\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"10\"> <tr>";


                if (apptInfo.Appt_status.Trim() == "Accepted")
                {

                    output += "<td> <input type=\"button\" data-mini=\"true\" value=\"Modify Time\" onclick=\"appt_modify('" + ap_id + "');\" /></td>" +
                        " <td> <input type=\"button\" data-mini=\"true\" value=\"Follow up\" onclick=\"appt_followup('" + ap_id + "');\" /></td>";
                }
                else
                {
                    output += "<td> <input type=\"button\" data-mini=\"true\" disabled=\"disabled\" value=\"Modify\" /></td>" +
                        " <td> <input type=\"button\" data-mini=\"true\"  disabled=\"disabled\" value=\"Follow up\" /></td>";
                }

                output += " </tr> </table>  </div>   </td>";//<tr><td align=\"center\" valign=\"top\" colspan=\"4\"><input type=\"button\" data-mini=\"true\"  value=\"Past Appointment\" onclick=\"go_pastappt();\" /></td></tr> </tr>";
                counter++;
            }

        }
        output += "</table>";

        main_Div.InnerHtml = output;

    }
}