﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebReference;
using System.Collections;

public partial class apptEdit_ajax_cancelappt : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //<img src="ajax/sahi.png" />
        string Js = "<script type=\"text/javascript\"> smoke.alert('hmmm');</script>";
        //Response.Write(Js);
        //refreshThisPage(Appt_id);
        string abc="";

        string apptId = "", cancel_comment = "", result = "", ThisIsFromApptViewPage = "";// 1july 2013 for adding Cancel and Modify buttons

        apptId = GetParam("p1").Trim();
        cancel_comment = GetParam("cmnt").Trim();

        ThisIsFromApptViewPage = GetParam("apptView455").Trim();


        if (apptId != "" && cancel_comment != "")
        {
            string IsForReject = GetParam("p2").Trim();
            if (IsForReject == "1")
            {
                if (UpdateData(apptId, "2", cancel_comment))
                {

                    abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BE1E2D; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Request has been rejected.</span> </div> </div> </center>";
                    result = abc;

                    //changes on 10 Oct 2013
                    ArrayList recentAppointments = new ArrayList();
                    string con_id = Convert.ToString(Session["ssnUserId"]);
                    if (con_id != "")
                    {
                        recentAppointments = getAppointments.upcommingAppointments(con_id); //getAppointments.acceptedAppointments(con_id);
                    }
                    if (recentAppointments.Count > 0)
                    {
                        Session["ssnAcceptedAppts"] = recentAppointments;

                    }

                }
                else
                {
                    abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BE1E2D; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Error please try again!</span> </div> </div> </center>";
                    result = abc;
                }
            }
            else
            {
                
                if (UpdateData(apptId, "Canceled", cancel_comment))
                {
                     abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BE1E2D; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Request has been canceled.</span> </div> </div> </center>";
                    result = abc;

                    //changes on 10 Oct 2013
                    ArrayList recentAppointments = new ArrayList();
                    string con_id = Convert.ToString(Session["ssnUserId"]);
                    if (con_id != "")
                    {
                        recentAppointments = getAppointments.upcommingAppointments(con_id); //getAppointments.acceptedAppointments(con_id);
                    }
                    if (recentAppointments.Count > 0)
                    {
                        Session["ssnAcceptedAppts"] = recentAppointments;
                       
                    }
                }
                else
                {
                    abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BE1E2D; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Error please try again!</span> </div> </div> </center>";
                    result = abc;
                }
            }
            



            // change for referesh pending appointment 23 Oct 2013

            if (Session["ssnUserId"] != null)
            {
                
                ArrayList pndgs = new ArrayList();
                string agent_id = Convert.ToString(Session["ssnUserId"]);
                pndgs = getPendingAppointmentSF.pendingAppointments(agent_id);
                if (pndgs!=null && pndgs.Count>0)
                {
                    Session["ssnPendingAppts"] = pndgs;    
                }
                else
                {
                    Session["ssnPendingAppts"] = null;
                }
                //o use this first:
                //string js = "<script type=\"text/javascript\"> updateDone()  </script>";
                //result += " " + js;


                Js += "<script type=\"text/javascript\"> alert('k');</script>";

                // Page.ClientScript.RegisterStartupScript(this.GetType(), "script", "  <script> alert('k');</script>");
                 //ScriptManager.RegisterStartupScript(Page, typeof(Page), "updateonclose2", "updateDone();", true);
                // string js = "<script type=\"text/javascript\"> alert('k'); updateDone();  </script>";
               // result += " " + Js;
            }
           


        }
        else
        {
            result = "";
        }
        Response.Write(result);
       
    }

    private bool UpdateData(string pAppt_id, string pWhatToDo, string pComments)
    {
        bool result = false;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

            string invitation_status = "";
            Appointment__c appt_obj = new Appointment__c();

            appt_obj.Id = pAppt_id;
            appt_obj.Comments__c = pComments.Trim();

            if (pWhatToDo != "" && pWhatToDo == "Canceled")
            {
                //Home Leased, changes on 26 Feb 2014 according to email.
                invitation_status = "Canceled";
                appt_obj.Comments__c = "Home Leased";
            }
            else if (pWhatToDo != "" && pWhatToDo == "2")
            {
                invitation_status = "Rejected";
            }
            else if (pWhatToDo != "" && pWhatToDo == "1")
            {
                //accepted
                invitation_status = "Accepted";
            }
            else
            {
                return false;
            }

            appt_obj.Invite_Status__c = invitation_status;
           


            sObject[] to = new sObject[1];
            to[0] = appt_obj;

            SaveResult[] saveResults = login.bi.update(to);

            // Handle the results  

            for (int i = 0; i < saveResults.Length; i++)
            {
                // Determine whether create() succeeded or had errors  

                if (saveResults[i].success)
                {
                    // No errors, so retrieve the Id created for this record  
                    //Session.Add("ssnCAcId", saveResults[i].id);
                    //Server.Transfer("editcust.aspx?cstid=" + saveResults[i].id);
                    result = true;
                }
                else
                {
                    result = false;
                    // Handle the errors  
                }
            }
        }

        catch (Exception ex)
        {
            result = false;
        }
        finally
        {
        }
        return result;
    }
}