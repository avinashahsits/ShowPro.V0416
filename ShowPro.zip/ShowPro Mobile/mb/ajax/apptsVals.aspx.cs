﻿using System;
using System.Collections.Generic;
using WebReference;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class ajax_slotaction : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }

    string SF_User_id = "";
    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            SF_User_id = Convert.ToString(Session["ssnUserId"]);
        }
        else
        {
            SF_User_id = "";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // var args = "p1=" + pSF_id + "&p2=" + pSlotId + "&p3=2"; 



        string Slot_date = "", apptSF_id = "", what_to_do = "", result = "", isOthers = "";



        if (SF_User_id == "" || SF_User_id == null)
        {
            SF_User_id = GetParam("p1").Trim();
        }

        isOthers = GetParam("p5").Trim();

        if (isOthers != "" && isOthers == "1")
        {
            result = itHasAppT_others(SF_User_id);
            if (result != "")
            {
               Response.Write(result);
            }
            else
            {
                Response.Write("No appointment!");
            }
            return;
        }

        apptSF_id = GetParam("p2").Trim();

        what_to_do = GetParam("p3").Trim();

        Slot_date = GetParam("p4").Trim();

        if (Slot_date != "")
        {
            //Slot_date = common.SF_date(Slot_date);
        }

        // p3= 1 for refresh, 2 for Accept and 3 for reject
        if (what_to_do == "1")
        {
            //refresh recent screens
            result = itHasAppT(SF_User_id);
        }
        else if (what_to_do == "2")
        {
            string abc = "";
            //1 for Accept in UpdateData method
            if (UpdateData(SF_User_id, apptSF_id, "1"))
            {
                abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BED73B; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Request has been accepted.</span> </div> </div> </center>";
            }
            else
            {
                abc = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BE1E2D; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Error please try again!</span> </div> </div> </center>";
            }
            //result = itHasAppT(SF_User_id);
            

            //string Js = "<script type=\"text/javascript\">check_others();</script>";
            result += abc;

            //changes on 10 Oct 2013
            ArrayList recentAppointments = new ArrayList();
            string con_id = Convert.ToString(Session["ssnUserId"]);
            if (con_id != "")
            {
                recentAppointments = getAppointments.upcommingAppointments(con_id); //getAppointments.acceptedAppointments(con_id);
            }
            if (recentAppointments.Count > 0)
            {
                Session["ssnAcceptedAppts"] = recentAppointments;
            }

            ArrayList pndgs = new ArrayList();
            string agent_id = Convert.ToString(Session["ssnUserId"]);
            pndgs = getPendingAppointmentSF.pendingAppointments(agent_id);
            if (pndgs != null && pndgs.Count > 0)
            {
                Session["ssnPendingAppts"] = pndgs;
            }
            else
            {
                Session["ssnPendingAppts"] = null;
            }

            string Js = "<script type=\"text/javascript\"> alert('k From JS string');</script>";
           // string js = "<script type=\"text/javascript\"> alert('k'); updateDone();  </script>";
            result += " " + Js;

            try
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "script", "  <script> alert('Page Script');</script>");
            }
            catch (Exception)
            {
                
                
            }
            try
            {
               // HttpContext.Current.Response.Write("<script>alert('Page Script');</script>");
            }
            catch (Exception)
            {
                
            }
            
           


        }
        else if (what_to_do == "3")
        {
            //2 for reject in method
            if (UpdateData(SF_User_id, apptSF_id, "2"))
            {

            }
            result = itHasAppT(SF_User_id);
            string Js = "<script type=\"text/javascript\">check_others();</script>";
            result += Js;
        }
        else
        {
        }
        if (result == "")
        {
            result = "No invitation!";
        }
       Response.Write(result);

    }
    private bool delData(string pc_id)
    {
        bool result = false;
        Appointment__c cus = new Appointment__c();
        cus.Id = pc_id;
        string[] to = new string[1];
        to[0] = pc_id;

        try
        {

            //UpdateResult[] updateResults = binding.update(new SObject[] {updateOpportunity});
            DeleteResult[] saveResults = login.bi.delete(to);

            // Handle the results  

            for (int i = 0; i < saveResults.Length; i++)
            {
                // Determine whether create() succeeded or had errors  

                if (saveResults[i].success)
                {
                    result = true;
                }
                else
                {
                    // result.InnerHtml=" Item {0} had an error updating", i);

                    // Handle the errors  

                    foreach (Error error in saveResults[i].errors)
                    {
                        //result.InnerHtml = "Error code is: {0}" + error.statusCode.ToString();
                        // result.InnerHtml += " Error message: {0}" + error.message;
                    }
                }
            }

        }
        catch (Exception ex)
        {
            result = false;
        }
        return result;
    }

    private bool UpdateData(string pSFid, string pAppt_id, string pWhatToDo)
    {
        bool result = false;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

            string invitation_status = "";
            Appointment__c appt_obj = new Appointment__c();

            appt_obj.Id = pAppt_id;

            if (pWhatToDo != "" && pWhatToDo=="2")
            {
                invitation_status = "Rejected";
            }
            else if (pWhatToDo != "" && pWhatToDo == "1")
            {
                //accepted
                invitation_status = "Accepted";
            }
            else
            {
                return false;
            }

            appt_obj.Invite_Status__c = invitation_status;


            sObject[] to = new sObject[1];
            to[0] = appt_obj;

            SaveResult[] saveResults = login.bi.update(to);

            // Handle the results  

            for (int i = 0; i < saveResults.Length; i++)
            {
                // Determine whether create() succeeded or had errors  

                if (saveResults[i].success)
                {
                    // No errors, so retrieve the Id created for this record  
                    //Session.Add("ssnCAcId", saveResults[i].id);
                    //Server.Transfer("editcust.aspx?cstid=" + saveResults[i].id);
                    result = true;
                }
                else
                {
                    result = false;
                    // Handle the errors  
                }
            }
        }

        catch (Exception ex)
        {
            result = false;
        }
        finally
        {
        }
        return result;
    }
    private string itHasAppT(string pUserSF_id)
    {
        string result = "";
        //if found any aap regarding this date then fetch the data and store it to Global variables then return true otherwise false

        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

            // and  Appointment_Date__c>= today 
            //SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='003d000000PgrzlAAB' and Invite_Status__c='Invited' order by LastModifiedDate desc
            string sql_appts_recent = "SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='" + pUserSF_id + "' and Invite_Status__c='Invited'  and  Appointment_Date__c>= today  order by LastModifiedDate desc";
            //SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='003d000000PgrzlAAB' and Invite_Status__c <> 'Invited' order by LastModifiedDate desc
            //string sql_appts_others = "SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='" + pUserSF_id + "' and Invite_Status__c <> 'Invited' order by LastModifiedDate desc";

            QueryResult qr = null;

            
            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_recent);

            bool done = false;
            if (qr.size > 0)
            {
                result = "<table id=\"no-more-tables\"><thead><tr>" +
                    "<th class=\"numeric\" style=\"width:81px;\">Date</th>" +
                    "<th class=\"numeric\" style=\"width:81px;\">Property</th>" +
                    "<th class=\"numeric\" style=\"width:60px;\">Action</th></tr></thead>";

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Appointment__c con = (Appointment__c)qr.records[i];

                        string cid = con.Id;



                        #region Get Html

                        string strCase = con.Case__c;
                        string strProperty = con.Property_name__c;

                        //string strPrpertyId = con.Property__c;

                        strProperty = "<a href=\"javascript://\" onclick=\"GotoThis('"+ cid+"');\">"+strProperty+"</a>";


                        string st = con.From__c;
                        string et = con.To__c;


                        con.Appointment_Date__cSpecified = true;
                        string date = Convert.ToString(con.Appointment_Date__c);
                        DateTime dt = Convert.ToDateTime(date);
                        date = dt.Month + "/" + dt.Day + "/" + dt.Year;
                        //edsb.png
                        //cancel_clear.png

                        string ActionPanel2_old = "<a href=\"javascript://\" onclick=\"acceptTihs('" + cid + "');\"><img src=\"../images/sahi.png\" border=\"0\" alt=\"Accept\" /></a>&nbsp;&nbsp;&nbsp;" +
                            "<a href=\"javascript://\" onclick=\"rejectTihs('" + cid + "');\"><img  src=\"../images/delall.png\" border=\"0\" alt=\"Reject\" /></a>";

                        string ActionPanel2 = "<a href=\"javascript://\" onclick=\"acceptTihs('" + cid + "');\"><img src=\"../images/sahi.png\" border=\"0\" alt=\"Accept\" /></a>&nbsp;&nbsp;&nbsp;" +
                            "<a href=\"javascript://\" onclick=\"rejectTihs('" + cid + "');\"><img  src=\"../images/delall.png\" border=\"0\" alt=\"Reject\" /></a>" +
                            "<a href=\"javascript://\" onclick=\"modifyTihs('" + cid + "');\"><img src=\"../images/edsb.png\" border=\"0\" alt=\"Modify\" /></a>&nbsp;&nbsp;&nbsp;" +
                            "<a href=\"javascript://\" onclick=\"cancelTihs('" + cid + "');\"><img src=\"../images/cancel_clear.png\" border=\"0\" alt=\"Cancel\" /></a>";

                        result += "<tr> <td class=\"numeric\" style=\"width:81px;\" data-title=\"Date\">"
                           // + date + "<br/><small>" + st + "-" + et + "</small></td><td class=\"numeric\" style=\"width:81px;\" data-title=\"Property\"> "
                            + date + "</td><td class=\"numeric\" style=\"width:81px;\" data-title=\"Property\"> "
                            + strProperty + "</td><td class=\"numeric\" style=\"width:60px;\" data-title=\"Action\">"
                            + ActionPanel2 + "</td></tr>";

                        #endregion

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }
                result += " </table>";

            }
            else
            {
                result = "No invitation!";

            }
        }
        catch (Exception ex)
        {

            result = ex.Message;
        }
        finally
        {
        }

        return result;
    }

    private string itHasAppT_others(string pUserSF_id)
    {
        string result = "";
        //if found any aap regarding this date then fetch the data and store it to Global variables then return true otherwise false

        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }


            //hiding Canceled appointment here
            //SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='003d000000PgrzlAAB' and Invite_Status__c <> 'Invited' order by LastModifiedDate desc
            // and  Appointment_Date__c>= today "
            string sql_appts_others = "SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='" + pUserSF_id + "' and Invite_Status__c <> 'Invited' and Invite_Status__c <> 'Canceled'  and  Appointment_Date__c>= today order by LastModifiedDate desc";

            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_others);

            bool done = false;
            if (qr.size > 0)
            {
                result = "<table id=\"no-more-tables\"><thead><tr>" +
                    "<th class=\"numeric\" style=\"width:81px;\">Date</th>" +
                    "<th class=\"numeric\" style=\"width:81px;\">Property</th>" +
                    "<th class=\"numeric\" style=\"width:60px;\">Status</th></tr></thead>";

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Appointment__c con = (Appointment__c)qr.records[i];

                        string cid = con.Id;


                        #region Get Html

                        string strCase = con.Case__c;
                        string strProperty = con.Property_name__c;

                        //string strPrpertyId = con.Property__c;

                        strProperty = "<a href=\"javascript://\" onclick=\"GotoThis('" + cid + "');\">" + strProperty + "</a>";


                        string st = con.From__c;
                        string et = con.To__c;


                        con.Appointment_Date__cSpecified = true;
                        string date = Convert.ToString(con.Appointment_Date__c);
                        DateTime dt = Convert.ToDateTime(date);
                        date = dt.Month + "/" + dt.Day + "/" + dt.Year;

                        string invite_status = con.Invite_Status__c;
                        string ActionPanel2 = "";
                        if (invite_status == "Accepted")
                        {
                            ActionPanel2 = "<img  src=\"../images/sahi.png\" border=\"0\" alt=\"Accepted\" />" +
                                "&nbsp;&nbsp;&nbsp;<a href=\"javascript://\" onclick=\"cancelTihs('" + cid + "');\"><img src=\"../images/cancel_clear.png\" border=\"0\" alt=\"Cancel\" /></a>";
                        }
                        else if (invite_status == "Rejected")
                        {
                            ActionPanel2 = "<img  src=\"../images/delall.png\" border=\"0\" alt=\"Rejected\" />"+
                                "&nbsp;&nbsp;&nbsp;<a href=\"javascript://\" onclick=\"cancelTihs('" + cid + "');\"><img src=\"../images/cancel_clear.png\" border=\"0\" alt=\"Cancel\" /></a>";
                        }
                        else if (invite_status == "Canceled")
                        {
                            ActionPanel2 = "<img  src=\"../images/cancel_clear.png\" border=\"0\" alt=\"Canceled\" />";
                        }


                        //string ActionPanel2 = "<a href=\"javascript://\" onclick=\"acceptTihs('" + cid + "');\"><img src=\"../images/sahi.png\" border=\"0\" alt=\"Accept\" /></a>&nbsp;&nbsp;&nbsp;" +
                        //    "<a href=\"javascript://\" onclick=\"rejectTihs('" + cid + "');\"><img  src=\"../images/close.png\" border=\"0\" alt=\"Reject\" /></a>";

                        result += "<tr> <td class=\"numeric\" style=\"width:81px;\" data-title=\"Date\">"
                            // + date + "<br/><small>" + st + "-" + et + "</small></td><td class=\"numeric\" style=\"width:81px;\" data-title=\"Property\"> "
                            + date + "</td><td class=\"numeric\" style=\"width:81px;\" data-title=\"Property\"> "
                            + strProperty + "</td><td class=\"numeric\" style=\"width:60px;\" data-title=\"Action\">"
                            + ActionPanel2 + "</td></tr>";

                        #endregion

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }
                result += " </table>";

            }
            else
            {
                result = "";

            }
        }
        catch (Exception ex)
        {

            result = ex.Message;
        }
        finally
        {
        }

        return result;
    }

    
    
}