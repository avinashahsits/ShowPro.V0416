﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebReference;

public partial class mb_cancelexp : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    public string exDate = "", exTime = "", exId = "", SF_Contact_id = "";

    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            SF_Contact_id = Convert.ToString(Session["ssnUserId"]);
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            string id = GetParam("p1").Trim();
            string date = GetParam("p2").Trim();
            string time = GetParam("p3").Trim();


            Message.InnerHtml = "";

            if (date != "" && id != "")
            {
                DateTime dt = Convert.ToDateTime(date);

                string DayName = String.Format("{0:dddd}", dt);
                //Console.WriteLine("Year: {0}, Month: {1}, Day: {2}", dt.Year, dt.Month, dt.Day);
                date = dt.Month + "/" + dt.Day + "/" + dt.Year;

                exDate = DayName + " , " + date;
                exId = id;
                SFobj_id.Value = id;
                exTime = time;
            }
        }
        else
        {
            string id = GetParam("p1").Trim();
            string date = GetParam("p2").Trim();
            string time = GetParam("p3").Trim();
            DateTime dt = Convert.ToDateTime(date);

            string DayName = String.Format("{0:dddd}", dt);
            //Console.WriteLine("Year: {0}, Month: {1}, Day: {2}", dt.Year, dt.Month, dt.Day);
            date = dt.Month + "/" + dt.Day + "/" + dt.Year;

            exDate = DayName + " , " + date;
            exTime = time;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Message.InnerHtml = "";
        string mess = "";
        string date = GetParam("p2").Trim();

        DateTime dt1 = Convert.ToDateTime(date);

        if (dt1 < DateTime.Today)
        {
            Message.InnerHtml = "You can't edit this past Unavailability!";
            return;
        }



        string ex_recId = SFobj_id.Value.Trim();

        if (ex_recId != "")
        {
            if (delData(ex_recId, ref mess))
            {
                Message.InnerHtml = "";
                //Response.Redirect("mycal.aspx?mess=Your Unavailability removed successfully!");
                Response.Redirect("myappts.aspx");

            }
            else
            {
                Message.InnerHtml = mess;
            }
        }

    }

    private bool delData(string pc_id, ref string strError)
    {
        bool result = false;
        Unvailability__c cus = new Unvailability__c();
        cus.Id = pc_id;
        string[] to = new string[1];
        to[0] = pc_id;

        try
        {

            //UpdateResult[] updateResults = binding.update(new SObject[] {updateOpportunity});
            DeleteResult[] saveResults = login.bi.delete(to);

            // Handle the results  

            for (int i = 0; i < saveResults.Length; i++)
            {
                // Determine whether create() succeeded or had errors  

                if (saveResults[i].success)
                {
                    result = true;
                }
                else
                {
                    // result.InnerHtml=" Item {0} had an error updating", i);
                    // Handle the errors  

                    foreach (Error error in saveResults[i].errors)
                    {
                        //result.InnerHtml = "Error code is: {0}" + error.statusCode.ToString();
                        strError = " Error message: {0}" + error.message;
                        result = false;
                    }
                }
            }

        }
        catch (Exception ex)
        {
            strError = ex.Message;
            result = false;
        }
        return result;
    }
}