﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_controls_menu : System.Web.UI.UserControl
{
    /// <summary>
    /// Created By :Sharad Verma on 9 Sept 2013
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    /// 
    public string counts = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        Random rm = new Random();

        int s = 0;//rm.Next(1, 100);
        ArrayList pndgs = new ArrayList();
       
        if (Session["ssnUserId"] != null)
        {
            string con_id = Convert.ToString(Session["ssnUserId"]);
            if (Session["ssnPendingAppts"] != null)
            {
                pndgs = (ArrayList)Session["ssnPendingAppts"];
            }
            else
            {
                pndgs = getPendingAppointmentSF.pendingAppointments(con_id);

                if (pndgs != null && pndgs.Count > 0)
                {
                    Session["ssnPendingAppts"] = pndgs;
                }

            }
            if (Session["checkDefaultAvailability"] != null)
            {
                string check = Convert.ToString(Session["checkDefaultAvailability"]);
                if (check == "True")
                {
                    availability.Style.Add("display", "block");
                }
                else
                {
                    availability.Style.Add("display", "none");
                }
            }
            else
            {
                availability.Style.Add("display", "none");
            }
            

            //if (con_id != "")
            //{
            //    pndgs = getPendingAppointmentSF.pendingAppointments(con_id);
            //}
        }
        else
        {

        }

        if (pndgs != null)
        {
            s = pndgs.Count;
        }
        else
        {
            string con_id = Convert.ToString(Session["ssnUserId"]);
            pndgs = getPendingAppointmentSF.pendingAppointments(con_id);

            if (pndgs != null && pndgs.Count > 0)
            {
                s = pndgs.Count;
                Session["ssnPendingAppts"] = pndgs;
            }
            else
            {
                Session["ssnPendingAppts"] = null;
            }
            
        }

        if(s==0)
        {
            counts = "<span class=\"ui-li-count\" id=\"pendingCount\" runat=\"server\">" + s.ToString() + "</span>";
        }
        else
        {
            //counts = "<span class=\"ui-li-count\" id=\"pendingCount\" runat=\"server\" style=\"border:1px solid red; color:red;\">" + s.ToString() + "</span>";
            counts = "<span class=\"ui-li-count\" id=\"pendingCount\" runat=\"server\"  style=\"color:red; border:1px solid red;\">" + s.ToString() + "</span>";
        }
        //pendingCount.InnerHtml = s.ToString();
    }
}