﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_controls_footer : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Random rm = new Random();


        try
        {
            string newId = "fr_" + rm.Next(1, 4554);
            refSSnMain.ID = newId;
        }
        catch (Exception ex)
        {
            
           // throw;
        }
    }
}