﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_admin_updatepassword : System.Web.UI.Page
{
    string UserName = "", userEmailId = "", adminId = "";

    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {
            adminId = Convert.ToString(Session["ssnAdminUser"]);
        }
     
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
       
        if (adminId != "")
        {
            string newPin = txtpwd.Text.Trim();
            string currentPin = txtCurrent.Text.Trim();

            if (newPin != "")
            {
                if (update_pin(adminId, newPin, currentPin))
                {
                    logerr.InnerHtml = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BED73B; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Your password has been updated  !</span> </div> </div> </center>";
                }
                else
                {
                    logerr.InnerHtml += " Try again.";
                    return;
                }
            }
        }
        else
        {
            logerr.InnerHtml = "";
            return;
        }
    }

    private bool update_pin(string pSF_User_id, string pnewPin, string pCuPass)
    {
        logerr.InnerHtml = "";
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        bool result = false;

        try
        {
            string check_sql = "select auto_id from user_master where salesforce_obj_id='admin' and security_pin='" + pCuPass + "' and acc_type=1";

            string sql = "update user_master set security_pin='" + pnewPin + "' where salesforce_obj_id='admin' and acc_type=1";

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(check_sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                cmd.Dispose();
                if (dr.Read())
                {

                    cmd = new SqlCommand(sql, con);
                    cmd.CommandType = CommandType.Text;

                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            else
            {

                result = false;
                logerr.InnerHtml = "Wrong current password !";
                cmd.Dispose();
            }

            dr.Close();

        }
        catch (Exception ex)
        {
            result = false;
            logerr.InnerHtml = ex.Message;
        }
        finally
        {
            con.Close();
        }
        return result;
    }
}