﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

using cs_mail;
using System.Threading;
using System.ComponentModel;
using System.Net.Mime;
using System.Text;
using System.IO;
using System.Net;
using System.Web.Services.Description;
using System.Net.Mail;

public partial class mb_admin_addnewuser : System.Web.UI.Page
{
    private string userToken = "", userEmail = "", userPin = "";
    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {
            // Session["ssnUserType"] = "1";//--1 for Admin, 2 for user
            if (Session["ssnUserType"] != null)
            {
                string isAdmin = Convert.ToString(Session["ssnUserType"]);

                if (isAdmin == "1")
                {
                }
                else
                {
                    Server.Transfer("adminpanel.aspx");
                    // Server.Transfer("Default.aspx?pid=3&emess=You are not Authorize to view this page! please login as Administrator");
                    //return;
                }

                if (login.bi != null)
                {
                }
                else
                {
                    login.loginnow();
                }
            }
            else
            {
                Server.Transfer("adminpanel.aspx");

            }


        }

        else
        {
            Server.Transfer("adminpanel.aspx");
            //Response.Redirect("Default.aspx");
        }


    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            dyMess.InnerHtml = "";
            logerr.InnerHtml = "";
            userToken = "";
            userEmail = "";
        }
        else
        {
        }
    }
    protected void btncreat_Click(object sender, EventArgs e)
    {
        logerr.InnerHtml = "";
        string SF_objId = "", uPin = "", uAccType = "2", uBy = "1", uEmail = "";//--1 for Admin, 2 for user
        if (Session["ssnTempSF_Obj_id"] != null)
        {
            SF_objId = Convert.ToString(Session["ssnTempSF_Obj_id"]);
        }
        else
        {
            logerr.InnerHtml = "Email id does not associated with any contact";
            return;
        }

        uPin = txtuPin.Text.Trim();

        if (uPin != "")
        {
        }
        else
        {

            logerr.InnerHtml = "Pin required";
            return;
        }

        uEmail = txtuEmail.Value.Trim();

        if (uEmail != "")
        {
        }
        else
        {
            logerr.InnerHtml = "Email id required";
            //logerr.InnerHtml = "Email id does not associated with any contact";
            return;
        }


        string SF_Only_id = TruncateLongString(SF_objId, 15);

        string result = createNewUser(SF_objId, uPin, uBy, uAccType, SF_Only_id);

        if (result == "1")
        {
            //user successfully created, sending email

            userEmail = uEmail;
            userPin = uPin;

            string ProgressMess = " <table border=\"0\" cellpadding=\"0\" cellspacing=\"9\" style=\"border: 1px solid #666; background-color: Silver;\"> <tr> <td align=\"right\" valign=\"top\">" +
                "<img src=\"../images/ajax-loader.gif\" alt=\"\" />  </td> <td align=\"left\" valign=\"top\" style=\"color: Green;\"> User created, sending email….</td></tr></table>";

            Thread after_emreg = new Thread(send_mail);
            //after_emreg.Start();
            logerr.InnerHtml = ProgressMess;

            send_mail();
            logerr.InnerHtml = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BED73B; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;User has been created.</span> </div> </div> </center>";

            clearform();
           // Response.Redirect("UserList.aspx"); //Page Not Found
        }

    }

    private void clearform()
    {
        txtuEmail.Value = "";
        txtuPin.Text = "";
    }
    public string TruncateLongString(string str, int maxLength)
    {//Check if the value is valid
        if (string.IsNullOrEmpty(str))
        {
            //Set valid empty string as string could be null
            str = string.Empty;
            return str;
        }
        else if (str.Length < maxLength)
        {
            return str;
        }
        return str.Substring(0, Math.Min(str.Length, maxLength));
    }

    protected void send_mail()
    {
        try
        {

            string user_id = "itinfo@ahsits.com";
            string pass = "zahera18";




            int port = 25;


            string emto = "sverma@ahsits.com";

            if (userEmail != null)
            {
                //emto = userEmail;
            }

            Random rm1 = new Random();


            string sub = "Your SF_APP account has been created";

            StringWriter sw = new StringWriter();
            HtmlTextWriter h = new HtmlTextWriter(sw);
            string messageBody = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"9\" style=\"border:1px solid #666; background-color:#CCEEFF;\">" +
"<thead> <tr>   <th>   <h3>Account Login Detail</h3></th></tr></thead><tbody> <tr> <td> Your SF_APP account has been created successfully; you can access your Control Panel here:        </td> </tr>" +
    "<tr> <td> <a href=\"http://anyonehome.ahsits.us/user/?aptkn=" + userToken + "&appd=" + rm1.Next() + "&whm=" + rm1.Next() + "&apuni=1\">Click Here</a> </td>  </tr>" +
    "<tr><td>E-mail id is &nbsp; :&nbsp; " + userEmail + "</td></tr><tr><td>Your Security Pin code is &nbsp; :&nbsp; " + userPin + "</td></tr> <tr>  <td>Regards,<br /> Web Master SF_APP</td></tr></tbody></table>";

            //       h.Write(" <h3 style=\"text-decoration: underline;\">Registration Details:</h3><br/> ");

            h.Write(messageBody);


            string str = sw.GetStringBuilder().ToString();

            string mess = str;
            cs_mail.custom_mail gm = new custom_mail();

            bool re = gm.godaddyMail(emto, "sverma@ahsits.com", "", "", port, user_id, pass, sub, mess);
            if (re == false)
            {
                // pendingmail.store_mail(emto, sub, mess);
                logerr.InnerHtml = "Email not sent to " + emto + "!";
            }
            else
            {
                logerr.InnerHtml = "<img src=\"../images/sahi.png\" alt=\"\" />Done!";
            }
        }
        catch (Exception ex)
        {
            logerr.InnerHtml = ex.Message;
        }
        finally
        {
            logerr.InnerHtml = "";
        }
    }

    private string createNewUser(string pSF_objId, string puPin, string puby, string puAccType)
    {
        string result = "0";
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand("app_proc_create_user", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("pSFid", pSF_objId);
            cmd.Parameters.AddWithValue("pPin", puPin);
            cmd.Parameters.AddWithValue("pBy", puby);
            cmd.Parameters.AddWithValue("pAccType", puAccType);

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    userToken = Convert.ToString(dr[0]);
                    result = "1";
                }
                else
                {
                    userToken = "";
                    result = "";
                }
            }
            else
            {
                result = "";
            }

        }
        catch (Exception ex)
        {
            result = ex.Message;
        }
        finally
        {
            con.Close();
        }
        return result;
    }

    private string createNewUser(string pSF_objId, string puPin, string puby, string puAccType, string pSF_id)
    {
        string result = "0";
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand("app_proc_create_user", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("pSFid", pSF_objId);
            cmd.Parameters.AddWithValue("pPin", puPin);
            cmd.Parameters.AddWithValue("pBy", puby);
            cmd.Parameters.AddWithValue("pAccType", puAccType);
            cmd.Parameters.AddWithValue("pSF_Only", pSF_id);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    userToken = Convert.ToString(dr[0]);
                    result = "1";
                }
                else
                {
                    userToken = "";
                    result = "";
                }
            }
            else
            {
                result = "";
            }

        }
        catch (Exception ex)
        {
            result = ex.Message;
        }
        finally
        {
            con.Close();
        }
        return result;
    }
}