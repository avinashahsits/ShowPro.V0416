﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_admin_adminpanel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string emailid_txt = txtEmail.Text.Trim();

        if (emailid_txt != "")
        {
            string pinCode = txtCode.Text.Trim();

            if (isValidUser(emailid_txt, pinCode))
            {
                Response.Redirect("wlcmadmin.aspx");
            }
            else
            {
                globalError.InnerHtml = "Please try again!";
                return;
            }
        }
        else
        {
            globalError.InnerHtml = "Please try again!";
            return;
        }
    }

    private bool isValidUser(string padmin_id, string pPinCode)
    {
        bool result = false;
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "select  auto_id,security_token, salesforce_obj_id, acc_type from user_master where" +
                " security_token='" + padmin_id + "' and security_pin='" + pPinCode + "' and acc_status='1'";

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    Session["ssnAdminUser"] = Convert.ToString(dr["salesforce_obj_id"]);
                    Session["ssnUserType"] = Convert.ToString(dr["acc_type"]);
                    Session["ssnUserFullName"] = Convert.ToString(dr["security_token"]);
                    //Session["ssnSecToken"] = Convert.ToString(dr["security_token"]);
                    result = true;
                }

            }
            else
            {
                Session["ssnUserId"] = null;
                Session["ssnUserType"] = null;
                result = false;

            }

        }
        catch (Exception ex)
        {
            result = false;

        }
        finally
        {
            con.Close();
        }
        return result;
    }
   
   
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("../Default.aspx");
    }
}