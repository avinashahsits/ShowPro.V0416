﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class mb_admin_edituser : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }

    string SF_User_id = "";

    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {

        }
        else
        {
            Session["ssnSecToken"] = null;
            Session["ssnUserId"] = null;
            Session["ssnUserType"] = null;
            Session["ssnUserEmailId"] = null;
            Session["ssnUserFullName"] = null;


            Response.Redirect("adminpanel.aspx");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        SF_User_id = GetParam("sfconida").Trim();
        if (SF_User_id != null)
        {
            // txtuEmail.Disabled = true;
            ArrayList contactInfo = getDataFromSF.getContactDataByID(SF_User_id);

            if (contactInfo.Count > 1)
            {

                txtuEmail.Value = Convert.ToString(contactInfo[0]);
            }
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        SF_User_id = GetParam("sfconida").Trim();

        if (SF_User_id != "")
        {
            string newPin = txtuPin.Text.Trim();

            if (newPin != "")
            {
                if (update_pin(SF_User_id, newPin))
                {
                    //Response.Redirect("manageuser.aspx");
                    logerr.InnerHtml = "<center> <div  style=\"margin: 0px; padding: 0px; background-color: #BED73B; color: rgb(0, 0, 0); font-family: 'Segoe UI', helvetica, arial, sans-serif; font-size: 12px;  font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; 	word-spacing: 0px; 	-webkit-text-stroke-width: 0px;	vertical-align:middle; display: block; width: 100%;\" > <div style=\"margin: 0px; padding: 2px 0px; color: white; font-size: 12px;\"> <span style=\"font-size: 16px;\">&nbsp;Your password has been updated  !</span> </div> </div> </center>";
                }
                else
                {
                    logerr.InnerHtml = "Try again!";
                    return;
                }
            }
        }
        else
        {
            logerr.InnerHtml = "";
            return;
        }
    }
    private bool update_pin(string pSF_User_id, string pnewPin)
    {
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        bool result = false;

        try
        {
            string sql = "update user_master set security_pin='" + pnewPin + "' where acc_type=2 and salesforce_obj_id='" + pSF_User_id + "'";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            cmd.ExecuteNonQuery();
            result = true;
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            result = false;
        }
        finally
        {
            con.Close();
        }
        return result;
    }
}