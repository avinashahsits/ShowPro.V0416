﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_admin_manageuser : System.Web.UI.Page
{
    string UserName = "", userEmailId = "";
    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {
            if (Session["ssnUserType"] != null)
            {

                string UserType = "";
                UserType = Convert.ToString(Session["ssnUserType"]);

                if (UserType == "1")
                {
                }
                else
                {
                    Response.Redirect("mbox.aspx?p2=adminpanel.aspx&p1=Please login to get access!");
                }
            }
            else
            {
                Response.Redirect("mbox.aspx?p2=adminpanel.aspx&p1=Please login to get access!");
            }
        }
        else
        {
            Session["ssnSecToken"] = null;
            Session["ssnUserId"] = null;
            Session["ssnUserType"] = null;
            Session["ssnUserEmailId"] = null;
            Session["ssnUserFullName"] = null;

            Response.Redirect("mbox.aspx?p2=adminpanel.aspx&p1=Please login to get access!");
        }


    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}