﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class demo_ajax_custDetail : System.Web.UI.Page
{ public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }

    string SF_User_id = "";

    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {
            
        }
        else
        {
            Response.Write("Please login as Admin!");
            return;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        SF_User_id = GetParam("sfconida").Trim();

        if (SF_User_id != "")
        {
            string isForDel = GetParam("act").Trim();
            if (isForDel == "2")
            {
                if (delthisUser(SF_User_id))
                {
                    string Js = "<script type=\"text/javascript\">get_recap();</script>";
                    Response.Write(Js);
                    return;
                }
                else
                {
                    Response.Write("object has not be deleted please try again!");
                }
            }
        }

        else
        {
            //sfconida
            string csData = getUserData();
            if (csData != "")
            {
                Response.Write(csData);
            }
        }

    }

    private bool delthisUser(string pSF_User_id)
    {
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        bool result = false;

        try
        {
            string sql = "delete user_master where acc_type=2 and salesforce_obj_id='" + pSF_User_id + "'";
           
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            cmd.ExecuteNonQuery();
            result = true;
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            result = false;
        }
        finally
        {
            con.Close();
        }
        return result;
    }
    private string getUserData()
    {
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        string result = "";

        try
        {
            string sql = "select salesforce_obj_id,security_pin,[dbo].[fn_YesNo](acc_type) as 'Acc. Type' from user_master where acc_type=2 order by last_updated desc";
            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                int i = 1;
                result = "<table id=\"no-more-tables\" style=\"width:100%;\" cellpadding=\"5\"><thead><tr><th class=\"numeric\" style=\"width:150px; text-align:left;\">Name</th><th class=\"numeric\" style=\"width:80px; text-align:left;\">Pin</th><th class=\"numeric\" style=\"width:80px; text-align:left;\">Action(s)</th></tr></thead>";
                while (dr.Read())
                {
                    string SF_id = "", login_Pin = "", userTye = "", NameInfo_2 = "N/A", contact_email = "N/A";

                    SF_id = Convert.ToString(dr["salesforce_obj_id"]).Trim();
                    login_Pin = Convert.ToString(dr["security_pin"]).Trim();
                    ArrayList contact_data = new ArrayList();

                    try
                    {
                        contact_data = getDataFromSF.getContactDataByID(SF_id);
                        contact_email = Convert.ToString(contact_data[0]);
                        //Session["ssnDispalyEmail"] = contact_email;
                        
                        if (contact_data.Count > 1)
                        {
                            NameInfo_2 = "<td class=\"numeric\" data-title=\"Name\" style=\"width:150px;\">" + contact_data[1] + "</td>";  
                        }
                    }
                    catch (Exception ex)
                    {
                        NameInfo_2 = "<td class=\"numeric\" data-title=\"Name\" style=\"width:150px;\">" + "N/A" + "</td>";
                    }

                    //string NameInfo = "<td class=\"numeric\" data-title=\"Name\">" + contact_data[0] + "</td><td class=\"numeric\" data-title=\"Email\">" + "emlid" + "</td>";

                    string ActionPanel = "<a href=\"javascript://\" onclick=\"editTihs('" + SF_id + "','" + contact_email + "');\">Edit</a>&nbsp;&nbsp;" +
                        "<a href=\"javascript://\" onclick=\"delTihs('" + SF_id + "');\">Delete</a>";

                    result += "<tr> " + NameInfo_2 + "<td class=\"numeric\" style=\"width:80px;\" data-title=\"Pin\"> " + login_Pin + "</td><td class=\"numeric\" data-title=\"Action\" style=\"width:80px;\">" + ActionPanel + "</td></tr>";


                    i++;

                }
                result += " </table>";

            }
            else
            {
                result = "";

            }
            dr.Close();
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            result = "";

        }
        finally
        {
            con.Close();
        }
        return result;
    }
    


}