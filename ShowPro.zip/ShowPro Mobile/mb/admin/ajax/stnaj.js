﻿function standardAjax(inputvar, url, divid1, divid2, AjaxThread) {
    var str, arr1, arr2, final_string;
    var http = new Array;

    document.getElementById(divid2).innerHTML =  '<center><font class=Heading_Font>Please wait...</font></center>';
    document.getElementById(divid1).style.display = 'block';
    try
    { http[AjaxThread] = new XMLHttpRequest(); }
    catch (e) {
        try
      { http[AjaxThread] = new ActiveXObject("Msxml2.XMLHTTP"); }
        catch (e) {
            try
        { http[AjaxThread] = new ActiveXObject("Microsoft.XMLHTTP"); }
            catch (e) {
                alert("Your browser does not support AJAX!");
                return false;
            }
        }
    }


    var params = inputvar;

    http[AjaxThread].open("POST", url, true);
    http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http[AjaxThread].setRequestHeader("Content-length", params.length);
    http[AjaxThread].setRequestHeader("Connection", "close");
    http[AjaxThread].onreadystatechange = function () {//Call a function when the state changes.
        if (http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) {
            str = http[AjaxThread].responseText;
            if (str == null)
                document.getElementById(divid2).style.display = 'none';
            var strScript = str.split('<script type="text/javascript">');

            if (strScript.length == 1)
                document.getElementById(divid2).innerHTML = str;
            else {
                document.getElementById(divid2).innerHTML = str;
                strScript = strScript[1].split('</script>');
                eval(strScript[0]); // to run any script called up from ajax page
            }

        }
    }
    http[AjaxThread].send(params);
}

function standardAjax2(inputvar, url, divid1, divid2, AjaxThread) {
    var str, arr1, arr2, final_string;
    var http = new Array;

    document.getElementById(divid2).innerHTML = '<center><img src=/"ajax/loader.gif/" /></center>';
    document.getElementById(divid1).style.display = 'block';
    try
    { http[AjaxThread] = new XMLHttpRequest(); }
    catch (e) {
        try
      { http[AjaxThread] = new ActiveXObject("Msxml2.XMLHTTP"); }
        catch (e) {
            try
        { http[AjaxThread] = new ActiveXObject("Microsoft.XMLHTTP"); }
            catch (e) {
                alert("Your browser does not support AJAX!");
                return false;
            }
        }
    }


    var params = inputvar;

    http[AjaxThread].open("POST", url, false);
    http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http[AjaxThread].setRequestHeader("Content-length", params.length);
    http[AjaxThread].setRequestHeader("Connection", "close");
    http[AjaxThread].onreadystatechange = function () {//Call a function when the state changes.
        if (http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) {
            str = http[AjaxThread].responseText;
            if (str == null)
                document.getElementById(divid2).style.display = 'none';
            var strScript = str.split('<script type="text/javascript">');

            if (strScript.length == 1)
                document.getElementById(divid2).innerHTML = str;
            else {
                document.getElementById(divid2).innerHTML = str;
                strScript = strScript[1].split('</script>');
                eval(strScript[0]); // to run any script called up from ajax page
            }

        }
    }
    http[AjaxThread].send(params);
}





function loadjscssfile(filename, filetype) {
    if (filetype == "js") { //if filename is a external JavaScript file
        var fileref = document.createElement('script')
        fileref.setAttribute("type", "text/javascript")
        fileref.setAttribute("src", filename)
    }
    else if (filetype == "css") { //if filename is an external CSS file
        var fileref = document.createElement("link")
        fileref.setAttribute("rel", "stylesheet")
        fileref.setAttribute("type", "text/css")
        fileref.setAttribute("href", filename)
    }
    if (typeof fileref != "undefined")
        document.getElementsByTagName("head")[0].appendChild(fileref)
}


function myajx(inputvar,url,divid1,divid2,AjaxThread,isAsnc)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;
  document.getElementById(divid2).innerHTML='<center class="ajaxLoad">Please wait...</center>'; //'<center><img src=/IMAGES/progress.gif /></center>';
  //document.getElementById(divid1).style.display='block';
  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, true);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	  str=http[AjaxThread].responseText;	
	   if(str==null)
	    document.getElementById(divid2).style.display='none';	   
	   var strScript=str.split('<script type="text/javascript">');
	   if(Formatting==0)
	    str = formatText(str,0);
	   else	   
	   if(strScript.length==1)
	    document.getElementById(divid2).innerHTML=str;
	   else
	    {	   //alert(str);	
	     document.getElementById(divid2).innerHTML=str;
	     strScript=strScript[1].split('</script>');
	     eval(strScript[0]); // to run any script called up from ajax page
	     }
	  
       }
     }
    http[AjaxThread].send(params);
   }
   
   function myajxIMG(inputvar,url,AjaxThread,DivId)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, false);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	  str=http[AjaxThread].responseText;	
	  //alert(DivId);
	 document.getElementById(DivId).innerHTML=str;//alert(str);	
       }
     }
    http[AjaxThread].send(params);
   }
   
   
function myajx2(inputvar,url,AjaxThread,isAsnc)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, false);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	  str=http[AjaxThread].responseText;//	alert(str);	
	 document.getElementById("hdimg1").value=str;
       }
     }
    http[AjaxThread].send(params);
   }

function myajx3(inputvar,url,AjaxThread,isAsnc)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, false);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	  str=http[AjaxThread].responseText;KBC=str;//	alert(str);	
	 //document.getElementById("hdimg1").value=str;
       }
     }
    http[AjaxThread].send(params);
   }
   
   
   
function bcdajax(inputvar,url,AjaxThread,isAsnc)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, true);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	    str=http[AjaxThread].responseText;//	alert(str);	
	    document.getElementById("ajdiv").innerHTML=str;
       }
       else
       {
       }
     }
    http[AjaxThread].send(params);
   }
   
   
   
   
   
   function myajx4(inputvar,url,AjaxThread,isAsnc)
 {
 
 
  var str,arr1,arr2,final_string;
  var http=new Array;  
  try
    {http[AjaxThread]=new XMLHttpRequest();}
   catch (e)
    {try
      {http[AjaxThread]=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e)
      {try
        {http[AjaxThread]=new ActiveXObject("Microsoft.XMLHTTP");}
      catch (e)
        {alert("Your browser does not support AJAX!");
         return false;
        }
        }
       }   
       
        //alert(url);
   var params = inputvar;
   
   http[AjaxThread].open("POST", url, false);
   http[AjaxThread].setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   http[AjaxThread].setRequestHeader("Content-length", params.length);
   http[AjaxThread].setRequestHeader("Connection", "close");
   http[AjaxThread].onreadystatechange = function() {//Call a function when the state changes.
	if(http[AjaxThread].readyState == 4 && http[AjaxThread].status == 200) 
	  {
	  
	  str=http[AjaxThread].responseText;
	  if (str == "0")
        {
            //if found any 0 Prompt user for take action 
            var mess = "Warning.. Some of the tasks are not checked. Please manually \"OK\" critical and other tasks before you proceed.";
           alert(mess);
            kbc = false;
        }
        else if (str == 1)
        {
           // Response.Write("1");
          kbc = true;
        }
        else if (str == 2)
        {

           
          kbc =2;
        }
        else
        {
           // Response.Write("3");
            kbc = true;
        }
       }
     }
    http[AjaxThread].send(params);
   }
   