﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebReference;

public partial class demo_ajax_checkSF_email : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {
            // Session["ssnUserType"] = "1";//--1 for Admin, 2 for user
            if (Session["ssnUserType"] != null)
            {
                string isAdmin = Convert.ToString(Session["ssnUserType"]);

                if (isAdmin == "1")
                {
                }
                else
                {
                    Response.Write("You are not Authorize to view this page! please login as Administrator.");
                    return;
                }

              
            }
            else
            {
                Response.Write("You are not Authorize to view this page! please login as Administrator.");
                return;

            }


        }

        else
        {
            Response.Write("You are not Authorize to view this page! please login as Administrator.");
            return;
        }


    }
  
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["ssnTempSF_Obj_id"] = null;
        string User_SF_Email = GetParam("p1").Trim();

        if (User_SF_Email != "")
        {
            string csData = checkThisEmail(User_SF_Email);//0 for Already Exists--> Ban this and 1 for go ahead
            if (csData != "")
            {
                if (csData == "1")
                {
                    Response.Write("");
                    string Js = "<script type=\"text/javascript\">enable_ahead();</script>";
                    Response.Write(Js);
                }
                else if (csData == "0")
                {
                    string Js = "<script type=\"text/javascript\"> alert('Already registered!');</script>";
                    Js = "<script type=\"text/javascript\">user_exists();</script>";

                    Response.Write("Already registered!");
                    Response.Write(Js);
                }               
                else if (csData != "")
                {
                    //string Js = "<script type=\"text/javascript\">user_exists();</script>";
                    Response.Write(csData);
                }
                
                else
                {
                    string Js = "<script type=\"text/javascript\"> alert('Already registered!');</script>";
                    Js = "<script type=\"text/javascript\">user_exists();</script>";

                    Response.Write("Already registered!");
                    Response.Write(Js);
                    
                }
            }
        }
        else
        {
            Response.Write("* Email id");
        }
        
    }

    private string checkThisEmail(string pUser_SF_Email)
    {
        if (login.bi != null)
        {
        }
        else
        {
            login.loginnow();
        }

        string result = "", SF_objId = "";

        SF_objId = getObjIdByEmail(pUser_SF_Email);

        if (SF_objId != "")
        {
        }
        else
        {
            return "Email id does not associated with any contact!";
        }

        SqlConnection con = new SqlConnection(appdb.dbconmars());

        try
        {
            SqlDataReader dr;

            SqlCommand cmd = new SqlCommand("app_proc_checkEmail", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("pSF_obj_id", SF_objId);

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    string isAlreadyRegistered = Convert.ToString(dr[0]);

                    if (isAlreadyRegistered != "")
                    {
                        result = isAlreadyRegistered;
                    }
                    //select 1; for go ahead

                    if (isAlreadyRegistered == "1")
                    {
                        Session["ssnTempSF_Obj_id"] = SF_objId;
                    }
                    else
                    {
                        Session["ssnTempSF_Obj_id"] = null;
                    }

                }
                else
                {
                    result = "0";
                }
            }
            else
            {
                result = "0";
            }

        }
        catch (Exception ex)
        {
            result = ex.Message;
        }
        finally
        {
            con.Close();
        }
        return result;
    }

    private string getObjIdByEmail(string pUser_SF_Email)
    {
        string result = "";
        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;

        try
        {


            //select Id from Creg__c where Emailid__c='"+"' and encpwd='"+"'";
            //qr = login.bi.query("select Id,Emailid__c,encpwd__c from Creg__c where Emailid__c='" + id + "'");// and encpwd__c='" + pass + "'");

            qr = login.bi.query("select Id from Contact where Email='" + pUser_SF_Email + "'");

            bool done = false;
            if (qr.size > 0)
            {
                
                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Contact con = (Contact)qr.records[i];

                        string emlid = con.Email;
                        string cid = con.Id;


                        if (cid != "")
                        {
                            result = cid;
                        }
                        else
                        {
                            result = "";
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }
               

            }
            else
            {
                result = "";

            }
        }
        catch (Exception ex)
        {
            result = "";

        }
        return result;
    }

}