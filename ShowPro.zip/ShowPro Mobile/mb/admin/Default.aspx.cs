﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_admin_Default : System.Web.UI.Page
{
    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnAdminUser"] != null)
        {


        }
        else
        {
            Session["ssnSecToken"] = null;
            Session["ssnUserId"] = null;
            Session["ssnUserType"] = null;
            Session["ssnUserEmailId"] = null;
            Session["ssnUserFullName"] = null;

            Response.Redirect("adminpanel.aspx");
        }


    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}