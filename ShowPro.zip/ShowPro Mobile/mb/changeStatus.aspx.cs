﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class mb_changeStatus : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList pndgs = new ArrayList();

        if (Session["ssnAcceptedAppts"] != null)
        {
            pndgs = (ArrayList)Session["ssnAcceptedAppts"];
        }
        else
        {

            return;
        }
        string id = "";


        id = GetParam("p1").Trim();

        if (id == "")
        {
            return;
        }


        var query = from getAppointments.AcceptedApptInfo appts in pndgs
                    // where appts.Appt_id = id
                    select appts;

        int counter = 1;
        string output = " <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 98%;\">";

        foreach (getAppointments.AcceptedApptInfo apptInfo in query)
        {
            string AjaxDivId = "ajx_" + counter;
            string ap_id = apptInfo.Appt_id;

            if (ap_id == id)
            {
                //href="apptdetail.aspx?p1="
                backLink.HRef = "apptdetail.aspx?p1=" + ap_id.Trim();


                output += "<tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px; border-bottom:1px solid #eee;\">" +
                       apptInfo.Appt_date.ToShortDateString() + " </td> </tr>" +
               "<tr> <td colspan=\"4\">" +
                       apptInfo.Appt_time + "  </td> </tr>" +
               "<tr>  <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                       apptInfo.Prop_name + " <br />" +
                       apptInfo.Prop_address + " </td></tr>" +
               "<tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\" colspan=\"4\">" +
                   apptInfo.Client_name + "<br />";

                if (apptInfo.Client_phone != "")
                {
                    output += apptInfo.Client_phone + " <br />";
                }
                else
                {
                    output += "";
                }

                output += apptInfo.Client_email + " </td>  </tr>" + "<tr>   <td align=\"center\" valign=\"top\" colspan=\"4\" style=\"border-bottom: 1px solid #ccc;\">" +
                       "<div id=\"" + AjaxDivId + "\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"10\"><tr>";

                string buttons = "", status = "";
                status = apptInfo.Appt_status.Trim();

                if (status == "Accepted")
                {
                    buttons = "<td> <input type=\"button\"  data-mini=\"true\" value=\"Reject\" onclick=\"appt_reject('" + apptInfo.Appt_id + "','" + AjaxDivId + "');\" /></td>" +
                       "<td> <input type=\"button\"  data-mini=\"true\" value=\"Home Leased\" onclick=\"appt_cancel('" + apptInfo.Appt_id + " ','" + AjaxDivId + "');\" /> </td> " +
                       "<td> <input type=\"button\" disabled=\"disabled\" data-mini=\"true\" value=\"Accept\" />  </td> ";

                }
                else if (status == "Rejected")
                {
                    buttons = "<td> <input type=\"button\" disabled=\"disabled\"  data-mini=\"true\" value=\"Reject\" /></td>" +
                       "<td> <input type=\"button\"  data-mini=\"true\" value=\"Home Leased\" onclick=\"appt_cancel('" + apptInfo.Appt_id + " ','" + AjaxDivId + "');\" /> </td> " +
                       "<td> <input type=\"button\"  data-mini=\"true\" value=\"Accept\" onclick=\"appt_acpt('" + apptInfo.Appt_id + "','" + AjaxDivId + "');\" />  </td> ";

                }
                else
                {
                    buttons = "<td> <input type=\"button\" disabled=\"disabled\"  data-mini=\"true\" value=\"Reject\"  /></td>" +
                       "<td> <input type=\"button\" disabled=\"disabled\" data-mini=\"true\" value=\"Home Leased\" /> </td> " +
                       "<td> <input type=\"button\" disabled=\"disabled\" data-mini=\"true\" value=\"Accept\"  />  </td> ";

                }


                output += buttons + "</tr> </table> </div> </td> </tr>";

                counter++;
            }

        }
        output += "</table>";

        main_Div.InnerHtml = output;

    }
}