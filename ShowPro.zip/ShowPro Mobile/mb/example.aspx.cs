﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebReference;
using System.Xml;
using System.Collections;

public partial class mb_example : System.Web.UI.Page
{
    string sf_user_id = "003i00000073R2EAAU";
    string App_id = "a0Ci0000005LqPlEAK";

    string strErrMess = "";
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //System.Web.UI.HtmlControls.HtmlInputText intext = (System.Web.UI.HtmlControls.HtmlInputText)form1.FindControl("mode1");

        //intext.Value = "11/30/2013";
    }

    protected void btnFoolowUp_Click(object sender, EventArgs e)
    {
        if (App_id != "")
        {
        }
        else
        {
           // appointment_id = GetParam("p1").Trim();
        }

        if (App_id != "")
        {
            string date1 = GetParam("mode1").Trim();// txtdate.Value.Trim();//mydate.Value.Trim();mydate

            string date = common.USA_date(date1);

            if (date != "" && date != "0")
            {
            }
            else
            {
                dyMessDefault.InnerHtml = "please enter valid date format!";
                return;
            }

            DateTime dt = DateTime.Parse(date);

            string from = ddlStart.SelectedValue.Trim();

            if (from != "" && from != "0")
            {
            }
            else
            {
                // dyMessDefault.InnerHtml = "From Required !";
                return;
            }


            if (modify_appt(sf_user_id, App_id, dt, from))
            {
                //Response.End();
               // Server.Transfer("back.aspx");
               Response.Redirect("back.aspx");
               
            }
            else
            {
                dyMessDefault.InnerHtml = strErrMess;
            }
        }
    }

    private bool modify_appt(string p_User_id, string pAppt_id, DateTime pdate, string pFrom)
    {
        bool result = false;



        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }


            //SELECT Appointment_Date__c, Contact_Email__c, From__c, Invite_Status__c, Property_Name__c, To__c, Id, Contact__c, Case__c FROM Appointment__c where Contact__c='003d000000PgrzlAAB' and Invite_Status__c='Invited' order by LastModifiedDate desc
            //string sql_appts_byid_backup = "SELECT Appointment_Date__c, Name, Case__c, Contact__c, Contact_Email__c, CreatedById, CreatedDate, DateTime_Invite_Sent__c, Day__c, IsDeleted, Email__c, From__c, Invite_Status__c, LastActivityDate, LastModifiedById, LastModifiedDate, Property__c, Property_name__c, Id, SystemModstamp, To__c FROM Appointment__c where Contact__c='" + p_User_id + "' and Id='" + pAppt_id + "'";

            string sql_appts_byid = "SELECT Appointment_Date__c, Name, Case__c, Contact__c, Contact_Email__c, CreatedById, CreatedDate, DateTime_Invite_Sent__c, Day__c, IsDeleted, Email__c, From__c, Invite_Status__c, LastActivityDate, LastModifiedById, LastModifiedDate, Property__c, Property_name__c, Id, SystemModstamp, To__c,Property__r.Id,Property__r.Concurrent_Showings_Allowed__c,Case__r.Slot_Limit__c FROM Appointment__c where Contact__c='" + p_User_id + "' and Id='" + pAppt_id + "'";
            //Property__r.Id,Property__r.Concurrent_Showings_Allowed__c,Case__r.Slot_Limit__c
            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Appointment__c con = (Appointment__c)qr.records[i];

                        string cid = con.Id;

                        Appointment__c modify_app = new Appointment__c();

                        modify_app.Appointment_Date__cSpecified = true;
                        modify_app.Appointment_Date__c = pdate;

                        modify_app.Id = cid.Trim();


                        string property_id = ""; int CCS = 1, slot_Limit = 2;

                        if (con.Property__r.Id != null)
                        {
                            property_id = con.Property__r.Id;
                        }
                        else
                        {
                            property_id = "";
                        }

                        if (con.Property__r.Concurrent_Showings_Allowed__c != null)
                        {
                            CCS = Convert.ToInt32(con.Property__r.Concurrent_Showings_Allowed__c.Trim());
                        }
                        else
                        {
                            CCS = 1;
                        }
                        if (con.Case__r.Slot_Limit__c != null)
                        {
                            slot_Limit = Convert.ToInt32(con.Case__r.Slot_Limit__c);
                            if (slot_Limit >= 30)
                            {
                                slot_Limit = ((slot_Limit) / 30);
                            }
                        }
                        else
                        {
                            slot_Limit = 2;
                        }

                        //changes on 21 Sept 2013
                        //check here for wxisting Appointments
                        //if allowed then go ahead else show error or skip in case of Recurring!

                        if (ValidateSlotTiming(slot_Limit, CCS, property_id, cid))
                        {

                            //if Concurrent showing them change the Start N End time
                            //Session["ssnapptFU_book_start"] = appt.startTime;
                            //Session["ssnapptFU_book_end"] = appt.endTime;
                            if (Session["ssnapptFU_goFor_CCS"] != null)
                            {
                                string dStart = "", dEnd = "";

                                int stend = 0, st = 0;


                                if (Session["ssnapptFU_book_start"] != null)
                                {
                                    try
                                    {
                                        st = Convert.ToInt32(Session["ssnapptFU_book_start"]);
                                        dStart = GetTimeFromNumber(st);
                                    }
                                    catch (Exception ex)
                                    {

                                    }
                                }

                                if (Session["ssnapptFU_book_end"] != null)
                                {
                                    try
                                    {
                                        stend = Convert.ToInt32(Session["ssnapptFU_book_end"]);
                                        dEnd = GetTimeFromNumber(stend);
                                    }
                                    catch (Exception ex)
                                    {

                                    }
                                }
                                if (dStart != "" && dStart != "0")
                                {
                                    modify_app.From__c = dStart;
                                }

                                if (dEnd != "" && dEnd != "0")
                                {
                                    modify_app.To__c = dEnd;
                                }

                            }
                            else
                            {
                                string dStart = pFrom, dEnd = "";

                                int stend = 0, st = 0;


                                st = GetNumberFromTime(pFrom);

                                stend = (st - slot_Limit);

                                dStart = GetTimeFromNumber(st);
                                if (dStart != "" && dStart != "0")
                                {
                                    modify_app.From__c = dStart;
                                }

                                dEnd = GetTimeFromNumber(stend);
                                if (dEnd != "" && dEnd != "0")
                                {
                                    modify_app.To__c = dEnd;
                                }
                            }
                        }
                        else
                        {
                            strErrMess = "Appointment already exists! please select another time";
                            dyMessDefault.InnerHtml = "Appointment already exists! please select another time";
                            return false;
                        }

                        sObject[] to = new sObject[1];
                        to[0] = modify_app;

                        SaveResult[] saveResults = login.bi.update(to); //login.bi.create(to);

                        // Handle the results  

                        for (int ik = 0; ik < saveResults.Length; ik++)
                        {
                            // Determine whether create() succeeded or had errors  

                            if (saveResults[ik].success)
                            {
                                // No errors, so retrieve the Id created for this record  
                                //Session.Add("ssnCAcId", saveResults[i].id);
                                //Server.Transfer("editcust.aspx?cstid=" + saveResults[i].id);
                                string resulkjhjkt = saveResults[i].id;
                                result = true;
                            }
                            else
                            {

                                // Handle the errors  

                                foreach (Error error in saveResults[i].errors)
                                {
                                    strErrMess = "<br/> Error code is: {0}" + error.statusCode.ToString() + "Error message: {0}" + error.message;
                                    result = false;
                                }
                            }
                        }

                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = false;

            }
        }
        catch (Exception ex)
        {
            strErrMess = ex.Message;
            result = false;
        }
        finally
        {
        }

        return result;
    }

    private bool ValidateSlotTiming(int pSlotLimit, int pConCurrentShowings, string pProp_id, string pAppointmentID)
    {
        bool itIsValid = false;

        string date1 = GetParam("mode1").Trim();// txtdate.Value.Trim();//mydate.Value.Trim();mydate

        string date = common.USA_date(date1);



        date = common.SF_date(date);

        DateTime dt1 = Convert.ToDateTime(date);

        if (dt1 < DateTime.Today)
        {
            dyMessDefault.InnerHtml = "You can't make appointment in past!";
            return false;
        }
        else
        {
            dyMessDefault.InnerHtml = "";
        }

        string dStart = ddlStart.Text.Trim();
        string dEnd = "";

        int slotlimit = 2;

        if (pSlotLimit != null && pSlotLimit > 1)
        {
            try
            {
                slotlimit = pSlotLimit;
            }
            catch (Exception ex)
            {
                slotlimit = 2;
            }
        }

        int intStart = GetNumberFromTime(dStart);
        int intEnd = (intStart - slotlimit);

        //check appts for this parameters if found then pick Start,End time for the Appt. and book/change Appt. 
        DateTime dt = DateTime.Parse(date);


        int ThisSlotTime = intStart;


        string slotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";

        string pContact = "";

        int concurrentShowings = 1;

        if (pConCurrentShowings != null && pConCurrentShowings > 1)
        {
            try
            {
                concurrentShowings = pConCurrentShowings;
            }
            catch (Exception ec)
            {
                concurrentShowings = 1;
            }
        }

        string propId = "";
        if (pProp_id != "")
        {
            try
            {
                propId = pProp_id;
            }
            catch (Exception ec)
            {
                propId = "";
            }
        }


        if (Session["ssnUserId"] != null)
        {
            pContact = Convert.ToString(Session["ssnUserId"]);
        }

        int apptCounter = getCountAppointments(propId, pContact, dt, ThisSlotTime, slotSoql, pAppointmentID);
        //get here Appt_start & appt_end ArrayList as Booking module the get start,end for this timeSlot


        //0 means there are some error or there is no Appointment with this Property, Agent,Date and Time Combination
        if (apptCounter != 0 && apptCounter < concurrentShowings)
        {
            // ConcurrentShowings

            int stend = 0, st = 0;
            dEnd = GetTimeFromNumber(intEnd);
            //Session["ssnapptChange_book_start"] = null;
            //Session["ssnapptChange_book_end"] = null;

            if (Session["ssnapptFU_book_start"] != null)
            {
                try
                {
                    st = Convert.ToInt32(Session["ssnapptFU_book_start"]);
                    dStart = GetTimeFromNumber(st);
                }
                catch (Exception ex)
                {

                }
            }

            if (Session["ssnapptFU_book_end"] != null)
            {
                try
                {
                    stend = Convert.ToInt32(Session["ssnapptFU_book_end"]);
                    dEnd = GetTimeFromNumber(stend);
                }
                catch (Exception ex)
                {
                    dEnd = GetTimeFromNumber(intEnd);
                }
            }



            if (dStart != "" && dStart != "0")
            {
                ddlStart.Text = dStart;
            }

            //if (dEnd != "" && dEnd != "0")
            //{
            //    ddlEnd.Text = dEnd;
            //}


            Session["ssnapptFU_goFor_CCS"] = 1;

            //cccsTd.InnerHtml = "Concurrent showing allowed <br/> so timing has been taken from previous appointment.!";

            //dyMessDefault.InnerHtml = "";
            //btnSave.CssClass = "cssbtn";
            //btnFoolowUp.Enabled = true;

            itIsValid = true;

        }
        else
        {
            // normal process
            Session["ssnapptFU_goFor_CCS"] = null;

            if (isValidAppointment(sf_user_id, intStart, date, slotlimit, propId, pAppointmentID))
            {
                //int ApptEnd_No = intStart - 2;

                dEnd = GetTimeFromNumber(intEnd);

                //if (dEnd != "")
                //{
                //    ddlEnd.Text = dEnd;
                //}

                dyMessDefault.InnerHtml = "";
                //btnSave.CssClass = "cssbtn";
                // btnFoolowUp.Enabled = true;

                itIsValid = true;
            }
            else
            {
                dyMessDefault.InnerHtml = "Appointment already exists! please select another time";
                //Appointment already exists! please select another time
                //btnSave.CssClass = "ui-icon-locked";
                //  btnFoolowUp.Enabled = false;
                itIsValid = false;
            }
        }
        return itIsValid;
    }

    private int getCountAppointments(string propId, string pContact, DateTime pDate, int slotTime, string pLimitSoql, string pAppt_id)
    {
        int result = 0;
        string errorMessage = "";

        Dictionary<int, getAppointmentData.ApptSlotTime> slotTiming = new Dictionary<int, getAppointmentData.ApptSlotTime>();


        string thisAppt_id = "";

        if (pAppt_id != null)
        {
            thisAppt_id = pAppt_id;
        }

        result = getAppointmentData.countAppts(propId, pContact, pDate, slotTime, pLimitSoql, ref slotTiming, ref errorMessage, thisAppt_id);

        foreach (KeyValuePair<int, getAppointmentData.ApptSlotTime> pair in slotTiming)
        {
            //Console.WriteLine("{0}, {1}", pair.Key, pair.Value);

            if (pair.Key == slotTime)
            {
                getAppointmentData.ApptSlotTime appt = new getAppointmentData.ApptSlotTime();
                appt = pair.Value;

                Session["ssnapptFU_book_start"] = appt.startTime;
                Session["ssnapptFU_book_end"] = appt.endTime;

            }

        }


        return result;
    }
    private bool isValidAppointment(string pSF_User_id, int pIntStart, string pSF_Date, int pSlotLimit, string pProp_Id, string pAppt_id)
    {
        bool result = false;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }



            int intSlotLimit = 2;
            if (pSlotLimit > 0)
            {
                try
                {
                    intSlotLimit = pSlotLimit;
                }
                catch (Exception ex)
                {
                    intSlotLimit = 2;
                }
            }


            //changes on 21 Sept 2013
            //changes should come here:: one slot will replace with Slot Limit for this Property
            //so we need from the Property Object:
            // Slotlimit & ConcurrentShowingAlloweds
            //

            string propId = "";
            if (pProp_Id != "")
            {
                try
                {
                    propId = pProp_Id;
                }
                catch (Exception ec)
                {
                    propId = "";
                }
            }




            int intEnd = (pIntStart - intSlotLimit);

            // string slotSoql = " (NoTo__c =" + intEnd + " and NoFrom__c = " + pIntStart + ") ";
            //string slotSoql = " (NoTo__c >=" + intEnd + " and NoFrom__c >= " + pIntStart + ") ";
            string slotSoql = " ( (NoFrom__c >=" + pIntStart + " and NoTo__c<=" + pIntStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";

            // string sql_appts_byid = " SELECT count(Id) FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
            //" Appointment_Date__c=" + pSF_Date + "  and Property__c='" + propId + "' and Contact__c='" + pSF_User_id + "'  and " + slotSoql;


            string pThisapptId = "", sql_appts_byid = "";

            if (pAppt_id != "")
            {
                pThisapptId = pAppt_id;
            }

            if (pThisapptId != "")
            {
                sql_appts_byid = " SELECT count(Id) FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and id <>'" + pThisapptId + "' and " +
            " Appointment_Date__c=" + pSF_Date + " and Contact__c='" + pSF_User_id + "'  and " + slotSoql;
            }
            else
            {
                sql_appts_byid = " SELECT count(Id) FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
              " Appointment_Date__c=" + pSF_Date + " and Contact__c='" + pSF_User_id + "'  and " + slotSoql;
            }

            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {
                    int howManyAppt = 0;

                    for (int i = 0; i < qr.records.Length; i++)
                    {

                        AggregateResult ar = (AggregateResult)qr.records[i];

                        string Count = "";

                        foreach (XmlElement e in ar.Any)
                        {

                            //Status = System.String.Format("{0} - {1}", e.LocalName, e.InnerText);
                            Count = System.String.Format(e.InnerText);
                        }
                        if (Count != "")
                        {
                            howManyAppt = Convert.ToInt32(Count);
                        }
                        else
                        {
                            howManyAppt = 0;
                        }


                    }
                    if (qr.done)
                    {
                        if (howManyAppt > 0)
                        {
                            result = false;
                        }
                        else
                        {
                            result = true;
                        }
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = true;// no data found for this timing! go Ahead...
            }
        }
        catch (Exception ex)
        {
            result = false;
        }
        finally
        {
        }
        return result;
    }

    private string GetTimeFromNumber(int pStart)
    {
        string result = "";

        if (pStart < 1)
        {
            return "0";
        }

        switch (pStart)
        {
            #region Converting Number to Time
            case 35:
                result = "6:00 a.m."; break;

            case 34:
                result = "6:30 a.m."; break;

            case 33:
                result = "7:00 a.m."; break;

            case 32:
                result = "7:30 a.m."; break;

            case 31:
                result = "8:00 a.m."; break;


            case 30:
                result = "8:30 a.m."; break;


            case 29:
                result = "9:00 a.m."; break;


            case 28:
                result = "9:30 a.m."; break;


            case 27:
                result = "10:00 a.m."; break;


            case 26:
                result = "10:30 a.m."; break;


            case 25:
                result = "11:00 a.m."; break;


            case 24:
                result = "11:30 a.m."; break;


            case 23:
                result = "12:00 p.m."; break;


            case 22:
                result = "12:30 p.m."; break;


            case 21:
                result = "1:00 p.m."; break;


            case 20:
                result = "1:30 p.m."; break;


            case 19:
                result = "2:00 p.m."; break;

            case 18:
                result = "2:30 p.m."; break;


            case 17:
                result = "3:00 p.m."; break;


            case 16:
                result = "3:30 p.m."; break;


            case 15:
                result = "4:00 p.m."; break;


            case 14:
                result = "4:30 p.m."; break;


            case 13:
                result = "5:00 p.m."; break;


            case 12:
                result = "5:30 p.m."; break;


            case 11:
                result = "6:00 p.m."; break;


            case 10:
                result = "6:30 p.m."; break;


            case 9:
                result = "7:00 p.m."; break;


            case 8:
                result = "7:30 p.m."; break;


            case 7:
                result = "8:00 p.m."; break;


            case 6:
                result = "8:30 p.m."; break;


            case 5:
                result = "9:00 p.m."; break;


            case 4:
                result = "9:30 p.m."; break;


            case 3:
                result = "10:00 p.m."; break;


            case 2:
                result = "10:30 p.m."; break;


            case 1:
                result = "11:00 p.m."; break;


            default:
                result = "0";
                break;
            #endregion
        }

        return result;
    }

    private int GetNumberFromTime(string pStart)
    {
        int result = 0;


        if (pStart == "")
        {
            return 0;
        }

        switch (pStart)
        {
            #region Converting Time to Number
            case "6:00 a.m.":
                result = 35; break;

            case "6:30 a.m.":
                result = 34; break;

            case "7:00 a.m.":
                result = 33; break;

            case "7:30 a.m.":
                result = 32; break;

            case "8:00 a.m.":
                result = 31; break;


            case "8:30 a.m.":
                result = 30; break;


            case "9:00 a.m.":
                result = 29; break;


            case "9:30 a.m.":
                result = 28; break;


            case "10:00 a.m.":
                result = 27; break;


            case "10:30 a.m.":
                result = 26; break;


            case "11:00 a.m.":
                result = 25; break;


            case "11:30 a.m.":
                result = 24; break;


            case "12:00 p.m.":
                result = 23; break;


            case "12:30 p.m.":
                result = 22; break;


            case "1:00 p.m.":
                result = 21; break;


            case "1:30 p.m.":
                result = 20; break;


            case "2:00 p.m.":
                result = 19; break;

            case "2:30 p.m.":
                result = 18; break;


            case "3:00 p.m.":
                result = 17; break;


            case "3:30 p.m.":
                result = 16; break;


            case "4:00 p.m.":
                result = 15; break;


            case "4:30 p.m.":
                result = 14; break;


            case "5:00 p.m.":
                result = 13; break;


            case "5:30 p.m.":
                result = 12; break;


            case "6:00 p.m.":
                result = 11; break;


            case "6:30 p.m.":
                result = 10; break;


            case "7:00 p.m.":
                result = 9; break;


            case "7:30 p.m.":
                result = 8; break;


            case "8:00 p.m.":
                result = 7; break;


            case "8:30 p.m.":
                result = 6; break;


            case "9:00 p.m.":
                result = 5; break;


            case "9:30 p.m.":
                result = 4; break;


            case "10:00 p.m.":
                result = 3; break;


            case "10:30 p.m.":
                result = 2; break;


            case "11:00 p.m.":
                result = 1; break;


            default:
                result = 0;
                break;
            #endregion
        }

        return result;
    }
}