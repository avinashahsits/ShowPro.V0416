﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using WebReference;

public partial class mb_settimeoff : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }


    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            //SF_Contact_id = Convert.ToString(Session["ssnUserId"]);
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string SelectedDate = GetParam("txtdate").Trim();
        //days.InnerHtml = SelectedDate;
    }

    //when all day is off then run this
    private bool fixException(ref string errmess)
    {
        bool result = false;
        try
        {
            errmess = "";
            string agentId = "", strStarttime = "", strEndTime = "", strSelectedDate = "";

            int start = 0, end = 0;

            if (Session["ssnUserId"] != null)
            {
                agentId = Convert.ToString(Session["ssnUserId"]);
            }

            DateTime dtselect=Convert.ToDateTime(GetParam("txtdate").Trim());
            strSelectedDate = String.Format("{0:MM/dd/yyyy}", dtselect);
            //strSelectedDate = GetParam("txtdate").Trim();//get this from Previous page as Query String!
            strStarttime = GetParam("ddlStart").Trim();
            strEndTime = GetParam("ddlEnd").Trim();

            if (strStarttime != "" && strEndTime != "")
            {
                start = GetNumberFromTime(strStarttime);
                end = GetNumberFromTime(strEndTime);
            }

            if (start == 0 || end == 0)
            {
                errmess = "Please select proper timing!.";
                return false;
            }
            else
            {
                errmess = "";
            }


            if (start > end)
            {
               
            }
            else
            {
                errmess = "Please select proper timing!.";
                return false;
            }

            string recType2 = GetParam("repeat").Trim();//for the Repeat Hidden filed!


            #region Start Recuring here
            //int frequency = Convert.ToInt32(countTYpe.Value.Trim());
            if (recType2 == "0")
            {

                DateTime dt = Convert.ToDateTime(strSelectedDate);
                string DayName = String.Format("{0:dddd}", dt);

                string slot_name = DayName + " , " + strSelectedDate + " (" + strStarttime + " - " + strEndTime + ")";


                if (isValidException(agentId, start, end, strSelectedDate, ref errmess))
                {
                    errmess = "";
                    string record_id = inserNewReCord(agentId, slot_name, DayName, strSelectedDate, strStarttime, strEndTime, "2");


                    if (record_id.Length > 1)
                    {
                        //txtaDate.Value = "";
                        //Response.Redirect("rcal.aspx?mess=1&mcode=1");
                        //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                        result = true;
                    }
                }
                else
                {
                    result = false;
                   // errmess = "Appointment exists on this timing!";
                }
            }
            else
            {
                string recType = GetParam("schedule_days").Trim();
                int frequencyCount = Convert.ToInt32(noofdays.Value.Trim());
                DateTime selDate = DateTime.Parse(strSelectedDate);

                int skip_counter = 0;

                if (recType == "Weekly")
                {
                    if (frequencyCount > 1)
                    {

                    }
                    else
                    {
                        errmess = "Count is less than 1!";
                        return false;
                    }

                    string record_id = "";
                    for (int i = 0; i < frequencyCount; i++)
                    {

                        //string selDate_next = common.Convert_USA_date(selDate);
                        string selDate_next = selDate.ToShortDateString();
                        
                        
                        DateTime dt = Convert.ToDateTime(selDate_next);
                        string DayName = String.Format("{0:dddd}", dt);

                        string slot_name = DayName + " , " + selDate_next + " (" + strStarttime + " - " + strEndTime + ")";


                        if (isValidException(agentId, start, end, selDate_next, ref errmess))
                        {
                            errmess = "";
                            record_id += inserNewReCord(agentId, slot_name, DayName, selDate_next, strStarttime, strEndTime, "2");
                        }
                        else
                        {
                            //logerr.InnerHtml = "Appointment exists on this timing!";
                            //break;
                            skip_counter++;
                        }


                        //add one more week
                        selDate = selDate.AddDays(7);
                    }

                    if (record_id.Length > 1)
                    {
                        // txtaDate.Value = "";
                        if (skip_counter > 0)
                        {
                            //mSkip
                            //Response.Redirect("rcal.aspx?mess=1&mcode=1&mSkip=1");
                            result = true;
                        }
                        else
                        {
                            result = true;
                            //Response.Redirect("rcal.aspx?mess=1&mcode=1");
                        }
                    }
                }
                else if (recType == "Monthly")
                {
                    if (frequencyCount > 1)
                    {
                    }
                    else
                    {
                        errmess = "Count is less than 1!";
                        return false;
                    }

                    string record_id = "";
                    for (int i = 0; i < frequencyCount; i++)
                    {
                        //string selDate_next = common.Convert_USA_date(selDate);
                        string selDate_next = selDate.ToShortDateString();
                        
                        DateTime dt = Convert.ToDateTime(selDate_next);
                        string DayName = String.Format("{0:dddd}", dt);

                        string slot_name = DayName + " , " + selDate_next + " (" + strStarttime + " - " + strEndTime + ")";


                        if (isValidException(agentId, start, end, selDate_next, ref errmess))
                        {
                            errmess = "";
                            record_id += inserNewReCord(agentId, slot_name, DayName, selDate_next, strStarttime, strEndTime, "2");
                        }
                        else
                        {
                            // logerr.InnerHtml = "Appointment exists on this timing!";
                            // break;
                            skip_counter++;
                        }



                        //add one more month
                        selDate = selDate.AddMonths(1);
                    }

                    if (record_id.Length > 1)
                    {
                        //txtaDate.Value = "";
                        if (skip_counter > 0)
                        {
                            result = true;
                            //mSkip
                            //  Response.Redirect("rcal.aspx?mess=1&mcode=1&mSkip=1");
                        }
                        else
                        {
                            result = true;
                            //Response.Redirect("rcal.aspx?mess=1&mcode=1");
                        }
                    }
                }
                else if (recType == "Day")
                {
                    if (frequencyCount > 1)
                    {
                    }
                    else
                    {
                        errmess = "Count is less than 1!";
                        return false;
                    }
                    string record_id = "";
                    for (int i = 0; i < frequencyCount; i++)
                    {
                        //string selDate_next = common.Convert_USA_date(selDate);
                        string selDate_next = selDate.ToShortDateString();
                        
                        DateTime dt = Convert.ToDateTime(selDate_next);
                        string DayName = String.Format("{0:dddd}", dt);

                        string slot_name = DayName + " , " + selDate_next + " (" + strStarttime + " - " + strEndTime + ")";


                        if (isValidException(agentId, start, end, selDate_next, ref errmess))
                        {
                            errmess = "";
                            record_id += inserNewReCord(agentId, slot_name, DayName, selDate_next, strStarttime, strEndTime, "2");
                        }
                        else
                        {
                            //logerr.InnerHtml = "Appointment exists on this timing!";
                            //break;
                            skip_counter++;
                        }



                        //add one more day
                        selDate = selDate.AddDays(1);
                    }
                    if (record_id.Length > 1)
                    {
                        // txtaDate.Value = "";
                        if (skip_counter > 0)
                        {
                            result = true;
                            //mSkip
                            //   Response.Redirect("rcal.aspx?mess=1&mcode=1&mSkip=1");
                        }
                        else
                        {
                            result = true;
                            //Response.Redirect("rcal.aspx?mess=1&mcode=1");
                        }
                        //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                    }

                }
                else
                {
                    DateTime dt = Convert.ToDateTime(strSelectedDate);

                    string DayName = String.Format("{0:dddd}", dt);

                    string slot_name = DayName + " , " + strSelectedDate + " (" + strStarttime + " - " + strEndTime + ")";


                    if (isValidException(agentId, start, end, strSelectedDate, ref errmess))
                    {
                        errmess = "";
                        string record_id = inserNewReCord(agentId, slot_name, DayName, strSelectedDate, strStarttime, strEndTime, "2");

                        if (record_id.Length > 1)
                        {
                            result = true;
                        }
                    }
                    else
                    {
                        result = false;
                       //errmess = "Appointment exists on this timing!";
                    }

                }

            }
            #endregion


            //result = true;
        }
        catch (Exception ex)
        {
            // change on 28 Oct 2013
            errmess = "Invalid date format. Please use MM/DD/YYYY";
            //errmess = ex.Message;
            result = false;
        }
        return result;
    }

    
    //when Day-off (All Day)
    private bool fixDayOff(ref string errmess, ref string recurring_message)
    {
        bool result = false;
        try
        {
            errmess = "";
            string agentId = "", strSelectedDate = "";

            if (Session["ssnUserId"] != null)
            {
                agentId = Convert.ToString(Session["ssnUserId"]);
            }

            DateTime dtselect = Convert.ToDateTime(GetParam("txtdate").Trim());
            strSelectedDate = String.Format("{0:MM/dd/yyyy}", dtselect);
            //strSelectedDate = GetParam("txtdate").Trim();
            string recType2 = GetParam("repeat").Trim();


            #region Start Recuring here

            //int frequency = Convert.ToInt32(countTYpe.Value.Trim());
            if (recType2 == "0")
            {

                if (isValidDayOff(agentId, strSelectedDate, ref errmess))
                {
                    errmess = "";
                    string slot_name = "Day-Off for:  " + strSelectedDate;

                    string record_id = inserDayoff(agentId, slot_name, strSelectedDate, "1");


                    if (record_id.Length > 1)
                    {
                        //txtaDate.Value = "";
                        //Response.Redirect("rcal.aspx?mess=Day off set successfully!");
                        //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                        result = true;
                    }
                }
                else
                {
                    result = false;
                }
            }
            else
            {
                //string recType = GetParam("schedule_days").Trim();
                string recType = schedule_days.Value.Trim();
                int frequencyCount = Convert.ToInt32(noofdays.Value.Trim());
                DateTime selDate = DateTime.Parse(strSelectedDate);

                int count = 0;

                if (recType == "Weekly")
                {
                    if (frequencyCount > 1)
                    {
                    }
                    else
                    {
                        errmess = "count is less than 1 !";
                        return false;
                    }

                    string record_id = "";
                  
                    for (int i = 0; i < frequencyCount; i++)
                    {

                        string selDate_next = selDate.ToShortDateString(); //common.Convert_USA_date(selDate);
                        //string selDate_next = String.Format("{0:MM/dd/yyyy}", selDate);

                      
                        // DateTime dt = Convert.ToDateTime(selDate_next);
                        //string DayName = String.Format("{0:dddd}", dt);

                        string slot_name = "Day-Off for:  " + selDate_next;

                        if (isValidDayOff(agentId, selDate_next, ref errmess))
                        {
                            errmess = "";
                            record_id = inserDayoff(agentId, slot_name, selDate_next, "1");
                        }
                        else
                        {
                            count++;
                            recurring_message = count.ToString();
                        }

                        //add one more week
                        selDate = selDate.AddDays(7);
                    }

                    if (record_id.Length > 1)
                    {
                        result = true;
                        // txtaDate.Value = "";
                        // Response.Redirect("rcal.aspx?mess=Day off set successfully!");
                        //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                    }
                    else
                    {
                        result = false;
                    }
                }
                else if (recType == "Monthly")
                {
                    if (frequencyCount > 1)
                    {
                    }
                    else
                    {
                        errmess = "count is less than 1 !";
                        return false;
                    }

                    string record_id = "";
                    for (int i = 0; i < frequencyCount; i++)
                    {



                        //string selDate_next = common.Convert_USA_date(selDate);
                        string selDate_next = selDate.ToShortDateString();
                        // DateTime dt = Convert.ToDateTime(selDate_next);
                        //string DayName = String.Format("{0:dddd}", dt);

                        string slot_name = "Day-Off for:  " + selDate_next;
                        if (isValidDayOff(agentId, selDate_next, ref errmess))
                        {
                            errmess = "";
                            record_id = inserDayoff(agentId, slot_name, selDate_next, "1");
                        }
                        else
                        {
                            count++;
                            recurring_message = count.ToString();
                        }
                        //add one more month
                        selDate = selDate.AddMonths(1);
                    }

                    if (record_id.Length > 1)
                    {
                        // txtaDate.Value = "";
                        //Response.Redirect("rcal.aspx?mess=Day off set successfully!");
                        //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                        result = true;
                    }
                }
                else if (recType == "Day")
                {
                    if (frequencyCount > 1)
                    {
                    }
                    else
                    {
                        errmess = "count is less than 1 !";
                        return false;
                    }
                    string record_id = "";
                    for (int i = 0; i < frequencyCount; i++)
                    {



                        //string selDate_next = common.Convert_USA_date(selDate);
                        string selDate_next = selDate.ToShortDateString();
                        //DateTime dt = Convert.ToDateTime(selDate_next);
                        // string DayName = String.Format("{0:dddd}", dt);

                        string slot_name = "Day-Off for:  " + selDate_next;
                        if (isValidDayOff(agentId, selDate_next, ref errmess))
                        {
                            errmess = "";
                            record_id = inserDayoff(agentId, slot_name, selDate_next, "1");
                        }
                        else
                        {
                            count++;
                            recurring_message = count.ToString();
                        }

                        //add one more day
                        selDate = selDate.AddDays(1);
                    }
                    if (record_id.Length > 1)
                    {
                        result = true;
                        // txtaDate.Value = "";
                        // Response.Redirect("rcal.aspx?mess=Day off set successfully!");
                        //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                    }

                }
                else
                {

                    string slot_name = "Day-Off for:  " + strSelectedDate;
                    if (isValidDayOff(agentId, strSelectedDate,ref errmess))
                    {
                        errmess = "";
                        string record_id = inserDayoff(agentId, slot_name, strSelectedDate, "1");
                        if (record_id.Length > 1)
                        {
                            result = true;
                            // txtaDate.Value = "";
                            //   Response.Redirect("rcal.aspx?mess=Day off set successfully!");
                            //Server.Transfer("rcal.aspx?mess=1&mcode=1");
                        }
                    }


                }



            }
            #endregion




            //result = true;
        }
        catch (Exception ex)
        {
            errmess = ex.Message;
            result = false;
        }
        return result;
    }


    private int GetNumberFromTime(string pStart)
    {
        int result = 0;


        if (pStart == "")
        {
            return 0;
        }

        switch (pStart)
        {
            #region Converting Time to Number
            case "6:00 a.m.":
                result = 35; break;

            case "6:30 a.m.":
                result = 34; break;

            case "7:00 a.m.":
                result = 33; break;

            case "7:30 a.m.":
                result = 32; break;

            case "8:00 a.m.":
                result = 31; break;


            case "8:30 a.m.":
                result = 30; break;


            case "9:00 a.m.":
                result = 29; break;


            case "9:30 a.m.":
                result = 28; break;


            case "10:00 a.m.":
                result = 27; break;


            case "10:30 a.m.":
                result = 26; break;


            case "11:00 a.m.":
                result = 25; break;


            case "11:30 a.m.":
                result = 24; break;


            case "12:00 p.m.":
                result = 23; break;


            case "12:30 p.m.":
                result = 22; break;


            case "1:00 p.m.":
                result = 21; break;


            case "1:30 p.m.":
                result = 20; break;


            case "2:00 p.m.":
                result = 19; break;

            case "2:30 p.m.":
                result = 18; break;


            case "3:00 p.m.":
                result = 17; break;


            case "3:30 p.m.":
                result = 16; break;


            case "4:00 p.m.":
                result = 15; break;


            case "4:30 p.m.":
                result = 14; break;


            case "5:00 p.m.":
                result = 13; break;


            case "5:30 p.m.":
                result = 12; break;


            case "6:00 p.m.":
                result = 11; break;


            case "6:30 p.m.":
                result = 10; break;


            case "7:00 p.m.":
                result = 9; break;


            case "7:30 p.m.":
                result = 8; break;


            case "8:00 p.m.":
                result = 7; break;


            case "8:30 p.m.":
                result = 6; break;


            case "9:00 p.m.":
                result = 5; break;


            case "9:30 p.m.":
                result = 4; break;


            case "10:00 p.m.":
                result = 3; break;


            case "10:30 p.m.":
                result = 2; break;


            case "11:00 p.m.":
                result = 1; break;


            default:
                result = 0;
                break;
            #endregion
        }

        return result;
    }

    private string inserNewReCord(string papp_id, string Rec_name, string day_name, string papp_date, string papp_from, string papp_end, string pAppStatus)
    {
        string result = "";
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }
            Unvailability__c u_obj = new Unvailability__c();

            u_obj.Name = Rec_name;
            u_obj.Day_name__c = day_name;
            u_obj.av_Date__cSpecified = true;


            //DateTime.ParseExact("02-27-2012", "MM-dd-yyyy", CultureInfo.GetCultureInfo("en-GB"));
            u_obj.av_Date__c = DateTime.Parse(papp_date);

            u_obj.Saved_by__c = papp_id;

            u_obj.av_start_Time__c = papp_from;

            // int nOfrom = Convert.ToInt16(ddlStart.SelectedValue);
            // u_obj.NoFrom__cSpecified = true;
            // u_obj.NoFrom__c = nOfrom;

            //  int noTo = Convert.ToInt16(ddlEnd.SelectedValue);
            //  u_obj.NoTo__cSpecified = true;
            //  u_obj.NoTo__c = noTo;


            u_obj.av_End_Time__c = papp_end;

            u_obj.av_Status__cSpecified = true;
            u_obj.av_Status__c = Convert.ToInt16(pAppStatus);



            sObject[] to = new sObject[1];
            to[0] = u_obj;

            SaveResult[] saveResults = login.bi.create(to);

            // Handle the results  

            for (int i = 0; i < saveResults.Length; i++)
            {
                // Determine whether create() succeeded or had errors  

                if (saveResults[i].success)
                {
                    // No errors, so retrieve the Id created for this record  
                    //Session.Add("ssnCAcId", saveResults[i].id);
                    //Server.Transfer("editcust.aspx?cstid=" + saveResults[i].id);
                    result = saveResults[i].id;

                }
                else
                {

                    // Handle the errors  

                    foreach (Error error in saveResults[i].errors)
                    {
                        //logerr.InnerHtml = "<br/> Error code is: {0}" + error.statusCode.ToString() + "Error message: {0}" + error.message;
                    }
                }
            }



        }

        catch (Exception ex)
        {
            result = "";
            // logerr.InnerHtml = "<br/> Error message: {0}" + ex.Message;
        }
        finally
        {
            if (result != "")
            {
                //   formClear();
                //call Ajax Here
            }
        }
        return result;
    }
    private string inserDayoff(string pSF_Contact_id, string p_name, string p_app_date, string pStatus)
    {
        string result = "";
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }
            Unvailability__c u_obj = new Unvailability__c();

            u_obj.Name = p_name;

            DateTime dt = Convert.ToDateTime(p_app_date);
            string DayName = String.Format("{0:dddd}", dt);
            u_obj.Day_name__c = DayName;


            u_obj.av_Date__cSpecified = true;


            //DateTime.ParseExact("02-27-2012", "MM-dd-yyyy", CultureInfo.GetCultureInfo("en-GB"));
            u_obj.av_Date__c = DateTime.Parse(p_app_date);

            u_obj.Saved_by__c = pSF_Contact_id;



            u_obj.av_Status__cSpecified = true;
            u_obj.av_Status__c = Convert.ToInt16(pStatus);



            sObject[] to = new sObject[1];
            to[0] = u_obj;

            SaveResult[] saveResults = login.bi.create(to);

            // Handle the results  

            for (int i = 0; i < saveResults.Length; i++)
            {
                // Determine whether create() succeeded or had errors  

                if (saveResults[i].success)
                {
                    // No errors, so retrieve the Id created for this record  
                    //Session.Add("ssnCAcId", saveResults[i].id);
                    //Server.Transfer("editcust.aspx?cstid=" + saveResults[i].id);
                    result = saveResults[i].id;

                }
                else
                {

                    // Handle the errors  

                    foreach (Error error in saveResults[i].errors)
                    {
                        //dyMessDefault.InnerHtml = "<br/> Error code is: {0}" + error.statusCode.ToString() + "Error message: {0}" + error.message;
                    }
                }
            }



        }

        catch (Exception ex)
        {
            result = "";
            //dyMessDefault.InnerHtml = "<br/> Error message: {0}" + ex.Message;
        }
        finally
        {
            if (result != "")
            {

                //call Ajax Here
            }
        }
        return result;
    }
    private bool isValidException(string strContactId, int intStart, int intEnd, string strDate,ref string errMsg)
    {
        bool result = false;
        string errMessage = "";

        //if trying to fix Exception for specific timing on a selected date
        DateTime dt = DateTime.Parse(strDate);
        //string slotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";

        // change on 27 Nov 2013
        string slotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<" + intStart + ") or (NoFrom__c >" + intEnd + " and NoTo__c<=" + intEnd + ") )";

        // change on 28 Oct 2013
        //string slotSoql = " ( (NoFrom__c >" + intStart + " and NoTo__c<" + intStart + ") or (NoFrom__c >" + intEnd + " and NoTo__c<" + intEnd + ") )";


        int howManyAppointments = countAppts(strContactId, dt, intStart, intEnd, ref errMessage, 2); //countAppts(strContactId, dt, slotSoql, ref errMessage, 2);

        if (howManyAppointments > 0)
        {
            //Time Off not allowed, appointments exists for this date!
            errMsg = "Time Off not allowed, appointment(s) already exists!";
            result = false;
            return result;
        }
        else
        {
            errMsg = "";
            //you can book day-off here
            result = true;
        }

        int itHasAlreadyException = 0;

        //string expSlotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";
         
        // changing on 30 Oct 2013
        //string expSlotSoql="( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") or (NoFrom__c=0 and NoTo__c=0) )";


        // change on 27 Nov 2013
        string expSlotSoql = "( (NoFrom__c >=" + intStart + " and NoTo__c<" + intStart + ") or (NoFrom__c >" + intEnd + " and NoTo__c<=" + intEnd + ") or (NoFrom__c=0 and NoTo__c=0) )";
        // change on 28 Oct 2013

        //string expSlotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<" + intEnd + ") )";


        itHasAlreadyException = countException(strContactId, dt, expSlotSoql, ref errMessage, 2);

        if (itHasAlreadyException > 0)
        {
            //Time Off not allowed, appointments exists for this date!
            errMsg = "Not allowed, Time off already exists !";
            result = false;
            return result;
        }
        else
        {
            errMsg = "";
            //you can book day-off here
            result = true;
        }

        return result;
    }
    private bool isValidException_backup(string strContactId, int intStart, int intEnd, string strDate)
    {
        bool result = false;
        string errMessage = "";

        //if trying to fix Exception for specific timing on a selected date
        DateTime dt = DateTime.Parse(strDate);
        string slotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";

        // changing on 30 Oct 2013

        //string slotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") or (NoFrom__c=" + intStart + " and NoTo__c=" + intEnd + ") )";

        int howManyAppointments = countAppts(strContactId, dt, slotSoql, ref errMessage, 2);

        if (howManyAppointments > 0)
        {
            //exception not allowed, appointments here in between the slot timing!
            result = false;
        }
        else
        {
            //you can book execption here
            result = true;
        }

        return result;
    }

    private bool isValidDayOff(string strContactId, string strDate, ref string ErrMsg)
    {
        bool result = false;
        string errMessage = "";

        //if trying to fix DayOff for a selected date
        DateTime dt = DateTime.Parse(strDate);

        int howManyAppointments = countAppts(strContactId, dt, "", ref errMessage, 1);



        if (howManyAppointments > 0)
        {
            //Time Off not allowed, appointments exists for this date!
            ErrMsg = "Time Off not allowed, appointment(s) already exists!";
            result = false;
            return result;
        }
        else
        {
            ErrMsg = "";
            //you can book day-off here
            result = true;
        }

        int itHasAlreadyException = 0;


        itHasAlreadyException = countException(strContactId, dt, "", ref errMessage, 2);

        if (itHasAlreadyException > 0)
        {
            //Time Off not allowed, appointments exists for this date!
            ErrMsg = "Not allowed, Time off already exists !";
            result = false;
            return result;
        }
        else
        {
            ErrMsg = "";
            //you can book day-off here
            result = true;
        }


        return result;
    }
    private bool isValidDayOff_backUp(string strContactId, string strDate)
    {
        bool result = false;
        string errMessage = "";

        //if trying to fix DayOff for a selected date
        DateTime dt = DateTime.Parse(strDate);

        int howManyAppointments = countAppts(strContactId, dt, "", ref errMessage, 1);

        int itHasAlreadyException = 0;

        itHasAlreadyException = countException(strContactId, dt, "", ref errMessage, 2);


        if (howManyAppointments > 0)
        {
            //exception not allowed, appointments here for this date!
            result = false;
        }
        else
        {
            //you can book day-off here
            result = true;
        }

        return result;
    }


    public int countAppts(string pAgentId, DateTime pdt, int startTime,int endTime, ref string mess, int isDayOrExp)
    {
        int result = 0;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }


            //string dayName = String.Format("{0:dddd}", pdt);

            string apptDate = common.Convert_USA_date(pdt);
            apptDate = common.SF_date(apptDate);
            //string apptDate = pdt.ToString();
            //SELECT id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and  Appointment_Date__c=2013-09-20   and Contact__c='003i00000073R2EAAU'  and  (NoTo__c >16 and NoFrom__c > 19) 

            string sql_appts_byid = "";
            if (isDayOrExp == 1)// 1 is for Day- off, so do not pass the timing as filter!
            {
                sql_appts_byid = " SELECT Id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
                          " Appointment_Date__c=" + apptDate + " and Contact__c='" + pAgentId + "'";
            }
            else
            {
                //2 for Exception!
                sql_appts_byid = " SELECT Id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
                          " Appointment_Date__c=" + apptDate + "  and Contact__c='" + pAgentId + "'";//  and " + pSlotBitween;
            }


            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {

                    int counter = 0;
                    for (int i = 0; i < qr.records.Length; i++)
                    {

                        Appointment__c con = (Appointment__c)qr.records[i];

                        if (con.Id != null)
                        {
                            if (isDayOrExp == 1)
                            {
                                counter++;
                            }
                            else
                            {
                                int fromSlot = 0, toSlot = 0;
                                if (con.NoFrom__c != null)
                                {
                                    con.NoFrom__cSpecified = true;
                                    fromSlot = Convert.ToInt32(con.NoFrom__c);
                                }
                                if (con.NoTo__c != null)
                                {
                                    con.NoTo__cSpecified = true;
                                    toSlot = Convert.ToInt32(con.NoTo__c);
                                }

                                if (fromSlot > 0 && toSlot > 0)
                                {
                                    //make comparision here :

                                    //(NoFrom__c> 35 and 35< NoTo__c) or(NoFrom__c> 1 and 1< NoTo__c)
                                    //" ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";
                                    //( (Appt_NoFrom__c >=" + pStart + " and Appt_NoTo__c<" + pStart + ") or (Appt_NoFrom__c >" + pEnd + " and Appt_NoTo__c<=" + pEnd + ") )"

                                    if ((fromSlot >= startTime && toSlot < startTime)) 
                                    {
                                        counter++;
                                    }
                                    if ((fromSlot > endTime && toSlot <= endTime))
                                    {
                                        counter++;
                                    }
                                    if (fromSlot>endTime && fromSlot<startTime)
                                    {
                                        counter++;
                                    }

                                }


                            }

                        }

                    }
                    if (qr.done)
                    {
                        result = counter;
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = 0;
            }
        }
        catch (Exception ex)
        {
            mess = ex.Message;
            result = 0;
        }
        finally
        {
        }

        return result;
    }


    public int countAppts(string pAgentId, DateTime pdt, string pSlotBitween, ref string mess, int isDayOrExp)
    {
        int result = 0;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }


            //string dayName = String.Format("{0:dddd}", pdt);

            string apptDate = common.Convert_USA_date(pdt);
            apptDate = common.SF_date(apptDate);
            //string apptDate = pdt.ToString();
            //SELECT id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and  Appointment_Date__c=2013-09-20   and Contact__c='003i00000073R2EAAU'  and  (NoTo__c >16 and NoFrom__c > 19) 

            string sql_appts_byid = "";
            if (isDayOrExp == 1)// 1 is for Day- off, so do not pass the timing as filter!
            {
                sql_appts_byid = " SELECT Id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
                          " Appointment_Date__c=" + apptDate + " and Contact__c='" + pAgentId + "'";
            }
            else
            {
                //2 for Exception!
                sql_appts_byid = " SELECT Id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and " +
                          " Appointment_Date__c=" + apptDate + "  and Contact__c='" + pAgentId + "'  and " + pSlotBitween;
            }


            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {

                    int counter = 0;
                    for (int i = 0; i < qr.records.Length; i++)
                    {

                        Appointment__c con = (Appointment__c)qr.records[i];

                        if (con.Id != null)
                        {
                            counter++;
                        }

                    }
                    if (qr.done)
                    {
                        result = counter;
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = 0;
            }
        }
        catch (Exception ex)
        {
            mess = ex.Message;
            result = 0;
        }
        finally
        {
        }

        return result;
    }

    public int countException(string pAgentId, DateTime pdt, string pSlotBitween, ref string mess, int isDayOrExp)
    {
        int result = 0;
        try
        {
            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }


            //string dayName = String.Format("{0:dddd}", pdt);

            string apptDate = common.Convert_USA_date(pdt);
            apptDate = common.SF_date(apptDate);
            //string apptDate = pdt.ToString();
            //SELECT id,NoTo__c,NoFrom__c FROM Appointment__c where Invite_Status__c in('Accepted','Invited') and  Appointment_Date__c=2013-09-20   and Contact__c='003i00000073R2EAAU'  and  (NoTo__c >16 and NoFrom__c > 19) 

            string sql_appts_byid = "";
            if (isDayOrExp == 1)// 1 is for Day- off, so do not pass the timing as filter!
            {
                sql_appts_byid = " SELECT  NoFrom__c, NoTo__c, Id, av_Status__c FROM Unvailability__c where av_Status__c in (1,2) and " +
                          " av_Date__c=" + apptDate + " and Saved_by__c='" + pAgentId + "'";
            }
            else
            {
                //2 for Exception!
                //string slotSoql = " ( (NoFrom__c >=" + intStart + " and NoTo__c<=" + intStart + ") or (NoFrom__c >=" + intEnd + " and NoTo__c<=" + intEnd + ") )";
                //SELECT Saved_by__c, av_Date__c, Day_name__c, av_start_Time__c,  NoFrom__c, NoTo__c, Id, av_Status__c, av_End_Time__c FROM Unvailability__c
                // where av_Status__c in (2,3) and av_Date__c= and Saved_by__c='' and
 
                // Change on 30_Oct 2013
                if (pSlotBitween != "")
                {
                    sql_appts_byid = " SELECT  NoFrom__c, NoTo__c, Id, av_Status__c FROM Unvailability__c where av_Status__c in (1,2) and " +
                               " av_Date__c=" + apptDate + " and Saved_by__c='" + pAgentId + "' and " + pSlotBitween + "";
                }
                else
                {
                    sql_appts_byid = " SELECT  NoFrom__c, NoTo__c, Id, av_Status__c FROM Unvailability__c where av_Status__c in (1,2) and " +
                               " av_Date__c=" + apptDate + " and Saved_by__c='" + pAgentId + "'";
                }
            }


            QueryResult qr = null;


            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            qr = login.bi.query(sql_appts_byid);

            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {

                    int counter = 0;
                    for (int i = 0; i < qr.records.Length; i++)
                    {

                        Unvailability__c con = (Unvailability__c)qr.records[i];

                        if (con.Id != null)
                        {

                            int startFromNumber = 0, entToNumber = 0;
                            try
                            {
                                if (con.NoFrom__c != null)
                                {
                                    con.NoFrom__cSpecified = true;
                                    startFromNumber = Convert.ToInt32(con.NoFrom__c);
                                }
                                if (con.NoTo__c != null)
                                {
                                    con.NoTo__cSpecified = true;
                                    entToNumber = Convert.ToInt32(con.NoTo__c);
                                }
                            }
                            catch (Exception ex)
                            {
                                startFromNumber = 0;
                                entToNumber = 0;
                            }


                            counter++;

                            //if (isDayOrExp == 1)
                            //{ counter++; }
                            //else
                            //{
                            //    if (startFromNumber == 0 && entToNumber == 0)
                            //    {
                            //        counter++;
                            //    }
                            //}

                        }

                    }
                    if (qr.done)
                    {
                        result = counter;
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }


            }
            else
            {
                result = 0;
            }
        }
        catch (Exception ex)
        {
            mess = ex.Message;
            result = 0;
        }
        finally
        {
        }

        return result;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        string message = "";
        errmessDiv.InnerHtml = "";
        string recurring_message = "";
        try
        {
            if (allday.Value == "off")
            {
                if (fixException(ref message))
                {
                    //message = "Your unavailability submitted successfully!";

                    //Response.Redirect("a1.aspx?p1=" + message);
                    Response.Redirect("redirect.aspx");
                }
                else
                {
                    errmessDiv.InnerHtml = message;
                }
            }
            else if (allday.Value == "on")
            {
                if (fixDayOff(ref message, ref recurring_message))
                {
                    //message = "Day-off saved successfully!";
                    //Response.Redirect("a1.aspx?p1=" + message);

                    Response.Redirect("redirect.aspx?p1=" + recurring_message);
                    //Server.Transfer("mycal.aspx");
                }
                else
                {
                    errmessDiv.InnerHtml = message;
                }
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}