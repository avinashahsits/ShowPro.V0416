﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebReference;
public partial class mb_Default_Availability : System.Web.UI.Page
{
    public class Agent_DefaultAvailability
    {
        public string Day { get; set; }
        public string mondayID { get; set; }

        public string mondayStart { get; set; }

        public string mondayEnd { get; set; }

        public string mondayStatus { get; set; }

        public string tuesdayID { get; set; }

        public string tuesdayStart { get; set; }

        public string tuesdayEnd { get; set; }

        public string tuesdayStatus { get; set; }

        public string wednesdayID { get; set; }

        public string wednesdayStart { get; set; }

        public string wednesdayEnd { get; set; }

        public string wednesdayStatus { get; set; }

        public string thursdayID { get; set; }

        public string thursdayStart { get; set; }

        public string thursdayEnd { get; set; }

        public string thursdayStatus { get; set; }

        public string fridayID { get; set; }

        public string fridayStart { get; set; }

        public string fridayEnd { get; set; }

        public string fridayStatus { get; set; }

        public string saturdayID { get; set; }

        public string saturdayStart { get; set; }

        public string saturdayEnd { get; set; }

        public string saturdayStatus { get; set; }

        public string sundayID { get; set; }

        public string sundayStart { get; set; }

        public string sundayEnd { get; set; }

        public string sundayStatus { get; set; }
    }

    public class Agent_DefaultAvailability2
    {
        public string Id { get; set; }
        public string starttime { get; set; }

        public string endtime { get; set; }

        public string Day { get; set; }

    }

    public string erromess = "", sucess = "", AgenId = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            AgenId = Convert.ToString(Session["ssnUserId"]); ;// "003i0000007tDqH";// Convert.ToString(Session["ssnUserId"]);//003i0000007tDqH 003i0000009wnY6//003i000000ceaQs 5 days // 003i000000bWkfc two days
            if (!IsPostBack)
            {

                if (AgenId != "")
                {
                    #region Get Recent Salesforce value
                    Dictionary<string, Agent_DefaultAvailability2> olddictionary = new Dictionary<string, Agent_DefaultAvailability2>();
                    Agent_DefaultAvailability2 forfillolddate = new Agent_DefaultAvailability2();
                    if (Fill_Availibility_Data(AgenId, ref olddictionary))
                    {
                        Session["olddictionary"] = olddictionary;
                        //btnupedat.Style.Add("background-color","none");
                    }
                    #endregion

                }
            }
        }
        else
        {
            Response.Redirect("Default.aspx");
        }

    }


    public bool Fill_Availibility_Data(string agent, ref Dictionary<string, Agent_DefaultAvailability2> olddictionary)
    {
        bool result = false;
        try
        {
            Dictionary<string, Agent_DefaultAvailability> getAvailablityData = new Dictionary<string, Agent_DefaultAvailability>();
            Agent_DefaultAvailability2 forolddate = new Agent_DefaultAvailability2();
            getAvailablityData = Get_DefaultAvailability(agent);

            if (getAvailablityData.Count == 0)
            {
                forupdate_default_availability.Style.Add("display","none");
            }
            foreach (KeyValuePair<string, Agent_DefaultAvailability> Pair in getAvailablityData)
            {

                string Day = Pair.Value.Day;
                #region For Monday
                if (Day == "Monday")
                {
                   
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.mondayID; ;
                    forolddate.Id = Pair.Value.mondayID;
                    forolddate.starttime = Pair.Value.mondayStart;
                    forolddate.endtime = Pair.Value.mondayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                    #endregion

                    mondayid.Value = Pair.Value.mondayID;
                    ddlStartM.SelectedValue = Pair.Value.mondayStart;
                    ddlEndM.SelectedValue = Pair.Value.mondayEnd;
                }
                #endregion

                #region For Tuesday
                if (Day == "Tuesday")
                {
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.tuesdayID; ;
                    forolddate.Id = Pair.Value.tuesdayID;
                    forolddate.starttime = Pair.Value.tuesdayStart;
                    forolddate.endtime = Pair.Value.tuesdayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                    #endregion
                    tuesdayid.Value = Pair.Value.tuesdayID;
                    ddlStartTu.SelectedValue = Pair.Value.tuesdayStart;
                    ddlEndTue.SelectedValue = Pair.Value.tuesdayEnd;
                }
                #endregion

                #region For Wednesday
                if (Day == "Wednesday")
                {
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.wednesdayID; ;
                    forolddate.Id = Pair.Value.wednesdayID;
                    forolddate.starttime = Pair.Value.wednesdayStart;
                    forolddate.endtime = Pair.Value.wednesdayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                    #endregion
                    wednesdayid.Value = Pair.Value.wednesdayID;
                    ddlStartWed.SelectedValue = Pair.Value.wednesdayStart;
                    ddlEndWed.SelectedValue = Pair.Value.wednesdayEnd;
                }
                #endregion

                #region For Thursday
                if (Day == "Thursday")
                {
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.thursdayID; ;
                    forolddate.Id = Pair.Value.thursdayID;
                    forolddate.starttime = Pair.Value.thursdayStart;
                    forolddate.endtime = Pair.Value.thursdayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                    #endregion
                    thursdayid.Value = Pair.Value.thursdayID;
                    ddlStartThu.SelectedValue = Pair.Value.thursdayStart;
                    ddlEndThu.SelectedValue = Pair.Value.thursdayEnd;
                }
                #endregion

                #region For Friday
                if (Day == "Friday")
                {
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.fridayID; ;
                    forolddate.Id = Pair.Value.fridayID;
                    forolddate.starttime = Pair.Value.fridayStart;
                    forolddate.endtime = Pair.Value.fridayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                   
                    #endregion
                    fridayid.Value = Pair.Value.fridayID;
                    ddlStartFir.SelectedValue = Pair.Value.fridayStart;
                    ddlEndFri.SelectedValue = Pair.Value.fridayEnd;
                }
                #endregion

                #region For Saturday
                if (Day == "Saturday")
                {
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.saturdayID; ;
                    forolddate.Id = Pair.Value.saturdayID;
                    forolddate.starttime = Pair.Value.saturdayStart;
                    forolddate.endtime = Pair.Value.saturdayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                    #endregion
                    saturdayid.Value = Pair.Value.saturdayID;
                    ddlStartSat.SelectedValue = Pair.Value.saturdayStart;
                    ddlEndSat.SelectedValue = Pair.Value.saturdayEnd;
                }
                #endregion

                #region For Sunday
                if (Day == "Sunday")
                {
                    #region for bind old data in dictionary
                    forolddate = new Agent_DefaultAvailability2();
                    string id = Pair.Value.sundayID; ;
                    forolddate.Id = Pair.Value.sundayID;
                    forolddate.starttime = Pair.Value.sundayStart;
                    forolddate.endtime = Pair.Value.sundayEnd;
                    forolddate.Day = Day;
                    olddictionary.Add(id, forolddate);
                    #endregion
                    sundayid.Value = Pair.Value.sundayID;
                    ddlStartSun.SelectedValue = Pair.Value.sundayStart;
                    ddlEndSun.SelectedValue = Pair.Value.sundayEnd;
                }
                #endregion

                

                result = true;

            }
            #region For Check Availability To Every Day
            if (mondayid.Value == "" || tuesdayid.Value == "" || wednesdayid.Value == "" || thursdayid.Value == "" || fridayid.Value == "" || saturdayid.Value == "" || sundayid.Value == "")
            {
                New_additional_availablity.Style.Add("display", "block");
                //New_additional_availablity.Style.Add("width","100%");
                if (mondayid.Value == "")
                {
                    foraddnew_monday.Style.Add("display", "block");
                  
                    forupdate_Monday_Panel.Style.Add("display", "none");

                }
                else
                {
                    foraddnew_monday.Style.Add("display", "none");
                    forupdate_Monday_Panel.Style.Add("display", "block");
                }
                if (tuesdayid.Value == "")
                {
                    foraddnew_tuesday.Style.Add("display", "block");
                    forupdate_tuesday_panel.Style.Add("display", "none");
                }
                else
                {
                    foraddnew_tuesday.Style.Add("display", "none");
                    forupdate_tuesday_panel.Style.Add("display", "block");
                }
                if (wednesdayid.Value == "")
                {
                    foraddnew_wednesday.Style.Add("display", "block");
                    forupdate_wednesday_panel.Style.Add("display", "none");
                }
                else
                {
                    foraddnew_wednesday.Style.Add("display", "none");
                    forupdate_wednesday_panel.Style.Add("display", "block");
                }
                if (thursdayid.Value == "")
                {
                    foraddnew_thursday.Style.Add("display", "block");
                    forupdate_thursday_panel.Style.Add("display", "none");
                }
                else
                {
                    foraddnew_thursday.Style.Add("display", "none");
                    forupdate_thursday_panel.Style.Add("display", "block");
                }
                if (fridayid.Value == "")
                {
                    foraddnew_friday.Style.Add("display", "block");
                    forupdate_friday_panel.Style.Add("display", "none");
                }
                else
                {
                    foraddnew_friday.Style.Add("display", "none");
                    forupdate_friday_panel.Style.Add("display", "block");
                }
                if (saturdayid.Value == "")
                {
                    foraddnew_saturday.Style.Add("display", "block");
                    forupdate_saturday_panel.Style.Add("display", "none");
                }
                else
                {
                    foraddnew_saturday.Style.Add("display", "none");
                    forupdate_saturday_panel.Style.Add("display", "block");
                }
                if (sundayid.Value == "")
                {
                    foraddnew_sunday.Style.Add("display", "block");
                    forupdate_sunday_panel.Style.Add("display", "none");
                }
                else
                {
                    foraddnew_sunday.Style.Add("display", "none");
                    forupdate_sunday_panel.Style.Add("display", "block");
                }
            }
            else
            {
                New_additional_availablity.Style.Add("display", "none");
            }
            #endregion
        }
        catch (Exception)
        {

            result = false;
        }

        return result;
    }


    protected void btnupedat_Click(object sender, EventArgs e)
    {
        string Salesforce_errormess="";
        //string AgenId = "003i0000007tDqH";

        bool HaveOK = false;

        #region For Getold Data in Dictionary
        Dictionary<string, Agent_DefaultAvailability2> olddictionary = new Dictionary<string, Agent_DefaultAvailability2>();
        if (Session["olddictionary"] != null)
        {
            try
            {
                olddictionary = (Dictionary<string, Agent_DefaultAvailability2>)Session["olddictionary"];
            }
            catch (Exception ex)
            {
            }
        }

        #endregion

        #region Shorting Changing Availability Time For Each Day With Dictionary
        Dictionary<string, Agent_DefaultAvailability2> changedictionary = fill_current_Data();//new Dictionary<string, Agent_DefaultAvailability2>();

        Agent_DefaultAvailability2 finalupdaterecord = new Agent_DefaultAvailability2();
        Dictionary<string, Agent_DefaultAvailability2> Finaldictionary = new Dictionary<string, Agent_DefaultAvailability2>();

        if (changedictionary.Count == 0)
        {
            HaveOK = false;
            errmessDiv.InnerHtml = "Invalid Time Range";

        }
        else
        {

            foreach (KeyValuePair<string, Agent_DefaultAvailability2> Origkvp in olddictionary)
            {
                bool hasDictionaryChanged = false;
                string keyId = "";
                foreach (KeyValuePair<string, Agent_DefaultAvailability2> kvp in changedictionary)
                {
                    if ((Origkvp.Key == kvp.Key) && (Origkvp.Value.starttime != kvp.Value.starttime || Origkvp.Value.endtime != kvp.Value.endtime))
                    {
                        hasDictionaryChanged = true;
                        finalupdaterecord = new Agent_DefaultAvailability2();
                        keyId = kvp.Value.Id; ;
                        finalupdaterecord.Id = kvp.Value.Id;
                        finalupdaterecord.starttime = kvp.Value.starttime;
                        finalupdaterecord.endtime = kvp.Value.endtime;
                        finalupdaterecord.Day = kvp.Value.Day;
                        //break;
                    }
                }
                if (hasDictionaryChanged)
                {
                    Finaldictionary.Add(keyId, finalupdaterecord);
                    //break;
                }
            }

            if (Finaldictionary.Count > 0)
            {
                HaveOK = true;
            }
            else
            {
                HaveOK = false;
                //errmessDiv.InnerHtml = "Select Default Availability for update!!";
                //return HaveOK;
            }
        }
        #endregion

     

        #region Update Default Availability For Day Wise
        if (Finaldictionary.Count > 0)
        {
            errmessDiv.InnerHtml = "";
            foreach (KeyValuePair<string, Agent_DefaultAvailability2> changedt in Finaldictionary)
            {
                int start = 0, end = 0;
                string Id = changedt.Value.Id;
                string starttime = changedt.Value.starttime;
                string endtime = changedt.Value.endtime;
                string day = changedt.Value.Day;

                if (day == "Monday")
                {
                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Monday" + ",";
                    }

                }
                if (day == "Tuesday")
                {

                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Tuesday" + ",";
                    }

                }
                if (day == "Wednesday")
                {

                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Wednesday" + ",";
                    }

                }
                if (day == "Thursday")
                {

                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Thursday" + ",";
                    }

                }
                if (day == "Friday")
                {

                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Friday" + ",";
                    }

                }
                if (day == "Saturday")
                {

                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Saturday" + ",";
                    }

                }
                if (day == "Sunday")
                {

                    if (update_DefaultAbility(Id, starttime, endtime, ref Salesforce_errormess))
                    {
                        sucess += "Sunday" + ",";
                    }

                }

            }

        #endregion

        #region For Display Message
           
            Response.Redirect("Default_availa_rdirect.aspx?p1=" + sucess.TrimEnd(',') + "&p2=" + erromess.TrimEnd(',') + "");

            #endregion

        #region Referesh Data From Salesforce
            //string AgenId1 = Convert.ToString(Session["ssnUserId"]);
            if (AgenId != "")
            {
                olddictionary = new Dictionary<string, Agent_DefaultAvailability2>();
                Agent_DefaultAvailability2 forfillolddate = new Agent_DefaultAvailability2();
                if (Fill_Availibility_Data(AgenId, ref olddictionary))
                {
                    Session["olddictionary"] = olddictionary;
                }
            }
            #endregion

        }
       

    }


    
    public Dictionary<string, Agent_DefaultAvailability2> fill_current_Data()
    {
        Dictionary<string, Agent_DefaultAvailability2> Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
        Agent_DefaultAvailability2 change_object = new Agent_DefaultAvailability2();
        try
        {
            int starttime = 0, endtime = 0;
            #region Monday
            if (mondayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartM.SelectedValue);
                endtime = GetNumberFromTime(ddlEndM.SelectedValue);
                if (starttime > endtime || ddlStartM.SelectedValue == "--None--" && ddlEndM.SelectedValue == "--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = mondayid.Value;
                    change_object.Id = mondayid.Value;
                    change_object.starttime = ddlStartM.SelectedValue;
                    change_object.endtime = ddlEndM.SelectedValue;
                    change_object.Day = "Monday";
                    if ((ddlStartM.SelectedValue == "--None--" && ddlEndM.SelectedValue != "--None--") || (ddlStartM.SelectedValue != "--None--" && ddlEndM.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                    
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion

            #region Tuesday
            if (tuesdayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartTu.SelectedValue);
                endtime = GetNumberFromTime(ddlEndTue.SelectedValue);
                if (starttime > endtime || ddlStartTu.SelectedValue == "--None--" && ddlEndTue.SelectedValue == "--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = tuesdayid.Value;
                    change_object.Id = tuesdayid.Value;
                    change_object.starttime = ddlStartTu.SelectedValue;
                    change_object.endtime = ddlEndTue.SelectedValue;
                    change_object.Day = "Tuesday";
                    if ((ddlStartTu.SelectedValue == "--None--" && ddlEndTue.SelectedValue != "--None--") || (ddlStartTu.SelectedValue != "--None--" && ddlEndTue.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion

            #region Wednesday
            if (wednesdayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartWed.SelectedValue);
                endtime = GetNumberFromTime(ddlEndWed.SelectedValue);
                if (starttime > endtime || ddlStartWed.SelectedValue == "--None--" && ddlEndWed.SelectedValue == "--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = wednesdayid.Value;
                    change_object.Id = wednesdayid.Value;
                    change_object.starttime = ddlStartWed.SelectedValue;
                    change_object.endtime = ddlEndWed.SelectedValue;
                    change_object.Day = "Wednesday";
                    if ((ddlStartWed.SelectedValue == "--None--" && ddlEndWed.SelectedValue != "--None--") || (ddlStartWed.SelectedValue != "--None--" && ddlEndWed.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion

            #region Thursday
            if (thursdayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartThu.SelectedValue);
                endtime = GetNumberFromTime(ddlEndThu.SelectedValue);
                if (starttime > endtime || ddlStartThu.SelectedValue == "--None--" && ddlEndThu.SelectedValue == "--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = thursdayid.Value;
                    change_object.Id = thursdayid.Value;
                    change_object.starttime = ddlStartThu.SelectedValue;
                    change_object.endtime = ddlEndThu.SelectedValue;
                    change_object.Day = "Thursday";
                    if ((ddlStartThu.SelectedValue == "--None--" && ddlEndThu.SelectedValue != "--None--") || (ddlStartThu.SelectedValue != "--None--" && ddlEndThu.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion

            #region Friday
            if (fridayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartFir.SelectedValue);
                endtime = GetNumberFromTime(ddlEndFri.SelectedValue);
                if (starttime > endtime || ddlStartFir.SelectedValue == "--None--" && ddlEndFri.SelectedValue == "--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = fridayid.Value;
                    change_object.Id = fridayid.Value;
                    change_object.starttime = ddlStartFir.SelectedValue;
                    change_object.endtime = ddlEndFri.SelectedValue;
                    change_object.Day = "Friday";
                    if ((ddlStartFir.SelectedValue == "--None--" && ddlEndFri.SelectedValue != "--None--") || (ddlStartFir.SelectedValue != "--None--" && ddlEndFri.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion

            #region Saturday
            if (saturdayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartSat.SelectedValue);
                endtime = GetNumberFromTime(ddlEndSat.SelectedValue);
                if (starttime > endtime || ddlStartSat.SelectedValue == "--None--" && ddlEndSat.SelectedValue=="--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = saturdayid.Value;
                    change_object.Id = saturdayid.Value;
                    change_object.starttime = ddlStartSat.SelectedValue;
                    change_object.endtime = ddlEndSat.SelectedValue;
                    change_object.Day = "Saturday";
                    if ((ddlStartSat.SelectedValue == "--None--" && ddlEndSat.SelectedValue != "--None--") || (ddlStartSat.SelectedValue != "--None--" && ddlEndSat.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion

            #region Sunday
            if (sundayid.Value != "")
            {
                starttime = GetNumberFromTime(ddlStartSun.SelectedValue);
                endtime = GetNumberFromTime(ddlEndSun.SelectedValue);
                if (starttime > endtime || ddlStartSun.SelectedValue == "--None--" && ddlEndSun.SelectedValue == "--None--")
                {
                    change_object = new Agent_DefaultAvailability2();
                    string id = sundayid.Value;
                    change_object.Id = sundayid.Value;
                    change_object.starttime = ddlStartSun.SelectedValue;
                    change_object.endtime = ddlEndSun.SelectedValue;
                    change_object.Day = "Sunday";
                    if ((ddlStartSun.SelectedValue == "--None--" && ddlEndSun.SelectedValue != "--None--") || (ddlStartSun.SelectedValue != "--None--" && ddlEndSun.SelectedValue == "--None--"))
                    {
                        Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                        return Change_Data;
                    }
                    else
                    {
                        Change_Data.Add(id, change_object);
                    }
                }
                else
                {
                    Change_Data = new Dictionary<string, Agent_DefaultAvailability2>();
                    return Change_Data;
                }
            }

            #endregion
        }
        catch (Exception)
        {

            Change_Data = null;
        }

        return Change_Data;
    }

    public static bool FindDifference(Agent_DefaultAvailability originalObject, Agent_DefaultAvailability changedObject)
    {
        foreach (PropertyInfo property in originalObject.GetType().GetProperties())
        {
           
            object originalValue = property.GetValue(originalObject,null);
            object newValue = property.GetValue(changedObject, null);

            if (!Equals(originalValue, newValue))
            {
                return true;
                
            }
        }
        return false;
    }

    public static Dictionary<string, Agent_DefaultAvailability> Get_DefaultAvailability(string AgentId)
    {
        Dictionary<string, Agent_DefaultAvailability> result = new Dictionary<string, Agent_DefaultAvailability>();

        Agent_DefaultAvailability available = new Agent_DefaultAvailability();

        #region SalesForce Login Check
        if (login.bi != null)
        {
            if (login.lr.sessionId != null)
            {
                string asd = login.lr.sessionId;
            }
            else
            {
                login.loginnow();
            }
        }
        else
        {
            login.loginnow();
        }

        #endregion
        QueryResult qr = null;

        //We are going to increase our return batch size to 250 items
        //Setting is a recommendation only, different batch sizes may
        //be returned depending on data, to keep performance optimized.
        //select first_name__c, last_name__c,dob__c from apitest__c where dob__c='4/13/2012'


        login.bi.QueryOptionsValue = new QueryOptions();
        login.bi.QueryOptionsValue.batchSize = 250;
        login.bi.QueryOptionsValue.batchSizeSpecified = true;
        try
        {
            string sql = "SELECT contact_rec_id__c, NoFrom__c, NoTo__c, To__c, Day__c, From__c, Id FROM Default_Availability__c where contact_rec_id__c='" + AgentId + "'";
            qr = login.bi.query(sql);
            bool done = false;
            if (qr.size > 0)
            {

                while (!done)
                {


                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Default_Availability__c con = (Default_Availability__c)qr.records[i];
                        available = new Agent_DefaultAvailability();
                        string id = "";
                        if (con.Id != null)
                        {
                            id = con.Id;
                            if (con.Day__c != null)
                            {
                                string Day_Name = con.Day__c;
                                available.Day = Day_Name;
                                #region For Monday Availability
                                if (Day_Name == "Monday")
                                {
                                    available.mondayID = con.Id;
                                    available.mondayStart = con.From__c;
                                    available.mondayEnd = con.To__c;
                                }
                                #endregion

                                #region For Tuesday Availability
                                if (Day_Name == "Tuesday")
                                {
                                    available.tuesdayID = con.Id;
                                    available.tuesdayStart = con.From__c;
                                    available.tuesdayEnd = con.To__c;
                                }
                                #endregion

                                #region For Wednesday Availability
                                if (Day_Name == "Wednesday")
                                {
                                    available.wednesdayID = con.Id;
                                    available.wednesdayStart = con.From__c;
                                    available.wednesdayEnd = con.To__c;
                                }
                                #endregion

                                #region For Thursday Availability
                                if (Day_Name == "Thursday")
                                {
                                    available.thursdayID = con.Id;
                                    available.thursdayStart = con.From__c;
                                    available.thursdayEnd = con.To__c;
                                }
                                #endregion

                                #region For Friday Availability
                                if (Day_Name == "Friday")
                                {
                                    available.fridayID = con.Id;
                                    available.fridayStart = con.From__c;
                                    available.fridayEnd = con.To__c;
                                }
                                #endregion

                                #region For Saturday Availability
                                if (Day_Name == "Saturday")
                                {
                                    available.saturdayID = con.Id;
                                    available.saturdayStart = con.From__c;
                                    available.saturdayEnd = con.To__c;
                                }
                                #endregion

                                #region For Sunday Availability
                                if (Day_Name == "Sunday")
                                {
                                    available.sundayID = con.Id;
                                    available.sundayStart = con.From__c;
                                    available.sundayEnd = con.To__c;
                                }
                                #endregion

                                result.Add(id, available);
                            }
                        }
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }
               
            }
        }
        catch (Exception)
        {

            result = null;
        }
        return result;
    }

    public static bool update_DefaultAbility(string id,string starttime,string endtime,  ref string error)
    {
        bool result = false;

        try
        {
            if (id =="")
            {
                return false;
            }

            sObject[] accountItems = new sObject[1];

             Default_Availability__c ac = new Default_Availability__c();

                ac.Id = id;
                ac.From__c= starttime;
                ac.To__c = endtime;
                accountItems[0] = ac;
          

            foreach (sObject accitems in accountItems)
            {
                if (Update_Availability(accitems, ref error))
                {
                    result = true;
                }
                else
                {
                    error += Environment.NewLine + error;
                }
            }
        }
        catch (Exception ex)
        {
        }
        return result;
    }

    private static bool Update_Availability(sObject saveThisProp, ref string ers)
    {
        bool result = false;
        try
        {
            #region Salesforce Login Check

            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

            #endregion Salesforce Login Check

            #region save records to Salesforce

            sObject[] accitems = new sObject[1];
            accitems[0] = saveThisProp;

            SaveResult[] saveResults = login.bi.update(accitems);

            // Handle the results

            for (int ik = 0; ik < saveResults.Length; ik++)
            {
                // Determine whether create() succeeded or had errors

                if (saveResults[ik].success)
                {
                    // No errors, so retrieve the Id created for this record
                    //Session["ssnUrrentOrderId"] = saveResults[ik].id;
                    string current_client_id = saveResults[ik].id;

                    result = true;
                }
                else
                {
                    // Handle the errors

                    foreach (Error error in saveResults[ik].errors)
                    {
                        //http://boards.developerforce.com/t5/Apex-Code-Development/BeforeInsert-caused-by-System-NullPointerException-Attempt-to-de/td-p/169248
                        ers += error.message; //"<br/> Error code is: {0}" + error.statusCode.ToString() + "Error message: {0}" + error.message;
                        //result = false;
                    }
                    result = false;
                }
            }

            #endregion save records to Salesforce
        }
        catch (Exception ex)
        {
            result = false;
            ers = ex.Message;
        }

        return result;
    }

    public static bool Insert_DefaultAbility(DataTable dtinsertavailability,string agentid, ref string error)
    {
        bool result = false;

        try
        {
            if (dtinsertavailability == null)
            {
                return false;
            }
            sObject[] accountItems = new sObject[dtinsertavailability.Rows.Count];
            for (int i = 0; i < dtinsertavailability.Rows.Count; i++)
            {
                Default_Availability__c ac = new Default_Availability__c();
                ac.contact_rec_id__c = agentid;
                ac.Day__c = dtinsertavailability.Rows[i]["Day"].ToString();
                ac.From__c = dtinsertavailability.Rows[i]["starttime"].ToString();
                ac.To__c = dtinsertavailability.Rows[i]["endtime"].ToString();
                accountItems[i] = ac;
            }

            foreach (sObject accitems in accountItems)
            {
                if (Insert_Availability_toSF(accitems, ref error))
                {
                    result = true;
                }
                else
                {
                    error += Environment.NewLine + error;
                }
            }
        }
        catch (Exception ex)
        {
        }
        return result;
    }

    private static bool Insert_Availability_toSF(sObject saveThisProp, ref string ers)
    {
        bool result = false;
        try
        {
            #region Salesforce Login Check

            if (login.bi != null)
            {
            }
            else
            {
                login.loginnow();
            }

            #endregion Salesforce Login Check

            #region save records to Salesforce

            sObject[] accitems = new sObject[1];
            accitems[0] = saveThisProp;

            SaveResult[] saveResults = login.bi.create(accitems);

            // Handle the results

            for (int ik = 0; ik < saveResults.Length; ik++)
            {
                // Determine whether create() succeeded or had errors

                if (saveResults[ik].success)
                {
                    // No errors, so retrieve the Id created for this record
                    //Session["ssnUrrentOrderId"] = saveResults[ik].id;
                    string current_client_id = saveResults[ik].id;

                    result = true;
                }
                else
                {
                    // Handle the errors

                    foreach (Error error in saveResults[ik].errors)
                    {
                        //http://boards.developerforce.com/t5/Apex-Code-Development/BeforeInsert-caused-by-System-NullPointerException-Attempt-to-de/td-p/169248
                        ers += error.message; //"<br/> Error code is: {0}" + error.statusCode.ToString() + "Error message: {0}" + error.message;
                        //result = false;
                    }
                    result = false;
                }
            }

            #endregion save records to Salesforce
        }
        catch (Exception ex)
        {
            result = false;
            ers = ex.Message;
        }

        return result;
    }

    private int GetNumberFromTime(string pStart)
    {
        int result = 0;


        if (pStart == "")
        {
            return 0;
        }

        switch (pStart)
        {
            #region Converting Time to Number
            case "6:00 a.m.":
                result = 35; break;

            case "6:30 a.m.":
                result = 34; break;

            case "7:00 a.m.":
                result = 33; break;

            case "7:30 a.m.":
                result = 32; break;

            case "8:00 a.m.":
                result = 31; break;


            case "8:30 a.m.":
                result = 30; break;


            case "9:00 a.m.":
                result = 29; break;


            case "9:30 a.m.":
                result = 28; break;


            case "10:00 a.m.":
                result = 27; break;


            case "10:30 a.m.":
                result = 26; break;


            case "11:00 a.m.":
                result = 25; break;


            case "11:30 a.m.":
                result = 24; break;


            case "12:00 p.m.":
                result = 23; break;


            case "12:30 p.m.":
                result = 22; break;


            case "1:00 p.m.":
                result = 21; break;


            case "1:30 p.m.":
                result = 20; break;


            case "2:00 p.m.":
                result = 19; break;

            case "2:30 p.m.":
                result = 18; break;


            case "3:00 p.m.":
                result = 17; break;


            case "3:30 p.m.":
                result = 16; break;


            case "4:00 p.m.":
                result = 15; break;


            case "4:30 p.m.":
                result = 14; break;


            case "5:00 p.m.":
                result = 13; break;


            case "5:30 p.m.":
                result = 12; break;


            case "6:00 p.m.":
                result = 11; break;


            case "6:30 p.m.":
                result = 10; break;


            case "7:00 p.m.":
                result = 9; break;


            case "7:30 p.m.":
                result = 8; break;


            case "8:00 p.m.":
                result = 7; break;


            case "8:30 p.m.":
                result = 6; break;


            case "9:00 p.m.":
                result = 5; break;


            case "9:30 p.m.":
                result = 4; break;


            case "10:00 p.m.":
                result = 3; break;


            case "10:30 p.m.":
                result = 2; break;


            case "11:00 p.m.":
                result = 1; break;


            default:
                result = 0;
                break;
            #endregion
        }

        return result;
    }

    public static ArrayList getFuture_AppointmentDate(string agentid)
    {
        ArrayList result = new ArrayList();

        #region Check Salesforce login

        if (login.bi != null)
        {
        }
        else
        {
            login.loginnow();
        }

        #endregion Check Salesforce login

        try
        {
            QueryResult qr = null;
            login.bi.QueryOptionsValue = new QueryOptions();
            login.bi.QueryOptionsValue.batchSize = 250;
            login.bi.QueryOptionsValue.batchSizeSpecified = true;

            string pSoql = "SELECT Appointment_Date__c FROM Appointment__c where Appointment_Date__c>= today and Contact__c='" + agentid + "'";
            qr = login.bi.query(pSoql);

            bool done = false;
            if (qr.size > 0)
            {
                while (!done)
                {
                    for (int i = 0; i < qr.records.Length; i++)
                    {
                        Appointment__c appt = (Appointment__c)qr.records[i];
                        if (appt.Appointment_Date__c != null)
                        {
                            DateTime dt = (DateTime)appt.Appointment_Date__c;
                            result.Add(dt);
                        }
                        
                    }
                    if (qr.done)
                    {
                        done = true;
                    }
                    else
                    {
                        qr = login.bi.queryMore(qr.queryLocator);
                    }
                }
            }
            else
            {
                result = null;
            }
        }
        catch (Exception)
        {
            throw;
        }
        return result;
    }


    protected void btnadd_Click(object sender, EventArgs e)
    {
        //string AgenId = "003i0000007tDqH";
        string errormess = "";
        bool haveOk = true;
        int starttime = 0, endtime = 0;
        DataTable resultinsert = new DataTable();
        resultinsert = insertnewapp();
        DataRow drForinsert = resultinsert.NewRow();
        #region Monday
        if (mondayid.Value == "")
        {
            starttime = GetNumberFromTime(ddlStartMon_New.SelectedValue);
            endtime = GetNumberFromTime(ddlEndMon_New.SelectedValue);
            if (ddlStartMon_New.SelectedValue != "--None--" || ddlEndMon_New.SelectedValue != "--None--")
            {
                if (starttime > endtime)
                {
                    string Day = "Monday";
                    string start = ddlStartMon_New.SelectedValue;
                    string end = ddlEndMon_New.SelectedValue;
                    if ((ddlStartMon_New.SelectedValue == "--None--" && ddlEndMon_New.SelectedValue != "--None--") || (ddlStartMon_New.SelectedValue != "--None--" && ddlEndMon_New.SelectedValue == "--None--"))
                    {
                        haveOk = false;
                    }
                    else
                    {
                        drForinsert["Day"] = "Monday";
                        drForinsert["starttime"] = start;
                        drForinsert["endtime"] = end;
                        resultinsert.Rows.Add(drForinsert);
                        drForinsert = resultinsert.NewRow();
                        if (resultinsert.Rows.Count > 0)
                        {
                            haveOk = true;
                            sucess += "Monday" + ",";
                        }
                        //if (Insert_DefaultAbility(AgenId, Day, start, end, ref errormess))
                        //{
                        //    haveOk = true;
                        //    sucess += "Monday" + ",";
                        //}
                    }

                }
                else
                {
                    haveOk = false;
                }
            }
            
        }

        #endregion

        #region Tuesday
        if (haveOk)
        {
            if (tuesdayid.Value == "")
            {
                starttime = GetNumberFromTime(ddlStartTues_New.SelectedValue);
                endtime = GetNumberFromTime(ddlEndTues_New.SelectedValue);
                if (ddlStartTues_New.SelectedValue != "--None--" || ddlEndTues_New.SelectedValue != "--None--")
                {
                    if (starttime > endtime)
                    {
                        string Day = "Tuesday";
                        string start = ddlStartTues_New.SelectedValue;
                        string end = ddlEndTues_New.SelectedValue;

                        if ((ddlStartTues_New.SelectedValue == "--None--" && ddlEndTues_New.SelectedValue != "--None--") || (ddlStartTues_New.SelectedValue != "--None--" && ddlEndTues_New.SelectedValue == "--None--"))
                        {
                            haveOk = false;
                        }
                        else
                        {
                            drForinsert["Day"] = "Tuesday";
                            drForinsert["starttime"] = start;
                            drForinsert["endtime"] = end;
                            resultinsert.Rows.Add(drForinsert);
                            drForinsert = resultinsert.NewRow();
                            if (resultinsert.Rows.Count > 0)
                            {
                                haveOk = true;
                                sucess += "Tuesday" + ",";
                            }
                        }
                    }
                    else
                    {
                        haveOk = false;
                    }
                }
            }
        }

        #endregion

        #region Wednesday
        if (haveOk)
        {
            if (wednesdayid.Value == "")
            {
                starttime = GetNumberFromTime(ddlStartWed_New.SelectedValue);
                endtime = GetNumberFromTime(ddlEndWed_New.SelectedValue);
                if (ddlStartWed_New.SelectedValue != "--None--"|| ddlEndWed_New.SelectedValue != "--None--")
                {
                    if (starttime > endtime)
                    {
                        string Day = "Wednesday";
                        string start = ddlStartWed_New.SelectedValue;
                        string end = ddlEndWed_New.SelectedValue;
                        if ((ddlStartWed_New.SelectedValue == "--None--" && ddlEndWed_New.SelectedValue != "--None--") || (ddlStartWed_New.SelectedValue != "--None--" && ddlEndWed_New.SelectedValue == "--None--"))
                        {
                            haveOk = false;
                        }
                        else
                        {
                            drForinsert["Day"] = "Wednesday";
                            drForinsert["starttime"] = start;
                            drForinsert["endtime"] = end;
                            resultinsert.Rows.Add(drForinsert);
                            drForinsert = resultinsert.NewRow();
                            if (resultinsert.Rows.Count > 0)
                            {
                                haveOk = true;
                                sucess += "Wednesday" + ",";
                            }
                        }

                    }
                    else
                    {
                        haveOk = false;
                    }
                }
            }
        }
        #endregion

        #region Thursday
        if (haveOk)
        {
            if (thursdayid.Value == "")
            {
                starttime = GetNumberFromTime(ddlStartThur_New.SelectedValue);
                endtime = GetNumberFromTime(ddlEndThur_New.SelectedValue);
                if (ddlStartThur_New.SelectedValue != "--None--" || ddlEndThur_New.SelectedValue != "--None--")
                {
                    if (starttime > endtime)
                    {
                        string Day = "Thursday";
                        string start = ddlStartThur_New.SelectedValue;
                        string end = ddlEndThur_New.SelectedValue;
                        if ((ddlStartThur_New.SelectedValue == "--None--" && ddlEndThur_New.SelectedValue != "--None--") || (ddlStartThur_New.SelectedValue != "--None--" && ddlEndThur_New.SelectedValue == "--None--"))
                        {
                            haveOk = false;
                        }
                        else
                        {
                            drForinsert["Day"] = "Thursday";
                            drForinsert["starttime"] = start;
                            drForinsert["endtime"] = end;
                            resultinsert.Rows.Add(drForinsert);
                            drForinsert = resultinsert.NewRow();
                            if (resultinsert.Rows.Count > 0)
                            {
                                haveOk = true;
                                sucess += "Thursday" + ",";
                            }
                        }

                    }
                    else
                    {
                        haveOk = false;
                    }
                }
            }
        }

        #endregion

        #region Friday
        if (haveOk)
        {
            if (fridayid.Value == "")
            {
                starttime = GetNumberFromTime(ddlStartFrid_New.SelectedValue);
                endtime = GetNumberFromTime(ddlEndFri_New.SelectedValue);
                if (ddlStartFrid_New.SelectedValue != "--None--" || ddlEndFri_New.SelectedValue != "--None--")
                {
                    if (starttime > endtime)
                    {
                        string Day = "Friday";
                        string start = ddlStartFrid_New.SelectedValue;
                        string end = ddlEndFri_New.SelectedValue;
                        if ((ddlStartFrid_New.SelectedValue == "--None--" && ddlEndFri_New.SelectedValue != "--None--") || (ddlStartFrid_New.SelectedValue != "--None--" && ddlEndFri_New.SelectedValue == "--None--"))
                        {
                            haveOk = false;
                        }
                        else
                        {
                            drForinsert["Day"] = "Friday";
                            drForinsert["starttime"] = start;
                            drForinsert["endtime"] = end;
                            resultinsert.Rows.Add(drForinsert);
                            drForinsert = resultinsert.NewRow();
                            if (resultinsert.Rows.Count > 0)
                            {
                                haveOk = true;
                                sucess += "Friday" + ",";
                            }
                        }
                    }
                    else
                    {
                        haveOk = false;
                    }
                }
            }
        }

        #endregion

        #region Saturday
        if (haveOk)
        {
            if (saturdayid.Value == "")
            {
                starttime = GetNumberFromTime(ddlStartSat_New.SelectedValue);
                endtime = GetNumberFromTime(ddlEndSat_New.SelectedValue);
                if (ddlStartSat_New.SelectedValue != "--None--" || ddlEndSat_New.SelectedValue != "--None--")
                {
                    if (starttime > endtime)
                    {
                        string Day = "Saturday";
                        string start = ddlStartSat_New.SelectedValue;
                        string end = ddlEndSat_New.SelectedValue;
                        if ((ddlStartSat_New.SelectedValue == "--None--" && ddlEndSat_New.SelectedValue != "--None--") || (ddlStartSat_New.SelectedValue != "--None--" && ddlEndSat_New.SelectedValue == "--None--"))
                        {
                            haveOk = false;
                        }
                        else
                        {
                            drForinsert["Day"] = "Saturday";
                            drForinsert["starttime"] = start;
                            drForinsert["endtime"] = end;
                            resultinsert.Rows.Add(drForinsert);
                            drForinsert = resultinsert.NewRow();
                            if (resultinsert.Rows.Count > 0)
                            {
                                haveOk = true;
                                sucess += "Saturday" + ",";
                            }
                        }
                    }
                    else
                    {
                        haveOk = false;
                    }
                }
            }
        }
        #endregion

        #region Sunday
        if (haveOk)
        {
            if (sundayid.Value == "")
            {
                starttime = GetNumberFromTime(ddlStartSun_New.SelectedValue);
                endtime = GetNumberFromTime(ddlEndSun_New.SelectedValue);
                if (ddlStartSun_New.SelectedValue != "--None--" || ddlEndSun_New.SelectedValue != "--None--")
                {
                    if (starttime > endtime)
                    {
                        string Day = "Sunday";
                        string start = ddlStartSun_New.SelectedValue;
                        string end = ddlEndSun_New.SelectedValue;
                        if ((ddlStartSun_New.SelectedValue == "--None--" && ddlEndSun_New.SelectedValue != "--None--") || (ddlStartSun_New.SelectedValue != "--None--" && ddlEndSun_New.SelectedValue == "--None--"))
                        {
                            haveOk = false;
                        }
                        else
                        {
                            drForinsert["Day"] = "Sunday";
                            drForinsert["starttime"] = start;
                            drForinsert["endtime"] = end;
                            resultinsert.Rows.Add(drForinsert);
                            drForinsert = resultinsert.NewRow();
                            if (resultinsert.Rows.Count > 0)
                            {
                                haveOk = true;
                                sucess += "Sunday" + ",";
                            }
                        }
                    }
                    else
                    {
                        haveOk = false;
                    }
                }
            }
        }

        #endregion

        if (haveOk)
        {
            if (sucess != "")
            {
                if (resultinsert.Rows.Count > 0)
                {
                    string messerror = "";
                    if (Insert_DefaultAbility(resultinsert, AgenId, ref messerror))
                    {
                        Response.Redirect("Default_availa_rdirect.aspx?p1=" + sucess.TrimEnd(',') + "&p2=" + erromess.TrimEnd(',') + "");
                    }
                }
            }
        }
        else
        {

            errmessDiv.InnerHtml = "Invalid Time Range";
        }

    }

    public static DataTable insertnewapp()
    {
        DataTable dt = new DataTable("mydt1");
        dt.Columns.Add("Day".ToString());
        dt.Columns.Add("starttime".ToString());
        dt.Columns.Add("endtime".ToString());
       

        return dt;
    }


    
}