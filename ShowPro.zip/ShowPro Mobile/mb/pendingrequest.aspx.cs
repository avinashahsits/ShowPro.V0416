﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class mb_pendingrequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList pndgs = new ArrayList();
        string con_id = Convert.ToString(Session["ssnUserId"]);

        pndgs = getPendingAppointmentSF.pendingAppointments(con_id);

        if (pndgs != null && pndgs.Count > 0)
        {
            Session["ssnPendingAppts"] = pndgs;
        }
        else
        {
            Session["ssnPendingAppts"] = null;
        }

        //Session["ssnPendingAppts"] = pndgs;

        if (getPendingAppt())
        {

        }
        else
        {
            main_Div.InnerHtml = "You have no pending requests.";
        }

    }

   

    private bool getPendingAppt()
    {
        bool result = false;
        try
        {
            Dictionary<DateTime, string> forDate = new Dictionary<DateTime, string>();

            ArrayList pndgs = new ArrayList();


            if (Session["ssnPendingAppts"] != null)
            {
                pndgs = (ArrayList)Session["ssnPendingAppts"];
            }
            else
            {
                return result;
            }

            string output = "<ul data-role=\"listview\" data-count-theme=\"c\" data-inset=\"false\">";


            var query = from getPendingAppointmentSF.PendingApptInfo appts in pndgs
                        select appts;

            //Create a different dictionary to store the counts.
            Dictionary<string, int> valCount = new Dictionary<string, int>();

            foreach (getPendingAppointmentSF.PendingApptInfo apptInfo in query)
            {
                DateTime date_app = Convert.ToDateTime(apptInfo.Appt_date);

                if (valCount.ContainsKey(date_app.ToShortDateString()))
                    valCount[date_app.ToShortDateString()]++;
                else
                    valCount[date_app.ToShortDateString()] = 1;

                try
                {
                    forDate.Add(date_app, date_app.ToShortDateString());
                }
                catch (Exception ex)
                {

                }
            }


            
            //Iterate through the values, setting count to 1 or incrementing current count.
            //foreach (string i in forDate.Values)
              //  if (valCount.ContainsKey(i))
                //    valCount[i]++;
                //else
                  //  valCount[i] = 1;

              int isFirstRows = 0;

              Dictionary<DateTime, bool> dateHeader = new Dictionary<DateTime, bool>();

              foreach (KeyValuePair<DateTime, string> date in forDate)
              {
                  bool dateDisplayed = false;

                  //SELECT Appointment_Date__c, Name, Id, Invite_Status__c, Contact__c FROM Appointment__c where Appointment_Date__c>= today and Contact__c='003i0000007tDqHAAU'

                  DateTime currentDate = DateTime.Parse(date.Key.ToShortDateString());
                  if (dateDisplayed == false && !dateHeader.ContainsKey(currentDate))
                  {
                      //output += "<div  style=\"background-color:#8D8D8D; color:#fff;  text-align: center; width:100%; height:27px; align:center; vertical-align:central; padding-top:5px;\">" + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + "</div>";
                      string counts = "<span class=\"ui-li-count\" style=\" color:red; border:1px solid rgb(140, 198, 63);-webkit-font-smoothing: antialiased;\">" + valCount[currentDate.ToShortDateString()] + "</span>";
                      output += " <li style=\"background-color:#8D8D8D; color:#fff; font-size: small; font-weight:normal;  text-align: center; -webkit-font-smoothing: antialiased;\">"
                      // + String.Format("{0:dddd, MMMM d, yyyy}", currentDate) + counts + "</li>";
                       //+ String.Format("{0:dddd}", currentDate) + " " + String.Format("{0:MM/dd/yyyy}", currentDate) + "</li>";
                       + String.Format("{0:dddd}", currentDate) + " " + currentDate.ToShortDateString() + "</li>";

                      dateDisplayed = true;
                      try
                      {
                          dateHeader.Add(currentDate, true);
                      }
                      catch (Exception)
                      {
                      }
                  }
                  if (isFirstRows == 0)
                  {
                      isFirstRows++;
                  }
                  else
                  {
                      output += "<br/>";
                  }
                  int counter = 1;
                  foreach (getPendingAppointmentSF.PendingApptInfo apptInfo in query)
                  {
                      if (date.Key == Convert.ToDateTime(apptInfo.Appt_date))
                      {

                          string AjaxDivId = "ajx_" + counter;

                          string htmltext = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 100%;font-size:small;\"><tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px; font-size:12px;\">" +
                              apptInfo.Appt_date + "<br />" +
                               apptInfo.Appt_time +
                            "</td>" +
                            "<td align=\"left\" valign=\"top\" style=\"padding-top: 10px; font-size:12px; \">" + apptInfo.Prop_name + "<br />" + apptInfo.Prop_address +
                            "</td></tr></table>";
                          output += "<li><a href=\"pendingrequestDetails.aspx?p1=" + apptInfo.Appt_id + "\" data-ajax=\"false\">" + htmltext + "</a></li>";
                          counter++;
                          output += "</table>";
                      }

                      
                  }
                  
              }


           
            result = true;
            main_Div.InnerHtml = output;
        }
        catch (Exception ex)
        {
            result = false;
        }

        return result;
    }

    /*
     string output = " <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 98%;\">";
        for (int i = 0; i < 4; i++)
        {
            output += "<tr> <td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\">" +
               "  Sept. 10 2013<br />" +
                 "1:00 pm" +
             "</td>" +
             "<td align=\"left\" valign=\"top\" style=\"padding-top: 10px;\">" +
                 "Poperty Name<br />" + i + " Line Address 1 <br /> City <br />State- Zip" +
             "</td>" +
             "<td align=\"right\" valign=\"top\" style=\"padding-top: 10px;\"> <h4>></h4></td>" +
         "</tr>" +
         "<tr>" +
             "<td align=\"center\" valign=\"top\" colspan=\"4\" style=\"border-bottom: 1px solid #ccc;\">" +
                 "<table border=\"0\" cellpadding=\"0\" cellspacing=\"10\">" +
                     "<tr> <td> <input type=\"button\" value=\"Decline\" onclick=\"appt_acpt('asssasddd') \" /> </td>" +
                         "<td>  <input type=\"button\" value=\"Cancel\" /></td>" +
                         "<td> <input type=\"button\" value=\"Accept\" /> </td>" +
                     "</tr> </table> </td>" +
                     " </tr>";

        }


        output += "</table>";

       // main_Div.InnerHtml = output;
     */



}