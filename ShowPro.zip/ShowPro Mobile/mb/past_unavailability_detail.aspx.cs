﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_past_unavailability_detail : System.Web.UI.Page
{
    public String GetParam(String ParamName)
    {
        String Param = "", GetParam = "";
        if (Request.Form[ParamName] != null)
            Param = Request.Form[ParamName];
        else if (Request.QueryString[ParamName] != null)
            Param = Request.QueryString[ParamName];
        else
            Param = "";

        if (Param == "")
            GetParam = "";
        else
        {
            GetParam = Param;
        }
        return GetParam;
    }
    public string exDate = "", exTime = "", exId = "", SF_Contact_id = "";

    private void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            SF_Contact_id = Convert.ToString(Session["ssnUserId"]);
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            string id = GetParam("p1").Trim();
            string date = GetParam("p2").Trim();
            string time = GetParam("p3").Trim();


            Message.InnerHtml = "";

            if (date != "" && id != "")
            {
                DateTime dt = Convert.ToDateTime(date);

                string DayName = String.Format("{0:dddd}", dt);
                //Console.WriteLine("Year: {0}, Month: {1}, Day: {2}", dt.Year, dt.Month, dt.Day);
                date = dt.Month + "/" + dt.Day + "/" + dt.Year;

                exDate = DayName + " , " + date;
                exId = id;
                SFobj_id.Value = id;
                exTime = time;
            }
        }
        else
        {
            string id = GetParam("p1").Trim();
            string date = GetParam("p2").Trim();
            string time = GetParam("p3").Trim();
            DateTime dt = Convert.ToDateTime(date);

            string DayName = String.Format("{0:dddd}", dt);
            //Console.WriteLine("Year: {0}, Month: {1}, Day: {2}", dt.Year, dt.Month, dt.Day);
            date = dt.Month + "/" + dt.Day + "/" + dt.Year;

            exDate = DayName + " , " + date;
            exTime = time;
        }
    }
}