﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mb_updatepassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            string Salesforce_obj_id = Convert.ToString(Session["ssnUserId"]);

            string pwd = loginPassword(Salesforce_obj_id);

            txtCurrent.Text = pwd;
        }
        else
        {
            txtCurrent.Text = "";
            Response.Redirect("Default.aspx");
        }
    }

    private string loginPassword(string pSF_id)
    {
        string result = "";
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "select  auto_id,security_token, security_pin, acc_type from user_master where" +
                " salesforce_obj_id='" + pSF_id + "' and acc_status='1'";

            SqlDataReader dr;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                if (dr.Read())
                {
                    //Session["ssnUserId"] = Convert.ToString(dr["salesforce_obj_id"]);
                    //Session["ssnUserType"] = Convert.ToString(dr["acc_type"]);
                    result = Convert.ToString(dr["security_pin"]);
                }

            }
            else
            {
                result = "";
            }
            dr.Close();
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            result = "";
        }
        finally
        {
            con.Close();
        }
        return result;
    }
    private bool updatePassword(string pSF_id,string pNewPwd)
    {
        bool result = false;
        SqlConnection con = new SqlConnection(appdb.dbconmars());
        try
        {
            string sql = "update user_master set security_pin='" + pNewPwd + "' where" +
                " salesforce_obj_id='" + pSF_id + "' and acc_status='1'";

           
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            int isUpadted = cmd.ExecuteNonQuery();

            if (isUpadted > 0)
            {
                result = true;
            }
           
           
            cmd.Dispose();
        }
        catch (Exception ex)
        {
            result = false;
        }
        finally
        {
            con.Close();
        }
        return result;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (Session["ssnUserId"] != null)
        {
            string Salesforce_obj_id = Convert.ToString(Session["ssnUserId"]);

            string pwd = txtCurrent.Text.Trim();
            string newPwd = txtpwd.Text.Trim();

            if (pwd == newPwd)
            {
                globalError.InnerHtml = "No change in Password!";
            }
            else
            {
                if (updatePassword(Salesforce_obj_id, newPwd))
                {
                    //Session["globalMessText"] = "Your password has been updated.";
                    Response.Redirect("a1.aspx");
                }
            }

             
        }
    }
}