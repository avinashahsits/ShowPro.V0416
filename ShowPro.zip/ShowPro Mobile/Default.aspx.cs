﻿using System;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.RedirectPermanent("http://showdev.anyonehome.com/mb/Default.aspx");
       // Response.RedirectPermanent("http://show.anyonehome.com/mb/Default.aspx");
        Response.RedirectPermanent("mb/Default.aspx");
    }
}